import requests
import json
import zipfile
import os
from pathlib import Path

VERSION_URL = "https://drive.google.com/uc?export=download&id=1V90ocogJiZi99mpHVwQ0-hUH-iTggewI"
UPDATE_URL = "https://drive.google.com/uc?export=download&id=1_0S6src5nR7muZRCT9nP6LE-4LDtiB5k"

LOCAL_VERSION_FILE = "version.json"


def get_local_version():
    try:
        with open(LOCAL_VERSION_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data["version"]
    except:
        return "0.0.0"


def get_remote_version():
    try:
        r = requests.get(VERSION_URL, timeout=5)
        data = r.json()
        return data["version"]
    except:
        return None


def check_update():
    local = get_local_version()
    remote = get_remote_version()

    if remote and remote != local:
        return True, remote

    return False, remote


def download_update():

    print("Baixando atualização...")

    r = requests.get(UPDATE_URL, stream=True)

    with open("update.zip", "wb") as f:
        for chunk in r.iter_content(8192):
            f.write(chunk)

    print("Download completo")


def install_update():

    print("Instalando atualização...")

    with zipfile.ZipFile("update.zip", "r") as zip_ref:
        zip_ref.extractall(".")

    os.remove("update.zip")

    print("Atualização instalada")