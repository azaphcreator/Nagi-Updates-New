module.exports = {
  name: "ajuda",
  aliases: ["help"],
  description: "Mostra ajuda básica",
  async execute(message) {
    await message.channel.send(
      "Comandos base:\n!ping\n!ajuda"
    );
  },
};
