module.exports = {
  name: "ping",
  aliases: [],
  description: "Responde pong",
  async execute(message) {
    await message.channel.send("Pong");
  },
};
