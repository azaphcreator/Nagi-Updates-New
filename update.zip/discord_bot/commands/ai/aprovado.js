const { EmbedBuilder } = require("discord.js");

const TARGET_GUILD_ID = "";
const TARGET_CHANNEL_ID = "1465750046350774414";
const MENTION_ROLE_ID = "";
const ALLOWED_ROLE_IDS = [];
const FLOW_STEPS = [{"id": "customer_name", "type": "text", "label": "Nome do Cliente", "ask": "Envie o nome do cliente completo"}, {"id": "customer_email", "type": "text", "label": "Email do Cliente", "ask": "Envie o email do cliente utilizado na Hotmart"}, {"id": "receipt", "type": "attachment", "label": "Comprovante de Pagamento", "ask": "Envie o comprovante de pagamento"}, {"id": "target_user", "type": "user_mention", "label": "Usuário Mencionado", "ask": "Mencione o usuário"}];
const GRANT_ROLE_TO_MENTIONED_USER = true;
const GRANT_ROLE_ID = "1468344981281308746";

const sessions = new Map();

function hasAllowedRole(member) {
  if (!ALLOWED_ROLE_IDS || ALLOWED_ROLE_IDS.length === 0) return true;
  if (!member || !member.roles || !member.roles.cache) return false;
  return ALLOWED_ROLE_IDS.some(roleId => member.roles.cache.has(roleId));
}

function getAttachmentInfo(message) {
  if (!message.attachments || message.attachments.size === 0) return null;
  const first = message.attachments.first();
  if (!first) return null;

  return {
    name: first.name || "arquivo",
    url: first.url,
    contentType: first.contentType || "desconhecido",
    size: first.size || 0,
  };
}

function getMentionedUser(message) {
  if (!message.mentions || !message.mentions.users || message.mentions.users.size === 0) return null;
  const first = message.mentions.users.first();
  if (!first) return null;

  return {
    id: String(first.id),
    tag: first.tag || first.username || "usuário",
  };
}

function getCurrentStep(session) {
  return FLOW_STEPS[session.stepIndex];
}

module.exports = {
  name: "aprovado",
  aliases: [],
  description: "Comando genérico complexo gerado por IA",

  async execute(message, args, client) {
    try {
      if (TARGET_GUILD_ID && (!message.guild || String(message.guild.id) !== String(TARGET_GUILD_ID))) {
        await message.reply("Este comando só pode ser usado no servidor configurado.");
        return;
      }

      if (!hasAllowedRole(message.member)) {
        await message.reply("❌ Você não tem permissão para usar este comando.");
        return;
      }

      const userId = String(message.author.id);

      if (sessions.has(userId)) {
        await message.reply(
          "Você já tem um fluxo em andamento.\n" +
          "Envie o próximo dado solicitado ou digite `cancelar` para abortar."
        );
        return;
      }

      sessions.set(userId, {
        stepIndex: 0,
        guildId: message.guild ? String(message.guild.id) : "",
        channelId: String(message.channel.id),
        startedAt: Date.now(),
        data: {}
      });

      const firstStep = FLOW_STEPS[0];
      await message.reply(firstStep.ask);
    } catch (err) {
      console.error("[BOT] erro ao iniciar fluxo genérico:", err);
      await message.reply("Erro ao iniciar o fluxo.").catch(() => null);
    }
  },

  async onMessage(message, client) {
    try {
      if (message.author?.bot) return;
      if (TARGET_GUILD_ID && (!message.guild || String(message.guild.id) !== String(TARGET_GUILD_ID))) return;

      const userId = String(message.author.id);
      const session = sessions.get(userId);
      if (!session) return;

      if (String(message.channel.id) !== String(session.channelId)) return;

      const content = (message.content || "").trim();

      if (true && content.toLowerCase() === "cancelar") {
        sessions.delete(userId);
        await message.reply("❌ Fluxo cancelado com sucesso.");
        return;
      }

      const step = getCurrentStep(session);
      if (!step) {
        sessions.delete(userId);
        return;
      }

      if (step.type === "text") {
        if (!content || content.startsWith("!")) return;

        session.data[step.id] = content;
      }

      if (step.type === "attachment") {
        const attachment = getAttachmentInfo(message);
        if (!attachment) {
          await message.reply(`⚠️ Agora preciso de: ${step.label} como anexo.`);
          return;
        }
        session.data[step.id] = attachment;
      }

      if (step.type === "user_mention") {
        const mentioned = getMentionedUser(message);
        if (!mentioned) {
          await message.reply(`⚠️ Agora preciso que você mencione um usuário para: ${step.label}.`);
          return;
        }
        session.data[step.id] = mentioned;
      }

      session.stepIndex += 1;

      if (session.stepIndex < FLOW_STEPS.length) {
        sessions.set(userId, session);
        const nextStep = getCurrentStep(session);
        await message.reply(nextStep.ask);
        return;
      }

      const targetChannel =
        (TARGET_CHANNEL_ID
          ? message.guild.channels.cache.get(TARGET_CHANNEL_ID) || await message.guild.channels.fetch(TARGET_CHANNEL_ID).catch(() => null)
          : message.channel);

      if (!targetChannel || !targetChannel.isTextBased()) {
        await message.reply("❌ Não consegui encontrar o canal de destino configurado.");
        sessions.delete(userId);
        return;
      }

      const fields = [];

      for (const s of FLOW_STEPS) {
        const value = session.data[s.id];

        if (s.type === "text") {
          fields.push({
            name: s.label,
            value: String(value || "Não informado"),
            inline: false,
          });
        }

        if (s.type === "attachment") {
          fields.push({
            name: s.label,
            value: value?.url ? `[Abrir arquivo](${value.url})` : "Arquivo não encontrado",
            inline: false,
          });
        }

        if (s.type === "user_mention") {
          fields.push({
            name: s.label,
            value: value?.id ? `<@${value.id}>\nID: \`${value.id}\`` : "Usuário não informado",
            inline: false,
          });
        }
      }

      fields.push(
        {
          name: "📨 Solicitante",
          value: `${message.author}\nID: \`${message.author.id}\``,
          inline: false,
        },
        {
          name: "💬 Canal de origem",
          value: `<#${message.channel.id}>`,
          inline: true,
        },
        {
          name: "🕒 Enviado em",
          value: `<t:${Math.floor(Date.now() / 1000)}:F>`,
          inline: true,
        }
      );

      const embed = new EmbedBuilder()
        .setTitle("Cliente Verificado")
        .setDescription("Usuario que fez a verificação")
        .setColor(15830058)
        .addFields(fields)
        .setFooter({ text: "Aprovação realizada com sucesso" })
        .setTimestamp();

      const sendResult = await targetChannel.send({
        content: MENTION_ROLE_ID ? `<@&${MENTION_ROLE_ID}>` : "",
        embeds: [embed],
      });

      if (GRANT_ROLE_TO_MENTIONED_USER && GRANT_ROLE_ID) {
        for (const s of FLOW_STEPS) {
          if (s.type === "user_mention") {
            const target = session.data[s.id];
            if (target?.id) {
              const member = await message.guild.members.fetch(target.id).catch(() => null);
              if (member) {
                await member.roles.add(GRANT_ROLE_ID).catch(() => null);
              }
            }
          }
        }
      }

      await message.reply("✅ Fluxo finalizado com sucesso.");
      sessions.delete(userId);
    } catch (err) {
      console.error("[BOT] erro em onMessage do comando genérico:", err);
      try {
        await message.reply("❌ Ocorreu um erro durante o fluxo.");
      } catch (_) {}
    }
  },
};
