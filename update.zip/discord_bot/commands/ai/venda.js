const { EmbedBuilder } = require("discord.js");

const TARGET_GUILD_ID = "1447626538722787441";
const TARGET_CHANNEL_ID = "1475574286243594461";
const MENTION_ROLE_ID = "1468684459531309268";
const ALLOWED_ROLE_IDS = ["1468684548983492741"];

const sessions = new Map();

function getAttachmentInfo(message) {
  if (!message.attachments || message.attachments.size === 0) return null;
  const first = message.attachments.first();
  if (!first) return null;

  return {
    name: first.name || "arquivo",
    url: first.url,
    contentType: first.contentType || "desconhecido",
    size: first.size || 0,
  };
}

function hasAllowedRole(member) {
  if (!ALLOWED_ROLE_IDS || ALLOWED_ROLE_IDS.length === 0) return true;
  if (!member || !member.roles || !member.roles.cache) return false;
  return ALLOWED_ROLE_IDS.some(roleId => member.roles.cache.has(roleId));
}

module.exports = {
  name: "venda",
  aliases: [],
  description: "Comando complexo gerado por blueprint",

  async execute(message, args, client) {
    try {
      if (!message.guild || String(message.guild.id) !== String(TARGET_GUILD_ID)) {
        await message.reply("Este comando só pode ser usado no servidor configurado.");
        return;
      }

      if (!hasAllowedRole(message.member)) {
        await message.reply("❌ Você não tem permissão para usar este comando.");
        return;
      }

      const userId = String(message.author.id);

      if (sessions.has(userId)) {
        await message.reply(
          "Você já tem uma coleta em andamento.\n" +
          "Envie o próximo dado solicitado ou digite `cancelar` para abortar."
        );
        return;
      }

      sessions.set(userId, {
        step: "awaiting_name",
        guildId: String(message.guild.id),
        channelId: String(message.channel.id),
        startedAt: Date.now(),
        data: {
          customerName: "",
          purchaseReceipt: null,
          labelReceipt: null
        }
      });

      await message.reply("📦 **Início do envio de venda**\n\nPrimeiro, envie **seu nome**.\n\nVocê pode digitar `cancelar` a qualquer momento.");
    } catch (err) {
      console.error("[BOT] erro ao iniciar fluxo:", err);
      await message.reply("Erro ao iniciar o fluxo.").catch(() => null);
    }
  },

  async onMessage(message, client) {
    try {
      if (!message.guild || String(message.guild.id) !== String(TARGET_GUILD_ID)) return;
      if (message.author?.bot) return;

      const userId = String(message.author.id);
      const session = sessions.get(userId);
      if (!session) return;

      if (String(message.channel.id) !== String(session.channelId)) return;

      const content = (message.content || "").trim();

      if (content.toLowerCase() === "cancelar") {
        sessions.delete(userId);
        await message.reply("❌ Coleta cancelada com sucesso.");
        return;
      }

      if (session.step === "awaiting_name") {
        if (!content || content.startsWith("!")) return;

        session.data.customerName = content;
        session.step = "awaiting_purchase_receipt";
        sessions.set(userId, session);

        await message.reply("✅ Nome salvo.\n\nAgora envie o **comprovante de compra** como anexo.");
        return;
      }

      if (session.step === "awaiting_purchase_receipt") {
        const attachment = getAttachmentInfo(message);
        if (!attachment) {
          await message.reply("⚠️ Agora preciso do **comprovante de compra** como anexo.");
          return;
        }

        session.data.purchaseReceipt = attachment;
        session.step = "awaiting_label_receipt";
        sessions.set(userId, session);

        await message.reply("✅ Comprovante de compra salvo.\n\nAgora envie o **comprovante da etiqueta** como anexo.");
        return;
      }

      if (session.step === "awaiting_label_receipt") {
        const attachment = getAttachmentInfo(message);
        if (!attachment) {
          await message.reply("⚠️ Agora preciso do **comprovante da etiqueta** como anexo.");
          return;
        }

        session.data.labelReceipt = attachment;

        const targetChannel =
          message.guild.channels.cache.get(TARGET_CHANNEL_ID) ||
          (await message.guild.channels.fetch(TARGET_CHANNEL_ID).catch(() => null));

        if (!targetChannel || !targetChannel.isTextBased()) {
          await message.reply("❌ Não consegui encontrar o canal de destino configurado.");
          sessions.delete(userId);
          return;
        }

        const embed = new EmbedBuilder()
          .setTitle("📦 Nova venda enviada")
          .setDescription("Uma nova venda foi enviada para análise.")
          .setColor(15830058)
          .addFields(
            {
              name: "👤 Nome",
              value: session.data.customerName || "Não informado",
              inline: false,
            },
            {
              name: "🙍 Usuário",
              value: `${message.author} \nID: \`${message.author.id}\``,
              inline: false,
            },
            {
              name: "🛒 Comprovante de compra",
              value: `[Abrir arquivo](${session.data.purchaseReceipt.url})`,
              inline: false,
            },
            {
              name: "🏷️ Comprovante da etiqueta",
              value: `[Abrir arquivo](${session.data.labelReceipt.url})`,
              inline: false,
            },
            {
              name: "💬 Canal de origem",
              value: `<#${message.channel.id}>`,
              inline: true,
            },
            {
              name: "🕒 Enviado em",
              value: `<t:${Math.floor(Date.now() / 1000)}:F>`,
              inline: true,
            }
          )
          .setFooter({ text: "RPN BOT • Sistema de envio de venda" })
          .setTimestamp();

        await targetChannel.send({
          content: MENTION_ROLE_ID ? `<@&${MENTION_ROLE_ID}>` : "",
          embeds: [embed],
        });

        await message.reply("✅ Sua solicitação foi enviada com sucesso.");
        sessions.delete(userId);
      }
    } catch (err) {
      console.error("[BOT] erro em onMessage do comando:", err);
      try {
        await message.reply("❌ Ocorreu um erro durante a coleta.");
      } catch (_) {}
    }
  },
};
