const path = require("path");
require("dotenv").config({
  path: path.join(__dirname, "bot.env"),
  override: true,
});

const fs = require("fs");
const { Client, GatewayIntentBits, Partials, Events } = require("discord.js");

const TOKEN = process.env.DISCORD_BOT_TOKEN || "";
const PREFIX = process.env.PREFIX || "!";
const OWNER_ID = process.env.OWNER_ID || "";

if (!TOKEN) {
  console.log("[BOT] DISCORD_BOT_TOKEN não configurado no bot.env");
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.MessageContent,
  ],
  partials: [Partials.Channel],
});

const commands = new Map();

function loadCommandsFrom(folder) {
  if (!fs.existsSync(folder)) return;

  const files = fs.readdirSync(folder).filter((file) => file.endsWith(".js"));

  for (const file of files) {
    const fullPath = path.join(folder, file);

    try {
      delete require.cache[require.resolve(fullPath)];
      const command = require(fullPath);

      if (!command || !command.name || typeof command.execute !== "function") {
        console.log("[BOT] comando ignorado:", fullPath);
        continue;
      }

      commands.set(command.name, command);

      if (Array.isArray(command.aliases)) {
        for (const alias of command.aliases) {
          commands.set(alias, command);
        }
      }

      console.log("[BOT] comando carregado:", command.name);
    } catch (err) {
      console.error("[BOT] erro ao carregar", fullPath, err);
    }
  }
}

function loadAllCommands() {
  commands.clear();
  loadCommandsFrom(path.join(__dirname, "commands", "basic"));
  loadCommandsFrom(path.join(__dirname, "commands", "ai"));
}

client.once(Events.ClientReady, () => {
  console.log(`[BOT] online como ${client.user.tag}`);
});

client.on(Events.MessageCreate, async (message) => {
  if (!message) return;
  if (message.author?.bot) return;

  const uniqueCommands = new Set(commands.values());
  for (const command of uniqueCommands) {
    if (typeof command.onMessage === "function") {
      try {
        await command.onMessage(message, client, { OWNER_ID, PREFIX });
      } catch (err) {
        console.error("[BOT] erro em onMessage do comando:", command.name, err);
      }
    }
  }

  const content = message.content || "";
  if (!content.startsWith(PREFIX)) return;

  const raw = content.slice(PREFIX.length).trim();
  if (!raw) return;

  const parts = raw.split(/\s+/);
  const name = (parts.shift() || "").toLowerCase();
  const args = parts;

  const command = commands.get(name);
  if (!command) return;

  try {
    await command.execute(message, args, client, { OWNER_ID, PREFIX });
  } catch (err) {
    console.error("[BOT] erro executando comando:", name, err);
    await message.channel.send("Erro ao executar comando.").catch(() => null);
  }
});

loadAllCommands();

client.login(TOKEN).catch((err) => {
  console.error("[BOT] falha ao logar:", err);
});