@echo off
cd /d "%~dp0"
call venv\Scripts\activate
python super_menu_nagi.py