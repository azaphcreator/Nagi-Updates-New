from __future__ import annotations

import getpass
import json
import math
import os
import platform
import shutil
import socket
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path
from typing import Optional
from menu_discord_admin import handle_local_bot_chat
from nagi_updater import check_update, download_update, install_update

from menu_discord_admin import (
    generate_command_from_blueprint,
    start_bot_process,
    stop_bot_process,
    restart_bot_process,
    bot_status_text,
)

import customtkinter as ctk
import psutil
import requests
from dotenv import load_dotenv
from PIL import Image, ImageOps

import winsound


def play_ui_sound(name):
    try:
        sound_path = ROOT / "assets" / "sounds" / f"{name}.wav"

        if not sound_path.exists():
            print(f"[UI SOUND] arquivo não encontrado: {sound_path}")
            return

        winsound.PlaySound(
            str(sound_path),
            winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_NODEFAULT,
        )

    except Exception as e:
        print("Som UI erro:", e)


def stop_ui_sound():
    try:
        winsound.PlaySound(None, 0)
    except Exception as e:
        print("Parar som UI erro:", e)


def play_typing_loop():
    try:
        sound_path = ROOT / "assets" / "sounds" / "typing.wav"

        if not sound_path.exists():
            print(f"[UI SOUND] arquivo não encontrado: {sound_path}")
            return

        winsound.PlaySound(
            str(sound_path),
            winsound.SND_FILENAME
            | winsound.SND_ASYNC
            | winsound.SND_LOOP
            | winsound.SND_NODEFAULT,
        )

    except Exception as e:
        print("Typing sound erro:", e)


# =========================================================
# PATHS / IMPORTS DO PROJETO
# =========================================================
ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
DATA_DIR = ROOT / "data"
LOGS_DIR = ROOT / "logs"

DATA_DIR.mkdir(exist_ok=True)
LOGS_DIR.mkdir(exist_ok=True)

if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from nagi.config import get_settings
from nagi.last_pix_state import load_last_pix, save_last_pix
from nagi.link_pages import generate_pix_page_locked, generate_unlock_code
from nagi.pix_parser import parse_pix_emv

# =========================================================
# ENV
# =========================================================
load_dotenv()

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

PID_FILE = ROOT / "nagi_pid.txt"
RUN_BOT_FILE = ROOT / "run_bot.py"

CHAT_WEBHOOK_URL = (os.getenv("NAGI_CHAT_WEBHOOK_URL") or "").strip()
CHAT_WEBHOOK_TOKEN = (os.getenv("NAGI_CHAT_WEBHOOK_TOKEN") or "").strip()

# =========================================================
# BOT EXTERNO: RPN BOT
# =========================================================
RPN_BOT_DIR = Path(os.getenv("RPN_BOT_DIR") or r"C:\Users\RPN\Desktop\RPN BOT")
RPN_BOT_PID_FILE = DATA_DIR / "rpn_bot_pid.txt"
RPN_BOT_LOG_FILE = LOGS_DIR / "rpn_bot_external.log"

# =========================================================
# CONTAS DEMO
# =========================================================
ACCOUNTS = {
    "azaphsilva": {
        "password": "101010Azaph!",
        "display_name": "Proxy Azaph",
        "profile_key": "azaphsilva",
        "bangboo_image": ROOT / "assets" / "bangboo_azaph.png",
    },
    "maira": {
        "password": "101215",
        "display_name": "Maira",
        "profile_key": "maira",
        "bangboo_image": ROOT / "assets" / "bangboo_maira.png",
    },
}

CHAT_IA_ACCOUNTS = {
    "bangboonagi": {
        "password": "101010Nagi!",
        "role": "admin",
        "display_name": "Bangboo Nagi Admin",
    },
    "usuario": {
        "password": "101215",
        "role": "user",
        "display_name": "Usuário",
    },
}

# =========================================================
# THEMES
# =========================================================
THEMES = {
    "azaph": {
        "BG": "#121110",
        "BG_SOFT": "#1A1817",
        "CARD": "#23201E",
        "CARD_2": "#2A2624",
        "CARD_3": "#171513",
        "TEXT": "#F3EEE6",
        "TEXT_SOFT": "#D8CFC3",
        "MUTED": "#B4A89A",
        "ACCENT": "#F08A2E",
        "ACCENT_HOVER": "#FF9B41",
        "ACCENT_SOFT": "#5A3420",
        "LIME": "#D7FF2F",
        "SUCCESS": "#58E0A1",
        "ERROR": "#FF6A6A",
        "BORDER": "#3A322E",
        "TAG_TEXT": "#17110A",
    },
    "maira": {
        "BG": "#140F14",
        "BG_SOFT": "#1D1620",
        "CARD": "#271E29",
        "CARD_2": "#302433",
        "CARD_3": "#181219",
        "TEXT": "#FFF0FA",
        "TEXT_SOFT": "#E9D3E6",
        "MUTED": "#C9AFC4",
        "ACCENT": "#F06BB8",
        "ACCENT_HOVER": "#FF8ECC",
        "ACCENT_SOFT": "#5D2B4E",
        "LIME": "#FFB6E3",
        "SUCCESS": "#6BE0B0",
        "ERROR": "#FF808C",
        "BORDER": "#443041",
        "TAG_TEXT": "#2A1022",
    },
}

# =========================================================
# SETTINGS DO NAGI
# =========================================================
try:
    SETTINGS = get_settings()
    SETTINGS_ERROR = ""
except Exception as e:
    SETTINGS = None
    SETTINGS_ERROR = str(e)


# =========================================================
# HELPERS
# =========================================================
def read_pid(pid_file: Path) -> Optional[int]:
    try:
        return int(pid_file.read_text(encoding="utf-8").strip())
    except Exception:
        return None


def write_pid(pid_file: Path, pid: int):
    pid_file.parent.mkdir(parents=True, exist_ok=True)
    pid_file.write_text(str(pid), encoding="utf-8")


def process_exists(pid: int) -> bool:
    try:
        p = psutil.Process(pid)
        return p.is_running() and p.status() != psutil.STATUS_ZOMBIE
    except Exception:
        return False


def kill_pid_tree(pid: int) -> bool:
    try:
        if os.name == "nt":
            result = subprocess.run(
                ["taskkill", "/PID", str(pid), "/T", "/F"],
                capture_output=True,
                text=True,
                timeout=12,
            )
            return result.returncode == 0

        proc = psutil.Process(pid)
        children = proc.children(recursive=True)
        for child in children:
            try:
                child.terminate()
            except Exception:
                pass
        _, alive = psutil.wait_procs(children, timeout=3)
        for p in alive:
            try:
                p.kill()
            except Exception:
                pass
        proc.terminate()
        try:
            proc.wait(timeout=4)
        except Exception:
            proc.kill()
        return True
    except Exception:
        return False


def format_brl_value(raw: str) -> Optional[str]:
    import re

    s = (raw or "").strip()
    if not s:
        return None

    s = s.replace("R$", "").replace(" ", "")
    s = re.sub(r"[^0-9\.,]", "", s)

    if not s:
        return None

    if "," in s:
        normalized = s.replace(".", "").replace(",", ".")
    else:
        normalized = s

    try:
        value = float(normalized)
    except Exception:
        return None

    inteiro, frac = f"{value:.2f}".split(".")
    return f"R$ {inteiro},{frac}"


def normalize_origin(raw: str) -> Optional[str]:
    text = (raw or "").strip().lower()
    if text == "rpn":
        return "RPN"
    if text == "hotmart":
        return "Hotmart"
    return None



def get_machine_fingerprint() -> dict:
    try:
        mac = ":".join(
            f"{(uuid.getnode() >> ele) & 0xff:02x}" for ele in range(40, -8, -8)
        )
    except Exception:
        mac = "unknown"

    return {
        "hostname": socket.gethostname(),
        "os": platform.system(),
        "os_version": platform.version(),
        "platform": platform.platform(),
        "processor": platform.processor(),
        "username_pc": getpass.getuser(),
        "python_version": platform.python_version(),
        "mac_address": mac,
    }


def tail_file(path: Path, max_lines: int = 80) -> str:
    if not path.exists():
        return "Log ainda não existe."

    try:
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()
        lines = lines[-max_lines:]
        return "".join(lines).strip() or "(log vazio)"
    except Exception as e:
        return f"Erro ao ler log: {e}"


def call_n8n(payload: dict) -> tuple[bool, str]:
    if SETTINGS is None:
        return False, f"Configuração inválida: {SETTINGS_ERROR}"

    nagi_webhook_url = getattr(SETTINGS, "nagi_webhook_url", None)
    nagi_webhook_token = getattr(SETTINGS, "nagi_webhook_token", None)
    nagi_webhook_timeout = getattr(SETTINGS, "nagi_webhook_timeout", 30)

    if not nagi_webhook_url:
        return False, "NAGI_WEBHOOK_URL não configurado no .env"

    headers = {"Content-Type": "application/json"}
    if nagi_webhook_token:
        headers["X-Nagi-Token"] = nagi_webhook_token

    try:
        resp = requests.post(
            nagi_webhook_url,
            json=payload,
            headers=headers,
            timeout=nagi_webhook_timeout,
        )

        content_type = (resp.headers.get("Content-Type") or "").lower()
        if "application/json" in content_type:
            data = resp.json()
        else:
            data = {"reply": resp.text}

        if resp.status_code >= 400:
            msg = (
                data.get("error")
                or data.get("message")
                or data.get("reply")
                or f"status {resp.status_code}"
            )
            return False, f"Erro {resp.status_code}: {msg}"

        return True, str(data.get("reply") or data.get("message") or "OK")
    except Exception as e:
        return False, f"Erro ao chamar webhook: {e}"


def call_chat_webhook(message: str, user_session: dict) -> tuple[bool, str]:
    if not CHAT_WEBHOOK_URL:
        return False, "NAGI_CHAT_WEBHOOK_URL não configurado no .env"

    headers = {"Content-Type": "application/json"}
    if CHAT_WEBHOOK_TOKEN:
        headers["X-Nagi-Token"] = CHAT_WEBHOOK_TOKEN

    payload = {
        "source": "nagi_super_menu",
        "message": message,
        "timestamp": int(time.time()),
        "auth_user": user_session["username"],
        "display_name": user_session["display_name"],
        "profile_key": user_session["profile_key"],
        "machine": user_session["machine_info"],
    }

    try:
        resp = requests.post(
            CHAT_WEBHOOK_URL, json=payload, headers=headers, timeout=45
        )

        content_type = (resp.headers.get("Content-Type") or "").lower()
        if "application/json" in content_type:
            data = resp.json()
        else:
            data = {"reply": resp.text}

        if resp.status_code >= 400:
            return False, str(
                data.get("error")
                or data.get("message")
                or data.get("reply")
                or f"Erro {resp.status_code}"
            )

        return True, str(data.get("reply") or data.get("message") or "Sem resposta")
    except Exception as e:
        return False, f"Erro no chat webhook: {e}"


# =========================================================
# SERVIÇO PRINCIPAL
# =========================================================
class NagiDesktopService:
    def __init__(self):
        self.proc: Optional[subprocess.Popen] = None

    def bot_status(self) -> dict:
        pid = read_pid(PID_FILE)
        running = bool(pid and process_exists(pid))
        return {
            "running": running,
            "pid": pid if running else None,
            "python": sys.executable,
            "run_file": str(RUN_BOT_FILE),
        }

    def start_bot(self) -> tuple[bool, str]:
        status = self.bot_status()
        if status["running"]:
            return True, f"Nagi já está rodando. PID: {status['pid']}"

        if not RUN_BOT_FILE.exists():
            return False, "run_bot.py não encontrado."

        try:
            creationflags = 0
            if os.name == "nt":
                creationflags = subprocess.CREATE_NEW_PROCESS_GROUP

            self.proc = subprocess.Popen(
                [sys.executable, str(RUN_BOT_FILE)],
                cwd=str(ROOT),
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
                shell=False,
                creationflags=creationflags,
            )

            time.sleep(2.2)
            status = self.bot_status()

            if status["running"]:
                return True, f"Nagi iniciado com sucesso. PID: {status['pid']}"

            return False, "O processo foi iniciado, mas o Nagi não permaneceu ativo."
        except Exception as e:
            return False, f"Erro ao iniciar Nagi: {e}"

    def stop_bot(self) -> tuple[bool, str]:
        pid = read_pid(PID_FILE)
        if not pid:
            return True, "Nagi já está desligado."

        if not process_exists(pid):
            try:
                PID_FILE.unlink(missing_ok=True)
            except Exception:
                pass
            return True, "PID antigo removido. Nagi não estava rodando."

        ok = kill_pid_tree(pid)

        try:
            time.sleep(1.2)
            if not process_exists(pid):
                PID_FILE.unlink(missing_ok=True)
        except Exception:
            pass

        if ok:
            return True, f"Nagi desligado por completo. PID encerrado: {pid}"
        return False, f"Não consegui encerrar totalmente o PID {pid}"

    def restart_bot(self) -> tuple[bool, str]:
        stop_ok, stop_msg = self.stop_bot()
        time.sleep(1.4)
        start_ok, start_msg = self.start_bot()
        return start_ok, f"{stop_msg}\n{start_msg}"

    def get_last_pix(self) -> tuple[bool, str]:
        last = load_last_pix()
        if not last:
            return False, "Nenhum PIX recente salvo."

        return True, (
            f"Cliente: {last.get('customer') or '-'}\n"
            f"Origem: {last.get('origin') or '-'}\n"
            f"Valor: {last.get('amount') or '(não definido)'}\n"
            f"Código: {last.get('unlock_code') or '-'}\n"
            f"Arquivo: {last.get('file_name') or '-'}"
        )

    def create_pix(
        self,
        customer: str,
        unlock_code: str,
        origin: str,
        amount_raw: str,
        pix_code: str,
    ) -> tuple[bool, str]:
        customer = (customer or "").strip()
        unlock_code = (unlock_code or "").strip().lower()
        origin = normalize_origin(origin)
        amount_raw = (amount_raw or "").strip()
        pix_code = (pix_code or "").strip()

        if not customer:
            return False, "Nome vazio."

        if not unlock_code:
            unlock_code = generate_unlock_code(8)

        if len(unlock_code) < 2:
            return False, "Código muito curto."

        if not origin:
            return False, "Origem inválida. Use RPN ou Hotmart."

        if not pix_code:
            return False, "PIX vazio."

        amount_display = format_brl_value(amount_raw) if amount_raw else None
        if amount_display is None:
            try:
                info = parse_pix_emv(pix_code)
                amount_display = (
                    format_brl_value(getattr(info, "amount", None))
                    if getattr(info, "amount", None)
                    else None
                )
            except Exception:
                amount_display = None

        try:
            page = generate_pix_page_locked(
                pix_code=pix_code,
                customer=customer,
                unlock_code=unlock_code,
                amount_display=amount_display,
                company_fixed="RPN",
                title="Copiar Pix",
            )
        except Exception as e:
            return False, f"Erro ao gerar HTML: {e}"

        save_last_pix(
            {
                "customer": customer,
                "origin": origin,
                "unlock_code": page.unlock_code,
                "pix_code": pix_code,
                "amount": amount_display,
                "file_name": page.file_name,
                "file_path": page.file_path,
                "company_fixed": "RPN",
                "title": "Copiar Pix",
            }
        )

        return True, (
            "PIX criado com sucesso.\n\n"
            f"Cliente: {customer}\n"
            f"Origem: {origin}\n"
            f"Valor: {amount_display or '(não definido)'}\n"
            f"Código de liberação: {page.unlock_code}\n"
            f"Arquivo: {page.file_name}\n"
            f"Caminho: {page.file_path}"
        )

    def publish_last_pix(self, checkout_label: str) -> tuple[bool, str]:
        checkout_label = (checkout_label or "").strip().lower()

        if checkout_label in ("1", "checkout 1", "checkout_1"):
            target_site_key = "checkout_1"
            target_site_label = "Checkout 1"
        elif checkout_label in ("2", "checkout 2", "checkout_2"):
            target_site_key = "checkout_2"
            target_site_label = "Checkout 2"
        else:
            return False, "Destino inválido. Use checkout 1 ou checkout 2."

        last_pix = load_last_pix()
        if not last_pix:
            return False, "Nenhum PIX recente salvo."

        payload = {
            "source": "nagi_super_menu",
            "type": "publish_checkout",
            "target_site_key": target_site_key,
            "target_site_label": target_site_label,
            "customer": last_pix.get("customer"),
            "origin": last_pix.get("origin"),
            "unlock_code": last_pix.get("unlock_code"),
            "pix_code": last_pix.get("pix_code"),
            "amount": last_pix.get("amount"),
            "file_name": last_pix.get("file_name"),
            "file_path": last_pix.get("file_path"),
            "message": f"Publicar {target_site_label}",
        }
        return call_n8n(payload)

    def clear_cache(self) -> tuple[bool, str]:
        return call_n8n(
            {
                "source": "nagi_super_menu",
                "type": "clear_wordpress_cache",
                "message": "!limparcache",
                "raw": "!limparcache",
            }
        )

    def planilha(self) -> tuple[bool, str]:
        return call_n8n(
            {
                "source": "nagi_super_menu",
                "type": "planilha_list",
                "message": "!planilha",
                "raw": "!planilha",
            }
        )

    def pendentes(self) -> tuple[bool, str]:
        return call_n8n(
            {
                "source": "nagi_super_menu",
                "type": "planilha_pendentes",
                "message": "!pendentes",
                "raw": "!pendentes",
            }
        )

    def resumo(self) -> tuple[bool, str]:
        return call_n8n(
            {
                "source": "nagi_super_menu",
                "type": "planilha_resumo",
                "message": "!resumo",
                "raw": "!resumo",
            }
        )

    def pago(self, row_id: str) -> tuple[bool, str]:
        row_id = (row_id or "").strip()
        if not row_id:
            return False, "Informe o ID."

        return call_n8n(
            {
                "source": "nagi_super_menu",
                "type": "marcar_pago",
                "row_id": row_id,
                "message": f"!pago {row_id}",
                "raw": f"!pago {row_id}",
            }
        )

    def _owner_allowed(self, controller_username: str) -> bool:
        return (controller_username or "").strip().lower() == "azaphsilva"

    def _resolve_rpn_bot_command(self) -> tuple[bool, list[str], str]:
        if not RPN_BOT_DIR.exists():
            return False, [], f"Pasta do RPN BOT não encontrada: {RPN_BOT_DIR}"

        npm_cmd = shutil.which("npm.cmd") or shutil.which("npm")
        node_cmd = shutil.which("node")

        package_json = RPN_BOT_DIR / "package.json"
        index_js = RPN_BOT_DIR / "index.js"

        scripts = {}
        if package_json.exists():
            try:
                data = json.loads(package_json.read_text(encoding="utf-8"))
                scripts = data.get("scripts") or {}
            except Exception:
                scripts = {}

        if npm_cmd and "start" in scripts:
            return True, [npm_cmd, "run", "start"], "npm run start"

        if npm_cmd and package_json.exists():
            return True, [npm_cmd, "start"], "npm start"

        if node_cmd and index_js.exists():
            return True, [node_cmd, str(index_js)], "node index.js"

        return (
            False,
            [],
            (
                "Não consegui definir como iniciar o RPN BOT. "
                "Garanta que exista package.json com script start ou index.js, "
                "e que Node/NPM estejam instalados."
            ),
        )

    def rpn_bot_status(self) -> dict:
        pid = read_pid(RPN_BOT_PID_FILE)
        running = bool(pid and process_exists(pid))

        ok, cmd, mode = self._resolve_rpn_bot_command()
        return {
            "running": running,
            "pid": pid if running else None,
            "folder": str(RPN_BOT_DIR),
            "log_file": str(RPN_BOT_LOG_FILE),
            "command_ok": ok,
            "command": " ".join(cmd) if cmd else "-",
            "mode": mode if ok else "-",
        }

    def start_rpn_bot(self, controller_username: str) -> tuple[bool, str]:
        if not self._owner_allowed(controller_username):
            return False, "Acesso negado. Somente Azaph pode controlar o RPN BOT."

        status = self.rpn_bot_status()
        if status["running"]:
            return True, f"RPN BOT já está rodando. PID: {status['pid']}"

        ok_cmd, cmd, mode = self._resolve_rpn_bot_command()
        if not ok_cmd:
            return False, mode

        try:
            env = os.environ.copy()
            creationflags = 0
            if os.name == "nt":
                creationflags = subprocess.CREATE_NEW_PROCESS_GROUP

            RPN_BOT_LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
            log_handle = open(RPN_BOT_LOG_FILE, "a", encoding="utf-8", errors="ignore")
            log_handle.write(
                f"\n\n===== START {time.strftime('%Y-%m-%d %H:%M:%S')} | {mode} =====\n"
            )
            log_handle.flush()

            proc = subprocess.Popen(
                cmd,
                cwd=str(RPN_BOT_DIR),
                stdout=log_handle,
                stderr=log_handle,
                stdin=subprocess.DEVNULL,
                creationflags=creationflags,
                env=env,
            )

            write_pid(RPN_BOT_PID_FILE, proc.pid)
            time.sleep(2.0)

            if process_exists(proc.pid):
                return True, (
                    "RPN BOT iniciado com sucesso.\n"
                    f"PID: {proc.pid}\n"
                    f"Modo: {mode}\n"
                    f"Pasta: {RPN_BOT_DIR}\n"
                    f"Log: {RPN_BOT_LOG_FILE}"
                )

            return False, (
                "O processo foi iniciado, mas não permaneceu ativo.\n"
                f"Veja o log: {RPN_BOT_LOG_FILE}"
            )
        except Exception as e:
            return False, f"Erro ao iniciar RPN BOT: {e}"

    def stop_rpn_bot(self, controller_username: str) -> tuple[bool, str]:
        if not self._owner_allowed(controller_username):
            return False, "Acesso negado. Somente Azaph pode controlar o RPN BOT."

        pid = read_pid(RPN_BOT_PID_FILE)
        if not pid:
            return True, "RPN BOT já está desligado."

        if not process_exists(pid):
            try:
                RPN_BOT_PID_FILE.unlink(missing_ok=True)
            except Exception:
                pass
            return True, "PID antigo removido. RPN BOT não estava rodando."

        ok = kill_pid_tree(pid)

        try:
            time.sleep(1.0)
            if not process_exists(pid):
                RPN_BOT_PID_FILE.unlink(missing_ok=True)
        except Exception:
            pass

        if ok:
            return True, f"RPN BOT desligado por completo. PID encerrado: {pid}"
        return False, f"Não consegui encerrar totalmente o PID {pid}"

    def restart_rpn_bot(self, controller_username: str) -> tuple[bool, str]:
        stop_ok, stop_msg = self.stop_rpn_bot(controller_username)
        time.sleep(1.2)
        start_ok, start_msg = self.start_rpn_bot(controller_username)
        return start_ok, f"{stop_msg}\n{start_msg}"

    def get_rpn_bot_log_tail(
        self, controller_username: str, max_lines: int = 80
    ) -> tuple[bool, str]:
        if not self._owner_allowed(controller_username):
            return False, "Acesso negado. Somente Azaph pode controlar o RPN BOT."

        text = tail_file(RPN_BOT_LOG_FILE, max_lines=max_lines)
        return True, (
            f"RPN BOT LOG ({max_lines} últimas linhas)\n"
            f"Arquivo: {RPN_BOT_LOG_FILE}\n\n"
            f"{text}"
        )


# =========================================================
# APP PRINCIPAL
# =========================================================
class NagiApp(ctk.CTk):
    MAIRA_DECOR = ". ˖  ꒰𑁬 ♡ ໒꒱  ˖ ."

    def update_nagi(self):

        try:

            print("[NAGI] Baixando atualização...")

            download_update()

            print("[NAGI] Instalando atualização...")

            install_update()

            print("[NAGI] Reiniciando Nagi...")

            os.execv(sys.executable, ["python"] + sys.argv)

        except Exception as e:
            print(f"[NAGI] erro ao atualizar: {e}")

    def show_update_popup(self, version):

        popup = ctk.CTkToplevel(self)
        popup.title("Atualização disponível")
        popup.geometry("420x220")

        frame = ctk.CTkFrame(popup)
        frame.pack(fill="both", expand=True, padx=20, pady=20)

        ctk.CTkLabel(
            frame,
            text=f"Nova versão do Nagi disponível\n\nVersão {version}",
            font=ctk.CTkFont(size=16, weight="bold")
        ).pack(pady=15)

        ctk.CTkButton(
            frame,
            text="Atualizar agora",
            command=self.update_nagi
        ).pack(pady=10)

        ctk.CTkButton(
            frame,
            text="Depois",
            command=popup.destroy
        ).pack()

    def check_updates_ui(self):
        try:
            update, version = check_update()

            if update:
                self.show_update_popup(version)

        except Exception as e:
            print(f"[NAGI] erro ao verificar update: {e}")

    def command_center_start_bot(self):
        if not self.is_azaph():
            self.log("Acesso negado para iniciar o bot.")
            return

        ok, msg = start_bot_process()
        self.log(msg)
        self.refresh_bot_control_status()

    def command_center_stop_bot(self):
        if not self.is_azaph():
            self.log("Acesso negado para parar o bot.")
            return

        ok, msg = stop_bot_process()
        self.log(msg)
        self.refresh_bot_control_status()

    def command_center_restart_bot(self):
        if not self.is_azaph():
            self.log("Acesso negado para reiniciar o bot.")
            return

        ok, msg = restart_bot_process()
        self.log(msg)
        self.refresh_bot_control_status()

    def command_center_show_bot_status(self):
        if not self.is_azaph():
            self.log("Acesso negado para consultar status do bot.")
            return

        msg = bot_status_text()
        self.log(msg)
        self.refresh_bot_control_status()

    def refresh_bot_control_status(self):
        if (
            not hasattr(self, "commands_bot_status_label")
            or self.commands_bot_status_label is None
        ):
            return

        try:
            msg = bot_status_text()
            self.commands_bot_status_label.configure(text=msg)
        except Exception as e:
            self.commands_bot_status_label.configure(
                text=f"Erro ao consultar status: {e}"
            )

    def toggle_command_enabled(self, command_name: str):

        if not self.is_azaph():
            self.log("Acesso negado.")
            return

        bp_path = self._commands_blueprints_dir() / f"{command_name}.json"

        if not bp_path.exists():
            self.log(f"Blueprint não encontrado: {bp_path}")
            return

        try:
            data = json.loads(bp_path.read_text(encoding="utf-8"))

            current = bool(data.get("enabled", True))
            data["enabled"] = not current

            bp_path.write_text(
                json.dumps(data, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )

            ok, msg = generate_command_from_blueprint(command_name)

            if ok:
                status = "ativado" if data["enabled"] else "desativado"
                self.log(f"Comando !{command_name} {status}")
            else:
                self.log(msg)

            self.refresh_commands_list()

        except Exception as e:
            self.log(f"Erro ao alternar estado do comando: {e}")

    def _generate_duplicate_command_name(self, base_name: str) -> str:
        bp_dir = self._commands_blueprints_dir()
        ai_dir = self._commands_ai_dir()

        candidate = f"{base_name}_copia"
        index = 2

        while (bp_dir / f"{candidate}.json").exists() or (
            ai_dir / f"{candidate}.js"
        ).exists():
            candidate = f"{base_name}_copia{index}"
            index += 1

        return candidate

    def duplicate_command_files(self, command_name: str):
        if not self.is_azaph():
            self.log("Acesso negado para duplicar comando.")
            return

        bp_path = self._commands_blueprints_dir() / f"{command_name}.json"
        if not bp_path.exists():
            self.log(f"Blueprint não encontrado para duplicação: {bp_path}")
            return

        try:
            data = json.loads(bp_path.read_text(encoding="utf-8"))
        except Exception as e:
            self.log(f"Erro ao ler blueprint para duplicar '{command_name}': {e}")
            return

        new_name = self._generate_duplicate_command_name(command_name)
        data["command_name"] = new_name

        new_bp_path = self._commands_blueprints_dir() / f"{new_name}.json"

        try:
            new_bp_path.write_text(
                json.dumps(data, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            self.log(f"Blueprint duplicado: {new_bp_path}")

            ok, msg = generate_command_from_blueprint(new_name)
            if ok:
                self.log(f"JS duplicado/regenerado com sucesso para !{new_name}")
                self.log(msg)
            else:
                self.log(f"Erro ao regenerar JS do duplicado !{new_name}: {msg}")

            self.refresh_commands_list()

        except Exception as e:
            self.log(f"Erro ao duplicar comando '{command_name}': {e}")

    def open_blueprint_json(self, command_name: str):
        bp_path = self._commands_blueprints_dir() / f"{command_name}.json"
        if not bp_path.exists():
            self.log(f"Blueprint não encontrado: {bp_path}")
            return

        try:
            os.startfile(str(bp_path))
        except Exception as e:
            self.log(f"Erro ao abrir blueprint JSON: {e}")

    def open_blueprint_editor(self, command_name: str):
        if not self.is_azaph():
            self.log("Acesso negado ao editor de blueprint.")
            return

        bp_path = self._commands_blueprints_dir() / f"{command_name}.json"
        if not bp_path.exists():
            self.log(f"Blueprint não encontrado: {bp_path}")
            return

        try:
            data = json.loads(bp_path.read_text(encoding="utf-8"))
        except Exception as e:
            self.log(f"Erro ao ler blueprint '{command_name}': {e}")
            return

        BlueprintEditorWindow(self, command_name, bp_path, data)

    def _commands_ai_dir(self):
        return ROOT / "discord_bot" / "commands" / "ai"

    def _commands_blueprints_dir(self):
        return ROOT / "discord_bot" / "commands" / "blueprints"

    def _scan_commands_data(self):
        ai_dir = self._commands_ai_dir()
        bp_dir = self._commands_blueprints_dir()

        ai_dir.mkdir(parents=True, exist_ok=True)
        bp_dir.mkdir(parents=True, exist_ok=True)

        js_names = {p.stem for p in ai_dir.glob("*.js")}
        bp_names = {p.stem for p in bp_dir.glob("*.json")}

        all_names = sorted(js_names | bp_names)

        rows = []
        for name in all_names:
            js_path = ai_dir / f"{name}.js"
            bp_path = bp_dir / f"{name}.json"

            cmd_type = "simple"

            if bp_path.exists():
                try:
                    import json

                    data = json.loads(bp_path.read_text(encoding="utf-8"))
                    cmd_type = str(data.get("type", "blueprint")).strip() or "blueprint"
                except Exception:
                    cmd_type = "blueprint inválido"

            rows.append(
                {
                    "name": name,
                    "type": cmd_type,
                    "has_js": js_path.exists(),
                    "has_blueprint": bp_path.exists(),
                    "js_path": js_path,
                    "bp_path": bp_path,
                }
            )

        return rows

    def _build_commands_tab(self):
        container, frame = self.make_tab_container()

        top = self._panel(frame)
        self._pack_panel(top)

        ctk.CTkLabel(
            top,
            text="Centro de Comandos",
            font=ctk.CTkFont(size=self.FONT_SECTION + 2, weight="bold"),
            text_color=self.T("TEXT"),
        ).pack(anchor="w", padx=self.PAD_IN, pady=(self.PAD_IN, 6))

        bot_panel = ctk.CTkFrame(
            top,
            fg_color=self.T("CARD_2"),
            corner_radius=16,
            border_width=1,
            border_color=self.T("BORDER"),
        )
        bot_panel.pack(fill="x", padx=self.PAD_IN, pady=(0, 14))

        ctk.CTkLabel(
            bot_panel,
            text="Controle do Bot Discord",
            font=ctk.CTkFont(size=17, weight="bold"),
            text_color=self.T("TEXT"),
        ).pack(anchor="w", padx=14, pady=(12, 8))

        bot_row = ctk.CTkFrame(bot_panel, fg_color="transparent")
        bot_row.pack(fill="x", padx=14, pady=(0, 10))

        self._button_primary(
            bot_row,
            "Iniciar Bot",
            self.command_center_start_bot,
            140,
        ).pack(side="left", padx=(0, 8))

        self._button_ghost(
            bot_row,
            "Parar Bot",
            self.command_center_stop_bot,
            130,
        ).pack(side="left", padx=(0, 8))

        self._button_ghost(
            bot_row,
            "Reiniciar Bot",
            self.command_center_restart_bot,
            150,
        ).pack(side="left", padx=(0, 8))

        self._button_ghost(
            bot_row,
            "Status Bot",
            self.command_center_show_bot_status,
            130,
        ).pack(side="left")

        self.commands_bot_status_label = ctk.CTkLabel(
            bot_panel,
            text="Consultando status do bot...",
            font=ctk.CTkFont(size=self.FONT_SMALL),
            text_color=self.T("TEXT_SOFT"),
            justify="left",
            wraplength=980,
        )
        self.commands_bot_status_label.pack(anchor="w", padx=14, pady=(0, 14))

        ctk.CTkLabel(
            top,
            text="Gerenciamento dos comandos locais do bot Discord. Esta área é exclusiva do Azaph.",
            font=ctk.CTkFont(size=self.FONT_BODY),
            text_color=self.T("TEXT_SOFT"),
            justify="left",
            wraplength=1000,
        ).pack(anchor="w", padx=self.PAD_IN, pady=(0, 12))

        row = ctk.CTkFrame(top, fg_color="transparent")
        row.pack(fill="x", padx=self.PAD_IN, pady=(0, self.PAD_IN))

        self._button_primary(
            row,
            "Atualizar lista",
            self.refresh_commands_list,
            150,
        ).pack(side="left", padx=(0, 8))

        self._button_ghost(
            row,
            "Abrir pasta AI",
            lambda: self.open_in_explorer(self._commands_ai_dir()),
            150,
        ).pack(side="left", padx=(0, 8))

        self._button_ghost(
            row,
            "Abrir pasta Blueprints",
            lambda: self.open_in_explorer(self._commands_blueprints_dir()),
            190,
        ).pack(side="left")

        list_card = self._panel(frame)
        self._pack_panel(list_card, fill="both", expand=True)

        self.commands_scroll = ctk.CTkScrollableFrame(
            list_card,
            fg_color=self.T("CARD_2"),
            corner_radius=18,
            border_width=1,
            border_color=self.T("BORDER"),
        )
        self.commands_scroll.pack(
            fill="both", expand=True, padx=self.PAD_IN, pady=self.PAD_IN
        )

        self.commands_list_frame = self.commands_scroll
        self.refresh_commands_list()
        self.refresh_bot_control_status()

        return container

    def open_in_explorer(self, path: Path):
        try:
            play_ui_sound("open")
            os.startfile(str(path))
        except Exception as e:
            self.log(f"Erro ao abrir pasta: {e}")

    def delete_command_files(self, command_name: str):
        if not self.is_azaph():
            self.log("Acesso negado para excluir comando.")
            return

        ai_path = self._commands_ai_dir() / f"{command_name}.js"
        bp_path = self._commands_blueprints_dir() / f"{command_name}.json"

        removed = []

        try:
            if ai_path.exists():
                ai_path.unlink()
                removed.append(str(ai_path))

            if bp_path.exists():
                bp_path.unlink()
                removed.append(str(bp_path))

            if removed:
                self.log(f"Comando '{command_name}' removido: {removed}")
            else:
                self.log(f"Nada para remover em '{command_name}'.")

            self.refresh_commands_list()

        except Exception as e:
            self.log(f"Erro ao excluir comando '{command_name}': {e}")

    def refresh_commands_list(self):
        if not hasattr(self, "commands_list_frame") or self.commands_list_frame is None:
            return

        for child in self.commands_list_frame.winfo_children():
            child.destroy()

        rows = self._scan_commands_data()

        if not rows:
            ctk.CTkLabel(
                self.commands_list_frame,
                text="Nenhum comando encontrado.",
                font=ctk.CTkFont(size=self.FONT_BODY),
                text_color=self.T("TEXT_SOFT"),
            ).pack(anchor="w", padx=12, pady=12)
            return

        for row in rows:
            card = ctk.CTkFrame(
                self.commands_list_frame,
                fg_color=self.T("CARD_2"),
                corner_radius=16,
                border_width=1,
                border_color=self.T("BORDER"),
            )
            card.pack(fill="x", padx=8, pady=8)

            top = ctk.CTkFrame(card, fg_color="transparent")
            top.pack(fill="x", padx=14, pady=(12, 6))

            title = f"!{row['name']}"
            meta = (
                f"Tipo: {row['type']}    "
                f"JS: {'sim' if row['has_js'] else 'não'}    "
                f"Blueprint: {'sim' if row['has_blueprint'] else 'não'}"
            )

            ctk.CTkLabel(
                top,
                text=title,
                font=ctk.CTkFont(size=self.FONT_SECTION, weight="bold"),
                text_color=self.T("TEXT"),
            ).pack(anchor="w")

            ctk.CTkLabel(
                top,
                text=meta,
                font=ctk.CTkFont(size=self.FONT_SMALL),
                text_color=self.T("TEXT_SOFT"),
            ).pack(anchor="w", pady=(2, 8))

            if row["has_blueprint"]:
                ctk.CTkLabel(
                    card,
                    text=f"Blueprint: {row['bp_path']}",
                    font=ctk.CTkFont(size=self.FONT_SMALL),
                    text_color=self.T("MUTED"),
                    justify="left",
                    wraplength=980,
                ).pack(anchor="w", padx=14, pady=(0, 4))

            if row["has_js"]:
                ctk.CTkLabel(
                    card,
                    text=f"JS: {row['js_path']}",
                    font=ctk.CTkFont(size=self.FONT_SMALL),
                    text_color=self.T("MUTED"),
                    justify="left",
                    wraplength=980,
                ).pack(anchor="w", padx=14, pady=(0, 8))

            actions = ctk.CTkFrame(card, fg_color="transparent")
            actions.pack(fill="x", padx=14, pady=(0, 12))

            if row["has_blueprint"]:
                self._button_primary(
                    actions,
                    "Editar Blueprint",
                    lambda n=row["name"]: self.open_blueprint_editor(n),
                    160,
                ).pack(side="left", padx=(0, 8))

                self._button_ghost(
                    actions,
                    "Ver JSON",
                    lambda n=row["name"]: self.open_blueprint_json(n),
                    120,
                ).pack(side="left", padx=(0, 8))

                self._button_ghost(
                    actions,
                    "Duplicar",
                    lambda n=row["name"]: self.duplicate_command_files(n),
                    120,
                ).pack(side="left", padx=(0, 8))

            self._button_ghost(
                actions,
                "Abrir pasta AI",
                lambda p=self._commands_ai_dir(): self.open_in_explorer(p),
                150,
            ).pack(side="left", padx=(0, 8))

            self._button_ghost(
                actions,
                "Abrir pasta Blueprints",
                lambda p=self._commands_blueprints_dir(): self.open_in_explorer(p),
                180,
            ).pack(side="left", padx=(0, 8))

            self._button_primary(
                actions,
                "Excluir comando",
                lambda n=row["name"]: self.delete_command_files(n),
                160,
            ).pack(side="right")

            bp_path = row["bp_path"]

            try:
                bp_data = json.loads(bp_path.read_text(encoding="utf-8"))
                enabled = bool(bp_data.get("enabled", True))
            except Exception:
                enabled = True

            toggle_label = "Desativar" if enabled else "Ativar"

            self._button_ghost(
                actions,
                toggle_label,
                lambda n=row["name"]: self.toggle_command_enabled(n),
                120,
            ).pack(side="left", padx=(0, 8))

    def __init__(self):
        super().__init__()

        self.service = NagiDesktopService()
        self.user_session: Optional[dict] = None
        self.chat_ia_session: Optional[dict] = None
        self.chat_gate_frame = None
        self.chat_admin_mode = False
        self.chat_window = None
        self.chat_loading_frame = None
        self.chat_side_img = None
        self.chat_side_overlay_img = None
        self.theme = THEMES["azaph"]

        self.anim_phase = 0.0
        self.bangboo_y = 0
        self.current_tab = "dashboard"
        self.status_loop_started = False

        self.loading_frame = None
        self.login_frame = None

        self.sidebar = None
        self.main = None
        self.header = None
        self.content = None

        self.tabs = {}
        self.nav_buttons = {}

        self._setup_responsive()
        self.title("NAGI // Super Menu")
        self.protocol("WM_DELETE_WINDOW", self.close_menu)

        self.show_loading()
        play_ui_sound("startup")
        self.after(1600, self.show_login)
        self.after(2000, self.check_updates_ui)

    # -----------------------------
    # RESPONSIVO
    # -----------------------------
    def _setup_responsive(self):
        self.update_idletasks()
        self.screen_w = max(1024, self.winfo_screenwidth())
        self.screen_h = max(720, self.winfo_screenheight())

        target_w = min(1500, int(self.screen_w * 0.94))
        target_h = min(930, int(self.screen_h * 0.92))
        min_w = 1020 if self.screen_w < 1280 else 1180
        min_h = 680 if self.screen_h < 800 else 760

        self.geometry(
            f"{target_w}x{target_h}+{max(10, (self.screen_w - target_w)//2)}+{max(10, (self.screen_h - target_h)//2)}"
        )
        self.minsize(min_w, min_h)

        self.compact_mode = self.screen_h <= 800 or self.screen_w <= 1280
        self.very_compact_mode = self.screen_h <= 720 or self.screen_w <= 1152

        if self.very_compact_mode:
            self.scale = 0.82
        elif self.compact_mode:
            self.scale = 0.90
        else:
            self.scale = 1.0

        ctk.set_widget_scaling(self.scale)
        ctk.set_window_scaling(1.0)

        self.SIDEBAR_W = (
            235 if self.very_compact_mode else (255 if self.compact_mode else 300)
        )
        self.PAD = 12 if self.very_compact_mode else (14 if self.compact_mode else 18)
        self.PAD_IN = 14 if self.very_compact_mode else 18
        self.HEADER_H = (
            88 if self.very_compact_mode else (96 if self.compact_mode else 108)
        )
        self.BTN_H = 40 if self.very_compact_mode else (44 if self.compact_mode else 48)
        self.ENTRY_H = (
            38 if self.very_compact_mode else (40 if self.compact_mode else 42)
        )

        self.FONT_HERO = (
            24 if self.very_compact_mode else (27 if self.compact_mode else 30)
        )
        self.FONT_TITLE = (
            24 if self.very_compact_mode else (27 if self.compact_mode else 30)
        )
        self.FONT_SECTION = (
            20 if self.very_compact_mode else (22 if self.compact_mode else 26)
        )
        self.FONT_LABEL = 13 if self.very_compact_mode else 14
        self.FONT_SMALL = 11 if self.very_compact_mode else 12
        self.FONT_BODY = 13 if self.very_compact_mode else 14
        self.FONT_SIDE_LOGO = (
            28 if self.very_compact_mode else (30 if self.compact_mode else 34)
        )
        self.FONT_LOGIN_LOGO = 34 if self.very_compact_mode else 40
        self.FONT_LOGIN_TITLE = 26 if self.very_compact_mode else 30

        self.configure(fg_color="#101010")

    # -----------------------------
    # TEMA / PERFIL
    # -----------------------------
    def T(self, key: str) -> str:
        return self.theme[key]

    def ui_click(self):
        play_ui_sound("click")

    def with_ui_click(self, func):
        def wrapped(*args, **kwargs):
            self.ui_click()
            return func(*args, **kwargs)

        return wrapped

    def is_maira(self) -> bool:
        return bool(
            self.user_session and self.user_session.get("profile_key") == "maira"
        )

    def is_azaph(self) -> bool:
        return bool(
            self.user_session and self.user_session.get("profile_key") == "azaphsilva"
        )

    def ui_display_name(self) -> str:
        if not self.user_session:
            return ""
        base = self.user_session["display_name"]
        if self.is_maira():
            return f"{base} ♡"
        return base

    def ui_nagi_name(self) -> str:
        return "NAGI ♡" if self.is_maira() else "NAGI"

    def ui_dashboard_text(self) -> str:
        if self.is_maira():
            return f"Dashboard {self.MAIRA_DECOR}"
        return "Dashboard"

    def ui_status_text(self, status: str) -> str:
        if self.is_maira():
            return f"{status} {self.MAIRA_DECOR}"
        return status

    def apply_user_theme(self, username: str):
        profile_key = ACCOUNTS[username]["profile_key"]
        self.theme = THEMES.get(profile_key, THEMES["azaph"])
        self.configure(fg_color=self.T("BG"))

    # -----------------------------
    # BASE UI
    # -----------------------------
    def clear_screen(self):
        for child in self.winfo_children():
            child.destroy()

    def make_tab_container(self):
        container = ctk.CTkFrame(self.content, fg_color="transparent")
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        scroll = ctk.CTkScrollableFrame(
            container,
            fg_color="transparent",
            corner_radius=0,
        )
        scroll.grid(row=0, column=0, sticky="nsew")

        return container, scroll

    def show_chat_loading(self):
        if "chat" in self.tabs and self.tabs["chat"].winfo_exists():
            self.tabs["chat"].destroy()

        container, frame = self.make_tab_container()

        panel = self._panel(frame)
        self._pack_panel(panel, fill="both", expand=True)

        wrap = ctk.CTkFrame(panel, fg_color="transparent")
        wrap.pack(expand=True, fill="both", padx=self.PAD_IN, pady=self.PAD_IN)

        self.chat_loading_canvas = ctk.CTkCanvas(
            wrap,
            width=220,
            height=180,
            bg=self.T("CARD"),
            highlightthickness=0,
            bd=0,
        )
        self.chat_loading_canvas.pack(pady=(35, 12))

        self.chat_ld_outer = self.chat_loading_canvas.create_oval(
            35, 15, 185, 165, fill=self.T("CARD_2"), outline=""
        )
        self.chat_ld_inner = self.chat_loading_canvas.create_oval(
            62, 42, 158, 138, fill=self.T("ACCENT"), outline=""
        )
        self.chat_ld_core = self.chat_loading_canvas.create_oval(
            88, 68, 132, 112, fill=self.T("CARD_3"), outline=""
        )
        self.chat_ld_ring = self.chat_loading_canvas.create_oval(
            52, 32, 168, 148, outline=self.T("LIME"), width=3
        )

        ctk.CTkLabel(
            wrap,
            text="Carregando Chat IA",
            font=ctk.CTkFont(size=self.FONT_SECTION + 2, weight="bold"),
            text_color=self.T("TEXT"),
        ).pack()

        mode_text = "Modo ADMIN" if self.chat_admin_mode else "Modo Usuário"

        self.chat_loading_label = ctk.CTkLabel(
            wrap,
            text=f"Inicializando HUD... • {mode_text}",
            font=ctk.CTkFont(size=self.FONT_BODY),
            text_color=self.T("TEXT_SOFT"),
        )
        self.chat_loading_label.pack(pady=(6, 18))

        self.chat_loading_bar = ctk.CTkProgressBar(
            wrap,
            width=320,
            height=14,
            progress_color=self.T("ACCENT"),
        )
        self.chat_loading_bar.pack()
        self.chat_loading_bar.set(0)

        self.chat_loading_progress = 0.0
        self.chat_loading_frame = container
        self.tabs["chat"] = container
        self.show_tab("chat")
        self._animate_chat_loading()

        self.after(1300, self.finish_chat_loading)

    def _animate_chat_loading(self):
        if not self.chat_loading_frame or not self.chat_loading_frame.winfo_exists():
            return

        self.anim_phase += 0.18
        pulse = 1 + math.sin(self.anim_phase) * 0.08
        ring = 1 + math.sin(self.anim_phase * 1.35) * 0.12

        cx, cy = 110, 90
        r_inner = 48 * pulse
        r_ring = 58 * ring

        try:
            self.chat_loading_canvas.coords(
                self.chat_ld_inner,
                cx - r_inner,
                cy - r_inner,
                cx + r_inner,
                cy + r_inner,
            )
            self.chat_loading_canvas.coords(
                self.chat_ld_ring, cx - r_ring, cy - r_ring, cx + r_ring, cy + r_ring
            )
        except Exception:
            pass

        self.chat_loading_progress = min(1.0, self.chat_loading_progress + 0.045)
        self.chat_loading_bar.set(self.chat_loading_progress)

        if self.chat_loading_progress < 0.35:
            txt = "Preparando sessão..."
        elif self.chat_loading_progress < 0.70:
            txt = "Carregando interface..."
        else:
            txt = "Abrindo HUD do Chat IA..."

        self.chat_loading_label.configure(text=txt)
        self.after(45, self._animate_chat_loading)

    def finish_chat_loading(self):
        if "chat" in self.tabs and self.tabs["chat"].winfo_exists():
            self.tabs["chat"].destroy()

        self.tabs["chat"] = self._build_chat_hud_tab()
        self.show_tab("chat")

    def show_loading(self):
        self.clear_screen()

        frame = ctk.CTkFrame(self, fg_color="#0e0e10", corner_radius=0)
        frame.pack(fill="both", expand=True)
        self.loading_frame = frame

        relw = 0.64 if self.compact_mode else 0.42
        relh = 0.50 if self.compact_mode else 0.42

        wrap = ctk.CTkFrame(frame, fg_color="#17171b", corner_radius=24)
        wrap.place(relx=0.5, rely=0.5, anchor="center", relwidth=relw, relheight=relh)

        self.loading_canvas = ctk.CTkCanvas(
            wrap, width=220, height=180, bg="#17171b", highlightthickness=0
        )
        self.loading_canvas.pack(pady=(28, 8))

        self.ld_outer = self.loading_canvas.create_oval(
            35, 15, 185, 165, fill="#2A2A31", outline=""
        )
        self.ld_inner = self.loading_canvas.create_oval(
            62, 42, 158, 138, fill="#F08A2E", outline=""
        )
        self.ld_core = self.loading_canvas.create_oval(
            88, 68, 132, 112, fill="#101012", outline=""
        )
        self.ld_ring = self.loading_canvas.create_oval(
            52, 32, 168, 148, outline="#D7FF2F", width=3
        )

        ctk.CTkLabel(
            wrap,
            text="NAGI",
            font=ctk.CTkFont(size=self.FONT_HERO + 4, weight="bold"),
            text_color="#F3EEE6",
        ).pack()

        ctk.CTkLabel(
            wrap,
            text="Inicializando sistema Bangboo...",
            font=ctk.CTkFont(size=self.FONT_BODY),
            text_color="#C8C1B8",
        ).pack(pady=(4, 18))

        self.loading_bar = ctk.CTkProgressBar(
            wrap,
            width=300 if self.compact_mode else 320,
            height=14,
            progress_color="#F08A2E",
        )
        self.loading_bar.pack()
        self.loading_bar.set(0)

        self.loading_label = ctk.CTkLabel(
            wrap,
            text="Carregando módulos...",
            font=ctk.CTkFont(size=self.FONT_SMALL),
            text_color="#A6A6AD",
        )
        self.loading_label.pack(pady=(12, 0))

        self.loading_progress = 0.0
        self.animate_loading()

    def animate_loading(self):
        if not self.loading_frame or not self.loading_frame.winfo_exists():
            return

        self.anim_phase += 0.18
        pulse = 1 + math.sin(self.anim_phase) * 0.08
        ring = 1 + math.sin(self.anim_phase * 1.35) * 0.12

        cx, cy = 110, 90
        r_inner = 48 * pulse
        r_ring = 58 * ring

        try:
            self.loading_canvas.coords(
                self.ld_inner, cx - r_inner, cy - r_inner, cx + r_inner, cy + r_inner
            )
            self.loading_canvas.coords(
                self.ld_ring, cx - r_ring, cy - r_ring, cx + r_ring, cy + r_ring
            )
        except Exception:
            pass

        self.loading_progress = min(1.0, self.loading_progress + 0.035)
        self.loading_bar.set(self.loading_progress)

        if self.loading_progress < 0.4:
            txt = "Carregando módulos..."
        elif self.loading_progress < 0.75:
            txt = "Validando ambiente..."
        else:
            txt = "Preparando autenticação..."

        self.loading_label.configure(text=txt)
        self.after(45, self.animate_loading)

    def show_login(self):
        self.clear_screen()
        self.configure(fg_color="#121110")

        frame = ctk.CTkFrame(self, fg_color="#121110", corner_radius=0)
        frame.pack(fill="both", expand=True)
        self.login_frame = frame

        if self.compact_mode:
            main_card = ctk.CTkFrame(frame, fg_color="#121110", corner_radius=0)
            main_card.place(
                relx=0.5, rely=0.5, anchor="center", relwidth=0.92, relheight=0.88
            )

            login_card = ctk.CTkFrame(
                main_card,
                fg_color="#1B1715",
                corner_radius=20,
                border_width=1,
                border_color="#352D29",
            )
            login_card.pack(fill="both", expand=True, padx=12, pady=12)

            ctk.CTkLabel(
                login_card,
                text="NAGI",
                font=ctk.CTkFont(size=self.FONT_LOGIN_LOGO, weight="bold"),
                text_color="#F3EEE6",
            ).pack(anchor="w", padx=26, pady=(24, 4))

            ctk.CTkLabel(
                login_card,
                text="Acesso ao sistema Bangboo",
                font=ctk.CTkFont(size=self.FONT_BODY),
                text_color="#CABEB0",
            ).pack(anchor="w", padx=26, pady=(0, 12))

            ctk.CTkLabel(
                login_card,
                text="Perfis disponíveis: azaph e maira",
                font=ctk.CTkFont(size=self.FONT_SMALL),
                text_color="#D8CFC3",
            ).pack(anchor="w", padx=26, pady=(0, 14))
        else:
            left = ctk.CTkFrame(frame, fg_color="#181513", corner_radius=0)
            left.place(relx=0, rely=0, relwidth=0.44, relheight=1)

            right = ctk.CTkFrame(frame, fg_color="#0f0e0d", corner_radius=0)
            right.place(relx=0.44, rely=0, relwidth=0.56, relheight=1)

            left_bg = ctk.CTkLabel(left, text="", fg_color="#181513")
            left_bg.place(relx=0, rely=0, relwidth=1, relheight=1)
            self._load_login_left_image(left_bg)

            left_info = ctk.CTkFrame(
                left,
                fg_color="#120f0d",
                corner_radius=20,
                border_width=1,
                border_color="#3A2F27",
            )
            left_info.place(relx=0.09, rely=0.12, relwidth=0.45, relheight=0.44)

            ctk.CTkLabel(
                left_info,
                text="NAGI",
                font=ctk.CTkFont(size=self.FONT_LOGIN_LOGO + 2, weight="bold"),
                text_color="#F6EEE5",
                anchor="w",
            ).place(relx=0.08, rely=0.09, relwidth=0.84)

            ctk.CTkLabel(
                left_info,
                text="Acesso ao sistema Bangboo",
                font=ctk.CTkFont(size=self.FONT_BODY),
                text_color="#D1C1B2",
                anchor="w",
            ).place(relx=0.08, rely=0.26, relwidth=0.84)

            info_text = (
                "Perfis disponíveis nesta fase:\n\n"
                "• azaph\n"
                "• maira\n\n"
                "Azaph controla o painel completo.\n"
                "Maira usa o painel normal com estilo próprio."
            )

            ctk.CTkLabel(
                left_info,
                text=info_text,
                justify="left",
                anchor="nw",
                wraplength=220,
                font=ctk.CTkFont(size=self.FONT_BODY - 1),
                text_color="#EFE4D7",
            ).place(relx=0.08, rely=0.42, relwidth=0.84, relheight=0.46)

            main_card = right

        login_card = ctk.CTkFrame(
            main_card,
            fg_color="#1B1715",
            corner_radius=24,
            border_width=1,
            border_color="#352D29",
        )

        if self.compact_mode:
            pass
        else:
            login_card.place(
                relx=0.5, rely=0.5, anchor="center", relwidth=0.60, relheight=0.57
            )

        ctk.CTkLabel(
            login_card,
            text="Entrar",
            font=ctk.CTkFont(size=self.FONT_TITLE + 2, weight="bold"),
            text_color="#F5EDE3",
        ).pack(anchor="w", padx=28, pady=(26, 8))

        ctk.CTkLabel(
            login_card,
            text="Digite seu usuário e senha para liberar o menu.",
            font=ctk.CTkFont(size=self.FONT_SMALL),
            text_color="#D9C7B8",
        ).pack(anchor="w", padx=28, pady=(0, 22))

        self.login_user = ctk.CTkEntry(
            login_card,
            placeholder_text="Usuário",
            height=self.ENTRY_H + 4,
            corner_radius=14,
            fg_color="#2A2421",
            border_color="#40352F",
            text_color="#FFF8F1",
        )
        self.login_user.pack(fill="x", padx=28, pady=(8, 10))

        self.login_pass = ctk.CTkEntry(
            login_card,
            placeholder_text="Senha",
            show="*",
            height=self.ENTRY_H + 4,
            corner_radius=14,
            fg_color="#2A2421",
            border_color="#40352F",
            text_color="#FFF8F1",
        )
        self.login_pass.pack(fill="x", padx=28, pady=(0, 10))
        self.login_pass.bind("<Return>", lambda e: self.try_login())

        self.login_status = ctk.CTkLabel(
            login_card,
            text="",
            font=ctk.CTkFont(size=self.FONT_SMALL),
            text_color="#FF8A8A",
        )
        self.login_status.pack(anchor="w", padx=28, pady=(8, 0))

        self.login_button = ctk.CTkButton(
            login_card,
            text="Liberar Acesso",
            height=self.BTN_H + 2,
            corner_radius=14,
            fg_color="#F08A2E",
            hover_color="#FF9B41",
            text_color="#1A120B",
            font=ctk.CTkFont(size=self.FONT_LABEL, weight="bold"),
            command=self.try_login,
        )
        self.login_button.pack(fill="x", padx=28, pady=(22, 12))

        demo = "Contas Atuais >\nazaphsilva: senha controlada e segura\nmaira: 101215"
        ctk.CTkLabel(
            login_card,
            text=demo,
            justify="left",
            font=ctk.CTkFont(size=self.FONT_SMALL),
            text_color="#B7A897",
        ).pack(anchor="w", padx=28, pady=(4, 0))

    def try_login(self):
        username = self.login_user.get().strip().lower()
        password = self.login_pass.get().strip()

        account = ACCOUNTS.get(username)
        if not account or account["password"] != password:
            play_ui_sound("error")
            self.login_status.configure(text="Usuário ou senha inválidos.")
            return

        machine_info = get_machine_fingerprint()

        self.user_session = {
            "username": username,
            "display_name": account["display_name"],
            "profile_key": account["profile_key"],
            "bangboo_image": account["bangboo_image"],
            "machine_info": machine_info,
            "login_at": int(time.time()),
        }

        play_ui_sound("login")

        self.apply_user_theme(username)
        self.build_main_ui()

    # -----------------------------
    # MAIN UI
    # -----------------------------
    def build_main_ui(self):
        self.clear_screen()
        self.configure(fg_color=self.T("BG"))

        self.grid_columnconfigure(0, weight=0)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self.tabs = {}
        self.nav_buttons = {}

        self.sidebar = ctk.CTkFrame(
            self, width=self.SIDEBAR_W, corner_radius=0, fg_color=self.T("BG_SOFT")
        )
        self.sidebar.grid(row=0, column=0, sticky="nsew")
        self.sidebar.grid_rowconfigure(40, weight=1)

        self.main = ctk.CTkFrame(self, corner_radius=0, fg_color=self.T("BG"))
        self.main.grid(row=0, column=1, sticky="nsew")
        self.main.grid_columnconfigure(0, weight=1)
        self.main.grid_rowconfigure(1, weight=1)

        self._build_sidebar()
        self._build_header()
        self._build_content()
        self._start_loops()

    def _build_sidebar(self):
        ctk.CTkLabel(
            self.sidebar,
            text=self.ui_nagi_name(),
            font=ctk.CTkFont(size=self.FONT_SIDE_LOGO, weight="bold"),
            text_color=self.T("TEXT"),
        ).grid(row=0, column=0, padx=18, pady=(18, 2), sticky="w")

        ctk.CTkLabel(
            self.sidebar,
            text=f"Perfil: {self.ui_display_name()}",
            font=ctk.CTkFont(size=self.FONT_LABEL),
            text_color=self.T("MUTED"),
        ).grid(row=1, column=0, padx=18, pady=(0, 8), sticky="w")

        box_w = 190 if self.very_compact_mode else (210 if self.compact_mode else 240)
        box_h = 170 if self.very_compact_mode else (190 if self.compact_mode else 220)

        self.bangboo_wrap = ctk.CTkFrame(
            self.sidebar,
            fg_color=self.T("CARD"),
            corner_radius=18,
            border_width=1,
            border_color=self.T("BORDER"),
            width=box_w,
            height=box_h,
        )
        self.bangboo_wrap.grid(row=2, column=0, padx=16, pady=(8, 14), sticky="ew")
        self.bangboo_wrap.grid_propagate(False)

        self.bangboo_label = ctk.CTkLabel(self.bangboo_wrap, text="")
        self.bangboo_label.place(relx=0.5, rely=0.52, anchor="center")
        self._load_bangboo_image()

        nav_items = [
            (self.ui_dashboard_text(), "dashboard"),
            ("PIX / Checkout", "pix"),
            ("Planilha", "sheet"),
        ]

        if self.is_azaph():
            nav_items.append(("Comandos", "commands"))

        nav_items.append(("Console", "console"))

        row = 3
        for text, key in nav_items:
            btn = ctk.CTkButton(
                self.sidebar,
                text=text,
                height=self.BTN_H,
                corner_radius=12,
                fg_color=self.T("ACCENT_SOFT"),
                hover_color=self.T("ACCENT"),
                text_color=self.T("TEXT"),
                border_width=1,
                border_color=self.T("BORDER"),
                font=ctk.CTkFont(size=self.FONT_LABEL, weight="bold"),
                command=self.with_ui_click(lambda k=key: self.show_tab(k)),
            )
            btn.grid(row=row, column=0, padx=14, pady=6, sticky="ew")
            self.nav_buttons[key] = btn
            row += 1

        self.chat_window_btn = ctk.CTkButton(
            self.sidebar,
            text="Chat IA",
            height=self.BTN_H,
            corner_radius=12,
            fg_color=self.T("ACCENT_SOFT"),
            hover_color=self.T("ACCENT"),
            text_color=self.T("TEXT"),
            border_width=1,
            border_color=self.T("BORDER"),
            font=ctk.CTkFont(size=self.FONT_LABEL, weight="bold"),
            command=self.with_ui_click(self.open_chat_ia_window),
        )
        self.chat_window_btn.grid(row=row, column=0, padx=14, pady=6, sticky="ew")
        row += 1

        self.side_status = ctk.CTkLabel(
            self.sidebar,
            text="● verificando...",
            font=ctk.CTkFont(size=self.FONT_LABEL, weight="bold"),
            text_color=self.T("MUTED"),
        )
        self.side_status.grid(row=41, column=0, padx=18, pady=(8, 4), sticky="w")

        self.sidebar_back_btn = self._button_ghost(
            self.sidebar, "Voltar ao Login", self.logout_to_login
        )
        self.sidebar_back_btn.grid(row=42, column=0, padx=14, pady=(2, 6), sticky="ew")

        self.sidebar_close_btn = ctk.CTkButton(
            self.sidebar,
            text="Fechar Menu",
            command=self.close_menu,
            height=self.BTN_H,
            corner_radius=12,
            fg_color=self.T("CARD_2"),
            hover_color=self.T("ERROR"),
            text_color=self.T("TEXT"),
            border_width=1,
            border_color=self.T("BORDER"),
            font=ctk.CTkFont(size=self.FONT_LABEL, weight="bold"),
        )
        self.sidebar_close_btn.grid(
            row=43, column=0, padx=14, pady=(0, 14), sticky="ew"
        )

    def _load_bangboo_image(self):
        img_path = self.user_session["bangboo_image"]
        if img_path.exists():
            try:
                img = Image.open(img_path).convert("RGBA")
                max_size = (
                    (120, 120)
                    if self.very_compact_mode
                    else ((145, 145) if self.compact_mode else (180, 180))
                )
                img.thumbnail(max_size)
                self.bangboo_img = ctk.CTkImage(
                    light_image=img, dark_image=img, size=img.size
                )
                self.bangboo_label.configure(image=self.bangboo_img, text="")
            except Exception:
                self.bangboo_label.configure(text="Bangboo", text_color=self.T("TEXT"))
        else:
            self.bangboo_label.configure(text="Bangboo", text_color=self.T("TEXT"))

    def _load_login_left_image(self, label_widget):
        img_path = ROOT / "assets" / "login_side.png"

        if not img_path.exists():
            print("[LOGIN IMG] arquivo não encontrado:", img_path)
            return False

        try:
            target_size = (900, 1200)
            img = Image.open(img_path).convert("RGBA")
            img = ImageOps.fit(img, target_size, Image.LANCZOS)

            # overlay escuro
            overlay = Image.new("RGBA", img.size, (0, 0, 0, 145))
            img = Image.alpha_composite(img, overlay)

            self.login_left_img = ctk.CTkImage(
                light_image=img,
                dark_image=img,
                size=target_size,
            )
            label_widget.configure(image=self.login_left_img, text="")
            print("[LOGIN IMG] imagem carregada com sucesso")
            return True
        except Exception as e:
            print("[LOGIN IMG] erro ao carregar:", e)
            return False

    def _build_header(self):
        self.header = ctk.CTkFrame(
            self.main,
            fg_color=self.T("CARD"),
            corner_radius=18,
            border_width=1,
            border_color=self.T("BORDER"),
            height=self.HEADER_H,
        )
        self.header.grid(row=0, column=0, sticky="ew", padx=self.PAD, pady=self.PAD)
        self.header.grid_columnconfigure(1, weight=1)

        left = ctk.CTkFrame(self.header, fg_color="transparent")
        left.grid(row=0, column=0, sticky="w", padx=self.PAD_IN, pady=self.PAD_IN)

        self.page_title = ctk.CTkLabel(
            left,
            text=self.ui_dashboard_text(),
            font=ctk.CTkFont(size=self.FONT_TITLE, weight="bold"),
            text_color=self.T("TEXT"),
        )
        self.page_title.pack(anchor="w")

        self.page_subtitle = ctk.CTkLabel(
            left,
            text="Controle geral do Nagi",
            font=ctk.CTkFont(size=self.FONT_SMALL),
            text_color=self.T("TEXT_SOFT"),
        )
        self.page_subtitle.pack(anchor="w", pady=(2, 0))

        right = ctk.CTkFrame(self.header, fg_color="transparent")
        right.grid(row=0, column=1, sticky="e", padx=self.PAD_IN, pady=self.PAD_IN)

        top_actions = ctk.CTkFrame(right, fg_color="transparent")
        top_actions.pack(anchor="e", pady=(0, 6))

        self.header_back_btn = self._button_ghost(
            top_actions,
            "Voltar",
            self.logout_to_login,
            110 if self.compact_mode else 150,
        )
        self.header_back_btn.pack(side="left", padx=(0, 8))

        self.header_close_btn = ctk.CTkButton(
            top_actions,
            text="Fechar",
            command=self.close_menu,
            width=90 if self.compact_mode else 120,
            height=self.BTN_H,
            corner_radius=12,
            fg_color=self.T("CARD_2"),
            hover_color=self.T("ERROR"),
            text_color=self.T("TEXT"),
            border_width=1,
            border_color=self.T("BORDER"),
            font=ctk.CTkFont(size=self.FONT_LABEL, weight="bold"),
        )
        self.header_close_btn.pack(side="left")

        self.header_status = ctk.CTkLabel(
            right,
            text=self.ui_status_text("OFFLINE"),
            font=ctk.CTkFont(size=self.FONT_BODY + 2, weight="bold"),
            text_color=self.T("ERROR"),
        )
        self.header_status.pack(anchor="e")

        self.header_badge = ctk.CTkLabel(
            right,
            text=self.ui_display_name(),
            font=ctk.CTkFont(size=self.FONT_SMALL, weight="bold"),
            text_color=self.T("TAG_TEXT"),
            fg_color=self.T("LIME"),
            corner_radius=999,
            padx=10,
            pady=4,
        )
        self.header_badge.pack(anchor="e", pady=(6, 0))

    def _build_content(self):
        self.content = ctk.CTkFrame(self.main, fg_color=self.T("BG"))
        self.content.grid(row=1, column=0, sticky="nsew")
        self.content.grid_columnconfigure(0, weight=1)
        self.content.grid_rowconfigure(0, weight=1)

        dashboard_tab = self._build_dashboard_tab()
        pix_tab = self._build_pix_tab()
        sheet_tab = self._build_sheet_tab()
        console_tab = self._build_console_tab()

        self.tabs = {
            "dashboard": dashboard_tab,
            "pix": pix_tab,
            "sheet": sheet_tab,
            "console": console_tab,
        }

        if self.is_azaph():
            self.tabs["commands"] = self._build_commands_tab()

        self.show_tab("dashboard")

    def open_chat_ia_window(self):
        play_ui_sound("open")
        try:
            if self.chat_window and self.chat_window.winfo_exists():
                self.chat_window.focus()
                self.chat_window.lift()
                return
        except Exception:
            pass

        self.chat_window = ChatIAWindow(self)

    def _build_chat_hud_tab(self):
        container, frame = self.make_tab_container()

        main_wrap = ctk.CTkFrame(frame, fg_color="transparent")
        main_wrap.pack(fill="both", expand=True, padx=self.PAD, pady=(0, self.PAD))

        if self.compact_mode:
            left = self._panel(main_wrap)
            left.pack(fill="x", pady=(0, self.PAD))

            right = self._panel(main_wrap)
            right.pack(fill="both", expand=True)
        else:
            grid = ctk.CTkFrame(main_wrap, fg_color="transparent")
            grid.pack(fill="both", expand=True)
            grid.grid_columnconfigure(0, weight=0)
            grid.grid_columnconfigure(1, weight=1)
            grid.grid_rowconfigure(0, weight=1)

            left = self._panel(grid)
            left.grid(row=0, column=0, sticky="nsw", padx=(0, 10))

            right = self._panel(grid)
            right.grid(row=0, column=1, sticky="nsew")

        # painel lateral com imagem
        side_w = 320 if self.compact_mode else 420
        side_h = 260 if self.compact_mode else 620

        side_box = ctk.CTkFrame(
            left,
            fg_color=self.T("CARD_2"),
            corner_radius=18,
            border_width=1,
            border_color=self.T("BORDER"),
            width=side_w,
            height=side_h,
        )
        side_box.pack(padx=self.PAD_IN, pady=self.PAD_IN, fill="both", expand=True)
        side_box.pack_propagate(False)

        side_bg = ctk.CTkLabel(side_box, text="", fg_color=self.T("CARD_2"))
        side_bg.place(relx=0, rely=0, relwidth=1, relheight=1)
        self._load_chat_side_image(side_bg, side_w, side_h)

        overlay_card = ctk.CTkFrame(
            side_box,
            fg_color="#0D0C0C",
            corner_radius=18,
            border_width=1,
            border_color="#2F2A26",
        )
        overlay_card.place(relx=0.06, rely=0.06, relwidth=0.88, relheight=0.40)

        role_label = "ADMIN" if self.chat_admin_mode else "USUÁRIO"
        desc = (
            "Modo administrador: criação de bot, comandos locais e automações avançadas."
            if self.chat_admin_mode
            else "Modo usuário: conversa com a IA integrada ao N8N."
        )

        ctk.CTkLabel(
            overlay_card,
            text=f"Chat IA // {role_label}",
            font=ctk.CTkFont(size=self.FONT_SECTION + 2, weight="bold"),
            text_color="#F7EFE5",
        ).pack(anchor="w", padx=18, pady=(18, 8))

        ctk.CTkLabel(
            overlay_card,
            text=desc,
            font=ctk.CTkFont(size=self.FONT_BODY),
            text_color="#E0D4C6",
            justify="left",
            wraplength=260 if self.compact_mode else 320,
        ).pack(anchor="w", padx=18, pady=(0, 10))

        help_text = (
            "• Admin: criar comandos, editar blueprint, iniciar bots\n"
            "• Usuário: usar apenas a IA do N8N\n"
            "• Digite 'cancelar' em fluxos complexos quando necessário"
        )

        ctk.CTkLabel(
            overlay_card,
            text=help_text,
            font=ctk.CTkFont(size=self.FONT_SMALL),
            text_color="#CDBAA7",
            justify="left",
            wraplength=260 if self.compact_mode else 320,
        ).pack(anchor="w", padx=18, pady=(0, 18))

        # painel do chat
        top = ctk.CTkFrame(right, fg_color="transparent")
        top.pack(fill="x", padx=self.PAD_IN, pady=(self.PAD_IN, 10))

        ctk.CTkLabel(
            top,
            text="HUD do Chat IA",
            font=ctk.CTkFont(size=self.FONT_SECTION + 2, weight="bold"),
            text_color=self.T("TEXT"),
        ).pack(anchor="w")

        sub = (
            "Acesso administrativo liberado."
            if self.chat_admin_mode
            else "Acesso comum liberado."
        )

        ctk.CTkLabel(
            top,
            text=sub,
            font=ctk.CTkFont(size=self.FONT_BODY),
            text_color=self.T("TEXT_SOFT"),
        ).pack(anchor="w", pady=(4, 10))

        row = ctk.CTkFrame(top, fg_color="transparent")
        row.pack(fill="x")

        self._button_ghost(row, "Sair do Chat IA", self.logout_chat_ia_mode, 170).pack(
            side="left", padx=(0, 8)
        )

        if self.chat_admin_mode:
            self._button_ghost(row, "Testar Chat", self.test_chat, 150).pack(
                side="left"
            )

        chatbox = ctk.CTkFrame(
            right,
            fg_color=self.T("CARD_2"),
            corner_radius=18,
            border_width=1,
            border_color=self.T("BORDER"),
        )
        chatbox.pack(fill="both", expand=True, padx=self.PAD_IN, pady=(0, self.PAD_IN))

        self.chat_history = ctk.CTkTextbox(
            chatbox,
            height=300 if self.compact_mode else 460,
            fg_color=self.T("CARD_3"),
            border_width=1,
            border_color=self.T("BORDER"),
            text_color=self.T("TEXT"),
            wrap="word",
            font=("Consolas", 12 if self.compact_mode else 14),
            corner_radius=14,
        )
        self.chat_history.pack(fill="both", expand=True, padx=16, pady=(16, 12))

        bottom = ctk.CTkFrame(chatbox, fg_color="transparent")
        bottom.pack(fill="x", padx=16, pady=(0, 16))

        placeholder = (
            "Digite comandos administrativos do Nagi..."
            if self.chat_admin_mode
            else "Digite sua mensagem para a IA..."
        )

        self.chat_input = self._entry(bottom, placeholder)
        self.chat_input.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self.chat_input.bind("<Return>", lambda e: self.send_chat())

        self._button_primary(
            bottom, "Enviar", self.send_chat, 120 if self.compact_mode else 140
        ).pack(side="left")

        return container

    def _load_chat_side_image(self, label_widget, target_w, target_h):
        img_path = ROOT / "assets" / "chat_ia_side.png"

        if not img_path.exists():
            label_widget.configure(
                text="Imagem do Chat IA não encontrada.",
                text_color=self.T("TEXT"),
            )
            return False

        try:
            img = Image.open(img_path).convert("RGBA")
            img = ImageOps.fit(img, (target_w, target_h), Image.LANCZOS)

            overlay = Image.new("RGBA", img.size, (0, 0, 0, 120))
            img = Image.alpha_composite(img, overlay)

            self.chat_side_img = ctk.CTkImage(
                light_image=img,
                dark_image=img,
                size=(target_w, target_h),
            )
            label_widget.configure(image=self.chat_side_img, text="")
            return True
        except Exception as e:
            print("[CHAT IA IMG] erro ao carregar:", e)
            label_widget.configure(
                text="Erro ao carregar imagem do Chat IA.",
                text_color=self.T("TEXT"),
            )
            return False

    def logout_chat_ia_mode(self):
        self.chat_ia_session = None
        self.chat_admin_mode = False

        if "chat" in self.tabs and self.tabs["chat"].winfo_exists():
            self.tabs["chat"].destroy()

        self.tabs["chat"] = self._build_chat_gate_tab()
        self.show_tab("chat")

    def _build_chat_gate_tab(self):
        container, frame = self.make_tab_container()

        panel = self._panel(frame)
        self._pack_panel(panel, fill="both", expand=True)

        ctk.CTkLabel(
            panel,
            text="Chat IA",
            font=ctk.CTkFont(size=self.FONT_SECTION + 2, weight="bold"),
            text_color=self.T("TEXT"),
        ).pack(anchor="w", padx=self.PAD_IN, pady=(self.PAD_IN, 8))

        ctk.CTkLabel(
            panel,
            text="Entre com um perfil do Chat IA para abrir o HUD correto.",
            font=ctk.CTkFont(size=self.FONT_BODY),
            text_color=self.T("TEXT_SOFT"),
        ).pack(anchor="w", padx=self.PAD_IN, pady=(0, 16))

        login_card = ctk.CTkFrame(
            panel,
            fg_color=self.T("CARD_2"),
            corner_radius=18,
            border_width=1,
            border_color=self.T("BORDER"),
        )
        login_card.pack(fill="x", padx=self.PAD_IN, pady=(0, self.PAD_IN))

        ctk.CTkLabel(
            login_card,
            text="Acesso do Chat IA",
            font=ctk.CTkFont(size=self.FONT_SECTION, weight="bold"),
            text_color=self.T("TEXT"),
        ).pack(anchor="w", padx=18, pady=(18, 8))

        self.chat_gate_user = self._entry(login_card, "Usuário do Chat IA")
        self.chat_gate_user.pack(fill="x", padx=18, pady=6)

        self.chat_gate_pass = ctk.CTkEntry(
            login_card,
            placeholder_text="Senha do Chat IA",
            show="*",
            height=self.ENTRY_H,
            corner_radius=12,
            fg_color=self.T("CARD_2"),
            border_width=1,
            border_color=self.T("BORDER"),
            text_color=self.T("TEXT"),
            placeholder_text_color=self.T("MUTED"),
        )
        self.chat_gate_pass.pack(fill="x", padx=18, pady=6)
        self.chat_gate_pass.bind("<Return>", lambda e: self.enter_chat_ia_mode())

        self.chat_gate_status = ctk.CTkLabel(
            login_card,
            text="",
            font=ctk.CTkFont(size=self.FONT_SMALL),
            text_color=self.T("ERROR"),
        )
        self.chat_gate_status.pack(anchor="w", padx=18, pady=(6, 0))

        self._button_primary(
            login_card,
            "Entrar no Chat IA",
            self.enter_chat_ia_mode,
            180 if self.compact_mode else 220,
        ).pack(anchor="w", padx=18, pady=(14, 18))

        demo = (
            "Perfis do Chat IA:\n"
            "Admin: bangboonagi / 101010Nagi!\n"
            "Usuário: usuario / 101215"
        )
        ctk.CTkLabel(
            login_card,
            text=demo,
            justify="left",
            font=ctk.CTkFont(size=self.FONT_SMALL),
            text_color=self.T("MUTED"),
        ).pack(anchor="w", padx=18, pady=(0, 18))

        return container

    def enter_chat_ia_mode(self):
        username = self.chat_gate_user.get().strip().lower()
        password = self.chat_gate_pass.get().strip()

        account = CHAT_IA_ACCOUNTS.get(username)
        if not account or account["password"] != password:
            self.chat_gate_status.configure(
                text="Usuário ou senha do Chat IA inválidos."
            )
            return

        self.chat_ia_session = {
            "username": username,
            "role": account["role"],
            "display_name": account["display_name"],
            "login_at": int(time.time()),
        }

        self.chat_admin_mode = account["role"] == "admin"
        self.show_chat_loading()

    def _open_chat_ia_hud(self):
        if "chat" in self.tabs and self.tabs["chat"].winfo_exists():
            self.tabs["chat"].destroy()

        self.tabs["chat"] = self._build_chat_hud_tab()
        self.show_tab("chat")

    # -----------------------------
    # COMPONENTES
    # -----------------------------
    def _panel(self, master):
        return ctk.CTkFrame(
            master,
            fg_color=self.T("CARD"),
            corner_radius=20,
            border_width=1,
            border_color=self.T("BORDER"),
        )

    def _textbox(self, master, height=300):
        return ctk.CTkTextbox(
            master,
            height=height,
            fg_color=self.T("CARD_3"),
            border_width=1,
            border_color=self.T("BORDER"),
            text_color=self.T("TEXT"),
            wrap="word",
            font=("Consolas", 12 if self.compact_mode else 14),
        )

    def _entry(self, master, placeholder):
        return ctk.CTkEntry(
            master,
            placeholder_text=placeholder,
            height=self.ENTRY_H,
            corner_radius=12,
            fg_color=self.T("CARD_2"),
            border_width=1,
            border_color=self.T("BORDER"),
            text_color=self.T("TEXT"),
            placeholder_text_color=self.T("MUTED"),
        )

    def _button_primary(self, parent, text, command, width=None):
        kwargs = {
            "master": parent,
            "text": text,
            "command": self.with_ui_click(command),
            "height": self.BTN_H,
            "corner_radius": 12,
            "fg_color": self.T("ACCENT"),
            "hover_color": self.T("ACCENT_HOVER"),
            "text_color": self.T("TAG_TEXT"),
            "font": ctk.CTkFont(size=self.FONT_LABEL, weight="bold"),
        }
        if width is not None:
            kwargs["width"] = width
        return ctk.CTkButton(**kwargs)

    def _button_ghost(self, parent, text, command, width=None):
        kwargs = {
            "master": parent,
            "text": text,
            "command": self.with_ui_click(command),
            "height": self.BTN_H,
            "corner_radius": 12,
            "fg_color": self.T("CARD_2"),
            "hover_color": self.T("ACCENT_SOFT"),
            "text_color": self.T("TEXT"),
            "border_width": 1,
            "border_color": self.T("BORDER"),
            "font": ctk.CTkFont(size=self.FONT_LABEL, weight="bold"),
        }
        if width is not None:
            kwargs["width"] = width
        return ctk.CTkButton(**kwargs)

    def _pack_panel(
        self, panel, side="top", fill="x", expand=False, padx=None, pady=None
    ):
        if padx is None:
            padx = self.PAD
        if pady is None:
            pady = (0, self.PAD)
        panel.pack(side=side, fill=fill, expand=expand, padx=padx, pady=pady)

    # -----------------------------
    # TABS
    # -----------------------------
    def _build_dashboard_tab(self):
        container, frame = self.make_tab_container()

        hero = self._panel(frame)
        self._pack_panel(hero)

        hero.grid_columnconfigure(1, weight=1)

        orb_size_w = 180 if self.compact_mode else 220
        orb_size_h = 150 if self.compact_mode else 180

        self.orb_canvas = ctk.CTkCanvas(
            hero,
            width=orb_size_w,
            height=orb_size_h,
            bg=self.T("CARD"),
            highlightthickness=0,
            bd=0,
        )
        self.orb_canvas.grid(row=0, column=0, padx=self.PAD, pady=self.PAD)

        cx = orb_size_w / 2
        cy = orb_size_h / 2
        outer = 70 if self.compact_mode else 80
        inner = 46 if self.compact_mode else 52
        core = 24 if self.compact_mode else 26
        ring = 56 if self.compact_mode else 62

        self.orb_outer = self.orb_canvas.create_oval(
            cx - outer,
            cy - outer,
            cx + outer,
            cy + outer,
            fill=self.T("CARD_2"),
            outline="",
        )
        self.orb_inner = self.orb_canvas.create_oval(
            cx - inner,
            cy - inner,
            cx + inner,
            cy + inner,
            fill=self.T("ACCENT"),
            outline="",
        )
        self.orb_core = self.orb_canvas.create_oval(
            cx - core,
            cy - core,
            cx + core,
            cy + core,
            fill=self.T("CARD_3"),
            outline="",
        )
        self.orb_ring = self.orb_canvas.create_oval(
            cx - ring, cy - ring, cx + ring, cy + ring, outline=self.T("LIME"), width=3
        )

        hero_text = ctk.CTkFrame(hero, fg_color="transparent")
        hero_text.grid(row=0, column=1, sticky="nsew", padx=8, pady=self.PAD)

        ctk.CTkLabel(
            hero_text,
            text=f"{self.ui_nagi_name()} Super Menu // {self.ui_display_name()}",
            font=ctk.CTkFont(size=self.FONT_HERO, weight="bold"),
            text_color=self.T("TEXT"),
        ).pack(anchor="w")

        ctk.CTkLabel(
            hero_text,
            text="Controle do bot, PIX, planilha, chat IA e serviços locais no mesmo painel.",
            font=ctk.CTkFont(size=self.FONT_BODY),
            text_color=self.T("TEXT_SOFT"),
            justify="left",
            wraplength=540 if self.compact_mode else 760,
        ).pack(anchor="w", pady=(6, 14))

        row_buttons = ctk.CTkFrame(hero_text, fg_color="transparent")
        row_buttons.pack(anchor="w")

        btn_w = 135 if self.compact_mode else 150
        self._button_primary(row_buttons, "Ligar Nagi", self.start_bot, btn_w).pack(
            side="left", padx=(0, 8), pady=2
        )
        self._button_ghost(row_buttons, "Desligar Nagi", self.stop_bot, btn_w).pack(
            side="left", padx=(0, 8), pady=2
        )
        self._button_ghost(row_buttons, "Reiniciar", self.restart_bot, btn_w).pack(
            side="left", padx=(0, 8), pady=2
        )
        self._button_ghost(row_buttons, "Testar Chat IA", self.test_chat, btn_w).pack(
            side="left", pady=2
        )

        if self.compact_mode:
            cards_wrap = ctk.CTkFrame(frame, fg_color="transparent")
            self._pack_panel(cards_wrap, fill="both", expand=True)

            self.card_status = self._panel(cards_wrap)
            self.card_status.pack(fill="x", pady=(0, self.PAD))

            self.card_lastpix = self._panel(cards_wrap)
            self.card_lastpix.pack(fill="x")
        else:
            cards_wrap = ctk.CTkFrame(frame, fg_color="transparent")
            self._pack_panel(cards_wrap, fill="both", expand=True)
            cards_wrap.grid_columnconfigure((0, 1), weight=1)

            self.card_status = self._panel(cards_wrap)
            self.card_status.grid(row=0, column=0, sticky="nsew", padx=(0, 9))

            self.card_lastpix = self._panel(cards_wrap)
            self.card_lastpix.grid(row=0, column=1, sticky="nsew", padx=(9, 0))

        ctk.CTkLabel(
            self.card_status,
            text="Status do Bot",
            font=ctk.CTkFont(size=self.FONT_SECTION, weight="bold"),
            text_color=self.T("TEXT"),
        ).pack(anchor="w", padx=self.PAD_IN, pady=(self.PAD_IN, 8))

        self.card_status_body = ctk.CTkLabel(
            self.card_status,
            text="Verificando...",
            text_color=self.T("TEXT_SOFT"),
            justify="left",
            anchor="w",
            font=ctk.CTkFont(size=self.FONT_BODY),
        )
        self.card_status_body.pack(anchor="w", padx=self.PAD_IN, pady=(0, self.PAD_IN))

        ctk.CTkLabel(
            self.card_lastpix,
            text="Último PIX",
            font=ctk.CTkFont(size=self.FONT_SECTION, weight="bold"),
            text_color=self.T("TEXT"),
        ).pack(anchor="w", padx=self.PAD_IN, pady=(self.PAD_IN, 8))

        self.card_lastpix_body = ctk.CTkLabel(
            self.card_lastpix,
            text="Nenhum PIX salvo ainda.",
            text_color=self.T("TEXT_SOFT"),
            justify="left",
            anchor="w",
            font=ctk.CTkFont(size=self.FONT_BODY),
        )
        self.card_lastpix_body.pack(anchor="w", padx=self.PAD_IN, pady=(0, self.PAD_IN))

        quick = self._panel(frame)
        self._pack_panel(quick)

        if self.compact_mode:
            quick.grid_columnconfigure((0, 1), weight=1)
            self._button_primary(quick, "Pendentes", self.action_pendentes).grid(
                row=0, column=0, padx=10, pady=10, sticky="ew"
            )
            self._button_primary(quick, "Resumo", self.action_resumo).grid(
                row=0, column=1, padx=10, pady=10, sticky="ew"
            )
            self._button_ghost(
                quick, "Checkout 1", lambda: self.publish_checkout("1")
            ).grid(row=1, column=0, padx=10, pady=10, sticky="ew")
            self._button_ghost(
                quick, "Checkout 2", lambda: self.publish_checkout("2")
            ).grid(row=1, column=1, padx=10, pady=10, sticky="ew")
        else:
            quick.grid_columnconfigure((0, 1, 2, 3), weight=1)
            self._button_primary(quick, "Pendentes", self.action_pendentes).grid(
                row=0, column=0, padx=12, pady=16, sticky="ew"
            )
            self._button_primary(quick, "Resumo", self.action_resumo).grid(
                row=0, column=1, padx=12, pady=16, sticky="ew"
            )
            self._button_ghost(
                quick, "Checkout 1", lambda: self.publish_checkout("1")
            ).grid(row=0, column=2, padx=12, pady=16, sticky="ew")
            self._button_ghost(
                quick, "Checkout 2", lambda: self.publish_checkout("2")
            ).grid(row=0, column=3, padx=12, pady=16, sticky="ew")

        return container

    def _build_pix_tab(self):
        container, frame = self.make_tab_container()

        if self.compact_mode:
            left = self._panel(frame)
            self._pack_panel(left)

            right = self._panel(frame)
            self._pack_panel(right, fill="both", expand=True)
        else:
            wrap = ctk.CTkFrame(frame, fg_color="transparent")
            self._pack_panel(wrap, fill="both", expand=True)
            wrap.grid_columnconfigure((0, 1), weight=1)

            left = self._panel(wrap)
            left.grid(row=0, column=0, sticky="nsew", padx=(0, 9))

            right = self._panel(wrap)
            right.grid(row=0, column=1, sticky="nsew", padx=(9, 0))

        ctk.CTkLabel(
            left,
            text="Criar PIX",
            font=ctk.CTkFont(size=self.FONT_SECTION, weight="bold"),
            text_color=self.T("TEXT"),
        ).pack(anchor="w", padx=self.PAD_IN, pady=(self.PAD_IN, 10))

        self.pix_customer = self._entry(left, "Nome do cliente")
        self.pix_customer.pack(fill="x", padx=self.PAD_IN, pady=6)

        self.pix_unlock = self._entry(left, "Código de liberação (vazio = automático)")
        self.pix_unlock.pack(fill="x", padx=self.PAD_IN, pady=6)

        self.pix_origin = ctk.CTkOptionMenu(
            left,
            values=["RPN", "Hotmart"],
            height=self.ENTRY_H,
            corner_radius=12,
            fg_color=self.T("ACCENT"),
            button_color=self.T("ACCENT_HOVER"),
            button_hover_color=self.T("ACCENT_HOVER"),
            text_color=self.T("TAG_TEXT"),
            dropdown_fg_color=self.T("CARD_2"),
            dropdown_text_color=self.T("TEXT"),
            dropdown_hover_color=self.T("ACCENT_SOFT"),
            font=ctk.CTkFont(size=self.FONT_LABEL),
        )
        self.pix_origin.pack(fill="x", padx=self.PAD_IN, pady=6)

        self.pix_amount = self._entry(left, "Valor (ex.: 97 ou 97,00) - opcional")
        self.pix_amount.pack(fill="x", padx=self.PAD_IN, pady=6)

        self.pix_code_box = self._textbox(
            left, height=180 if self.compact_mode else 250
        )
        self.pix_code_box.pack(fill="both", expand=True, padx=self.PAD_IN, pady=10)

        row = ctk.CTkFrame(left, fg_color="transparent")
        row.pack(fill="x", padx=self.PAD_IN, pady=(0, self.PAD_IN))

        self._button_primary(
            row, "Criar PIX", self.create_pix, 140 if self.compact_mode else 150
        ).pack(side="left", padx=(0, 8))
        self._button_ghost(
            row, "Ver Último PIX", self.show_last_pix, 140 if self.compact_mode else 150
        ).pack(side="left")

        ctk.CTkLabel(
            right,
            text="Publicação / Utilidades",
            font=ctk.CTkFont(size=self.FONT_SECTION, weight="bold"),
            text_color=self.T("TEXT"),
        ).pack(anchor="w", padx=self.PAD_IN, pady=(self.PAD_IN, 10))

        self._button_primary(
            right, "Publicar no Checkout 1", lambda: self.publish_checkout("1")
        ).pack(fill="x", padx=self.PAD_IN, pady=8)
        self._button_primary(
            right, "Publicar no Checkout 2", lambda: self.publish_checkout("2")
        ).pack(fill="x", padx=self.PAD_IN, pady=8)
        self._button_ghost(right, "Limpar Cache WordPress", self.clear_cache).pack(
            fill="x", padx=self.PAD_IN, pady=8
        )
        self._button_ghost(
            right, "Abrir Pasta do Projeto", self.open_project_folder
        ).pack(fill="x", padx=self.PAD_IN, pady=8)

        self.pix_result = self._textbox(right, height=260 if self.compact_mode else 350)
        self.pix_result.pack(
            fill="both", expand=True, padx=self.PAD_IN, pady=(14, self.PAD_IN)
        )

        return container

    def _build_sheet_tab(self):
        container, frame = self.make_tab_container()

        if self.compact_mode:
            left = self._panel(frame)
            self._pack_panel(left)

            right = self._panel(frame)
            self._pack_panel(right, fill="both", expand=True)
        else:
            wrap = ctk.CTkFrame(frame, fg_color="transparent")
            self._pack_panel(wrap, fill="both", expand=True)
            wrap.grid_columnconfigure((0, 1), weight=1)

            left = self._panel(wrap)
            left.grid(row=0, column=0, sticky="nsew", padx=(0, 9))

            right = self._panel(wrap)
            right.grid(row=0, column=1, sticky="nsew", padx=(9, 0))

        ctk.CTkLabel(
            left,
            text="Planilha / Automação",
            font=ctk.CTkFont(size=self.FONT_SECTION, weight="bold"),
            text_color=self.T("TEXT"),
        ).pack(anchor="w", padx=self.PAD_IN, pady=(self.PAD_IN, 10))

        self._button_primary(left, "Listar Planilha", self.action_planilha).pack(
            fill="x", padx=self.PAD_IN, pady=8
        )
        self._button_primary(left, "Ver Pendentes", self.action_pendentes).pack(
            fill="x", padx=self.PAD_IN, pady=8
        )
        self._button_primary(left, "Ver Resumo", self.action_resumo).pack(
            fill="x", padx=self.PAD_IN, pady=8
        )

        row = ctk.CTkFrame(left, fg_color="transparent")
        row.pack(fill="x", padx=self.PAD_IN, pady=(14, self.PAD_IN))

        self.pago_id = self._entry(row, "ID para marcar como pago")
        self.pago_id.pack(side="left", fill="x", expand=True, padx=(0, 8))

        self._button_primary(
            row, "Marcar Pago", self.action_pago, 140 if self.compact_mode else 150
        ).pack(side="left")

        ctk.CTkLabel(
            right,
            text="Saída",
            font=ctk.CTkFont(size=self.FONT_SECTION, weight="bold"),
            text_color=self.T("TEXT"),
        ).pack(anchor="w", padx=self.PAD_IN, pady=(self.PAD_IN, 10))

        self.sheet_output = self._textbox(
            right, height=360 if self.compact_mode else 560
        )
        self.sheet_output.pack(
            fill="both", expand=True, padx=self.PAD_IN, pady=(0, self.PAD_IN)
        )

        return container

    def _build_chat_tab(self):
        container, frame = self.make_tab_container()

        top = self._panel(frame)
        self._pack_panel(top)

        ctk.CTkLabel(
            top,
            text="Chat IA",
            font=ctk.CTkFont(size=self.FONT_SECTION, weight="bold"),
            text_color=self.T("TEXT"),
        ).pack(anchor="w", padx=self.PAD_IN, pady=(self.PAD_IN, 6))
        ctk.CTkLabel(
            top,
            text=f"Tudo que você escrever aqui será enviado com o perfil {self.ui_display_name()} e os dados básicos da máquina.",
            font=ctk.CTkFont(size=self.FONT_BODY),
            text_color=self.T("TEXT_SOFT"),
            wraplength=720 if self.compact_mode else 980,
            justify="left",
        ).pack(anchor="w", padx=self.PAD_IN, pady=(0, 12))

        row = ctk.CTkFrame(top, fg_color="transparent")
        row.pack(fill="x", padx=self.PAD_IN, pady=(0, self.PAD_IN))

        self._button_ghost(
            row,
            "Testar Webhook Chat",
            self.test_chat,
            170 if self.compact_mode else 180,
        ).pack(side="left")

        chatbox = self._panel(frame)
        self._pack_panel(chatbox, fill="both", expand=True)

        self.chat_history = self._textbox(
            chatbox, height=300 if self.compact_mode else 460
        )
        self.chat_history.pack(
            fill="both", expand=True, padx=self.PAD_IN, pady=(self.PAD_IN, 12)
        )

        bottom = ctk.CTkFrame(chatbox, fg_color="transparent")
        bottom.pack(fill="x", padx=self.PAD_IN, pady=(0, self.PAD_IN))

        self.chat_input = self._entry(
            bottom, "Digite sua mensagem para o Nagi / IA / N8N..."
        )
        self.chat_input.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self.chat_input.bind("<Return>", lambda e: self.send_chat())

        self._button_primary(
            bottom, "Enviar", self.send_chat, 120 if self.compact_mode else 140
        ).pack(side="left")

        return container

    def _build_console_tab(self):
        container, frame = self.make_tab_container()

        box = self._panel(frame)
        self._pack_panel(box, fill="both", expand=True)

        ctk.CTkLabel(
            box,
            text="Console do Super Menu",
            font=ctk.CTkFont(size=self.FONT_SECTION, weight="bold"),
            text_color=self.T("TEXT"),
        ).pack(anchor="w", padx=self.PAD_IN, pady=(self.PAD_IN, 10))

        self.console = self._textbox(box, height=420 if self.compact_mode else 620)
        self.console.pack(
            fill="both", expand=True, padx=self.PAD_IN, pady=(0, self.PAD_IN)
        )

        return container

    def _build_rpn_tab(self):
        container, frame = self.make_tab_container()

        top = self._panel(frame)
        self._pack_panel(top)

        if self.compact_mode:
            left = ctk.CTkFrame(top, fg_color="transparent")
            left.pack(fill="x", padx=self.PAD_IN, pady=(self.PAD_IN, 8))

            right = ctk.CTkFrame(top, fg_color="transparent")
            right.pack(fill="x", padx=self.PAD_IN, pady=(0, self.PAD_IN))
        else:
            top.grid_columnconfigure(1, weight=1)
            left = ctk.CTkFrame(top, fg_color="transparent")
            left.grid(row=0, column=0, sticky="w", padx=self.PAD_IN, pady=self.PAD_IN)

            right = ctk.CTkFrame(top, fg_color="transparent")
            right.grid(row=0, column=1, sticky="e", padx=self.PAD_IN, pady=self.PAD_IN)

        ctk.CTkLabel(
            left,
            text="Controle do RPN BOT",
            font=ctk.CTkFont(size=self.FONT_SECTION + 2, weight="bold"),
            text_color=self.T("TEXT"),
        ).pack(anchor="w")

        ctk.CTkLabel(
            left,
            text="Acesso exclusivo do Azaph. Inicia, desliga e monitora o bot externo em Node.js.",
            font=ctk.CTkFont(size=self.FONT_BODY),
            text_color=self.T("TEXT_SOFT"),
            wraplength=620 if self.compact_mode else 900,
            justify="left",
        ).pack(anchor="w", pady=(6, 0))

        self.rpn_status_badge = ctk.CTkLabel(
            right,
            text="OFFLINE",
            font=ctk.CTkFont(size=self.FONT_BODY + 2, weight="bold"),
            text_color=self.T("ERROR"),
        )
        self.rpn_status_badge.pack(anchor="e")

        self.rpn_info_label = ctk.CTkLabel(
            right,
            text=str(RPN_BOT_DIR),
            font=ctk.CTkFont(size=self.FONT_SMALL),
            text_color=self.T("MUTED"),
            justify="right",
            wraplength=420 if self.compact_mode else 500,
        )
        self.rpn_info_label.pack(anchor="e", pady=(6, 0))

        if self.compact_mode:
            actions = self._panel(frame)
            self._pack_panel(actions)

            out = self._panel(frame)
            self._pack_panel(out, fill="both", expand=True)
        else:
            wrap = ctk.CTkFrame(frame, fg_color="transparent")
            self._pack_panel(wrap, fill="both", expand=True)
            wrap.grid_columnconfigure((0, 1), weight=1)

            actions = self._panel(wrap)
            actions.grid(row=0, column=0, sticky="nsew", padx=(0, 9))

            out = self._panel(wrap)
            out.grid(row=0, column=1, sticky="nsew", padx=(9, 0))

        ctk.CTkLabel(
            actions,
            text="Ações",
            font=ctk.CTkFont(size=self.FONT_SECTION, weight="bold"),
            text_color=self.T("TEXT"),
        ).pack(anchor="w", padx=self.PAD_IN, pady=(self.PAD_IN, 12))

        self._button_primary(actions, "Iniciar RPN BOT", self.action_rpn_start).pack(
            fill="x", padx=self.PAD_IN, pady=6
        )
        self._button_ghost(actions, "Desligar RPN BOT", self.action_rpn_stop).pack(
            fill="x", padx=self.PAD_IN, pady=6
        )
        self._button_ghost(actions, "Reiniciar RPN BOT", self.action_rpn_restart).pack(
            fill="x", padx=self.PAD_IN, pady=6
        )
        self._button_ghost(actions, "Ver Status", self.action_rpn_status).pack(
            fill="x", padx=self.PAD_IN, pady=6
        )
        self._button_ghost(actions, "Ver Último Log", self.action_rpn_tail).pack(
            fill="x", padx=self.PAD_IN, pady=6
        )
        self._button_ghost(
            actions, "Abrir Pasta RPN BOT", self.open_rpn_bot_folder
        ).pack(fill="x", padx=self.PAD_IN, pady=6)

        self.rpn_status_body = ctk.CTkLabel(
            actions,
            text="Verificando...",
            text_color=self.T("TEXT_SOFT"),
            justify="left",
            anchor="w",
            font=ctk.CTkFont(size=self.FONT_BODY),
            wraplength=420 if self.compact_mode else 500,
        )
        self.rpn_status_body.pack(fill="x", padx=self.PAD_IN, pady=(14, self.PAD_IN))

        ctk.CTkLabel(
            out,
            text="Saída / Log",
            font=ctk.CTkFont(size=self.FONT_SECTION, weight="bold"),
            text_color=self.T("TEXT"),
        ).pack(anchor="w", padx=self.PAD_IN, pady=(self.PAD_IN, 12))

        self.rpn_output = self._textbox(out, height=360 if self.compact_mode else 560)
        self.rpn_output.pack(
            fill="both", expand=True, padx=self.PAD_IN, pady=(0, self.PAD_IN)
        )

        return container

    # -----------------------------
    # ANIMAÇÕES / NAVEGAÇÃO
    # -----------------------------
    def _animate(self):
        self.anim_phase += 0.12

        pulse = 1 + math.sin(self.anim_phase) * 0.07
        ring = 1 + math.sin(self.anim_phase * 1.4) * 0.12

        try:
            cx = self.orb_canvas.winfo_reqwidth() / 2
            cy = self.orb_canvas.winfo_reqheight() / 2
            r_inner = (46 if self.compact_mode else 52) * pulse
            r_ring = (56 if self.compact_mode else 62) * ring
            self.orb_canvas.coords(
                self.orb_inner, cx - r_inner, cy - r_inner, cx + r_inner, cy + r_inner
            )
            self.orb_canvas.coords(
                self.orb_ring, cx - r_ring, cy - r_ring, cx + r_ring, cy + r_ring
            )
        except Exception:
            pass

        y = int(math.sin(self.anim_phase * 0.8) * (4 if self.compact_mode else 6))
        if y != self.bangboo_y:
            self.bangboo_y = y
            try:
                self.bangboo_label.place(relx=0.5, rely=0.52, anchor="center", y=y)
            except Exception:
                pass

        try:
            if math.sin(self.anim_phase * 1.2) > 0:
                self.header_badge.configure(
                    fg_color=self.T("LIME"), text_color=self.T("TAG_TEXT")
                )
            else:
                self.header_badge.configure(
                    fg_color=self.T("ACCENT"), text_color=self.T("TAG_TEXT")
                )
        except Exception:
            pass

        self.after(40, self._animate)

    def show_tab(self, name: str):
        if name == "rpn" and not self.is_azaph():
            self._safe_log("Acesso negado à aba RPN BOT.")
            return

        if not hasattr(self, "tabs") or not isinstance(self.tabs, dict):
            self._safe_log("Erro: self.tabs não foi inicializado.")
            return

        if name not in self.tabs:
            self._safe_log(
                f"Erro: aba '{name}' não encontrada. Abas disponíveis: {list(self.tabs.keys())}"
            )
            return

        self.current_tab = name

        for _, tab in self.tabs.items():
            if tab is not None:
                try:
                    tab.grid_forget()
                except Exception:
                    pass

        selected_tab = self.tabs.get(name)
        if selected_tab is not None:
            selected_tab.grid(row=0, column=0, sticky="nsew")

        data = {
            "dashboard": (self.ui_dashboard_text(), "Controle geral do Nagi"),
            "pix": ("PIX / Checkout", "Criação, publicação e utilidades"),
            "sheet": ("Planilha", "Consultas e ações do N8N"),
            "console": ("Console", "Logs locais do super menu"),
        }

        if self.is_azaph():
            data["commands"] = (
                "Comandos",
                "Gerenciamento local dos comandos do bot Discord",
            )

        title, subtitle = data.get(name, (self.ui_nagi_name(), "Sistema"))
        self.page_title.configure(text=title)
        self.page_subtitle.configure(text=subtitle)

        for key, btn in self.nav_buttons.items():
            if key == name:
                btn.configure(
                    fg_color=self.T("ACCENT"),
                    hover_color=self.T("ACCENT_HOVER"),
                    text_color=self.T("TAG_TEXT"),
                )
            else:
                btn.configure(
                    fg_color=self.T("ACCENT_SOFT"),
                    hover_color=self.T("ACCENT"),
                    text_color=self.T("TEXT"),
                )

    # -----------------------------
    # LOG / OUTPUT
    # -----------------------------
    def _safe_log(self, text: str):
        print(text)
        try:
            self.log(text)
        except Exception:
            pass

    def log(self, text: str):
        stamp = time.strftime("%H:%M:%S")
        line = f"[{stamp}] {text}\n"
        try:
            self.console.insert("end", line)
            self.console.see("end")
        except Exception:
            pass

    def set_output(self, widget, ok: bool, msg: str):
        widget.delete("1.0", "end")
        prefix = "✅ " if ok else "❌ "
        widget.insert("1.0", prefix + msg)
        self.log(msg)

    # -----------------------------
    # STATUS
    # -----------------------------
    def refresh_status(self):
        if not self.user_session:
            return

        status = self.service.bot_status()

        if status["running"]:
            self.header_status.configure(
                text=self.ui_status_text("ONLINE"), text_color=self.T("SUCCESS")
            )
            self.side_status.configure(
                text=f"● {self.ui_status_text('online')} • {status['pid']}",
                text_color=self.T("SUCCESS"),
            )
            self.card_status_body.configure(
                text=(
                    f"Bot rodando normalmente.\n"
                    f"PID: {status['pid']}\n"
                    f"Python: {status['python']}\n"
                    f"Usuário logado: {self.ui_display_name()}"
                )
            )
        else:
            self.header_status.configure(
                text=self.ui_status_text("OFFLINE"), text_color=self.T("ERROR")
            )
            self.side_status.configure(
                text=f"● {self.ui_status_text('offline')}", text_color=self.T("ERROR")
            )
            self.card_status_body.configure(
                text=f"Nagi desligado.\nUsuário logado: {self.ui_display_name()}"
            )

        ok, msg = self.service.get_last_pix()
        self.card_lastpix_body.configure(text=msg if ok else "Nenhum PIX salvo ainda.")

        if (
            self.is_azaph()
            and hasattr(self, "rpn_status_badge")
            and hasattr(self, "rpn_status_body")
        ):
            rpn = self.service.rpn_bot_status()
            if rpn["running"]:
                self.rpn_status_badge.configure(
                    text="ONLINE", text_color=self.T("SUCCESS")
                )
                self.rpn_status_body.configure(
                    text=(
                        f"RPN BOT rodando.\n"
                        f"PID: {rpn['pid']}\n"
                        f"Modo: {rpn['mode']}\n"
                        f"Comando: {rpn['command']}\n"
                        f"Log: {rpn['log_file']}"
                    )
                )
            else:
                self.rpn_status_badge.configure(
                    text="OFFLINE", text_color=self.T("ERROR")
                )
                self.rpn_status_body.configure(
                    text=(
                        f"RPN BOT desligado.\n"
                        f"Modo detectado: {rpn['mode']}\n"
                        f"Comando: {rpn['command']}\n"
                        f"Pasta: {rpn['folder']}"
                    )
                )

    def run_async(self, fn, callback=None):
        def worker():
            ok, msg = fn()
            if callback:
                self.after(0, lambda: callback(ok, msg))

        threading.Thread(target=worker, daemon=True).start()

    def _start_loops(self):
        if not self.status_loop_started:
            self.status_loop_started = True
            self.after(3000, self._status_loop)
            self.after(40, self._animate)

        self.refresh_status()

    def _status_loop(self):
        try:
            self.refresh_status()
        except Exception as e:
            self._safe_log(f"Erro no loop de status: {e}")
        self.after(3000, self._status_loop)

    # -----------------------------
    # SESSÃO / FECHAR
    # -----------------------------
    def logout_to_login(self):
        self.user_session = None
        self.current_tab = "dashboard"
        self.tabs = {}
        self.nav_buttons = {}
        self.sidebar = None
        self.main = None
        self.header = None
        self.content = None
        self.login_frame = None
        self.configure(fg_color="#121110")
        self.show_login()

    def close_menu(self):
        try:
            self.destroy()
        except Exception:
            os._exit(0)

    # -----------------------------
    # AÇÕES NAGI
    # -----------------------------
    def start_bot(self):
        self.run_async(self.service.start_bot, self._done_message)

    def stop_bot(self):
        self.run_async(self.service.stop_bot, self._done_message)

    def restart_bot(self):
        self.run_async(self.service.restart_bot, self._done_message)

    def _done_message(self, ok: bool, msg: str):
        self.log(msg)
        self.refresh_status()

    # -----------------------------
    # PIX
    # -----------------------------
    def create_pix(self):
        customer = self.pix_customer.get()
        unlock = self.pix_unlock.get()
        origin = self.pix_origin.get()
        amount = self.pix_amount.get()
        pix_code = self.pix_code_box.get("1.0", "end").strip()

        def job():
            return self.service.create_pix(customer, unlock, origin, amount, pix_code)

        self.run_async(job, lambda ok, msg: self.set_output(self.pix_result, ok, msg))

    def show_last_pix(self):
        ok, msg = self.service.get_last_pix()
        self.set_output(self.pix_result, ok, msg)

    def publish_checkout(self, checkout: str):
        self.run_async(
            lambda: self.service.publish_last_pix(checkout),
            lambda ok, msg: self.set_output(self.pix_result, ok, msg),
        )

    def clear_cache(self):
        self.run_async(
            self.service.clear_cache,
            lambda ok, msg: self.set_output(self.pix_result, ok, msg),
        )

    def open_project_folder(self):
        try:
            if os.name == "nt":
                os.startfile(str(ROOT))
            else:
                subprocess.Popen(["xdg-open", str(ROOT)])
            self.log(f"Pasta aberta: {ROOT}")
        except Exception as e:
            self.log(f"Erro ao abrir pasta: {e}")

    # -----------------------------
    # PLANILHA
    # -----------------------------
    def action_planilha(self):
        self.run_async(
            self.service.planilha,
            lambda ok, msg: self.set_output(self.sheet_output, ok, msg),
        )

    def action_pendentes(self):
        self.run_async(
            self.service.pendentes,
            lambda ok, msg: self.set_output(self.sheet_output, ok, msg),
        )

    def action_resumo(self):
        self.run_async(
            self.service.resumo,
            lambda ok, msg: self.set_output(self.sheet_output, ok, msg),
        )

    def action_pago(self):
        row_id = self.pago_id.get().strip()
        self.run_async(
            lambda: self.service.pago(row_id),
            lambda ok, msg: self.set_output(self.sheet_output, ok, msg),
        )

    # -----------------------------
    # CHAT
    # -----------------------------
    def append_chat(self, sender: str, text: str):
        stamp = time.strftime("%H:%M")
        self.chat_history.insert("end", f"[{stamp}] {sender}\n{text}\n\n")
        self.chat_history.see("end")

    def test_chat(self):
        self.append_chat("Sistema", "Teste do chat local/webhook...")

        def job():
            ok, msg, handled = handle_local_bot_chat(
                "status bot discord", self.user_session
            )
            if handled:
                return ok, msg
            return call_chat_webhook(
                "teste de conexão do super menu do Nagi", self.user_session
            )

        def done(ok, msg):
            self.append_chat(
                "Sistema", f"Teste do chat: {msg}" if ok else f"Falha no teste: {msg}"
            )
            self.log(f"Teste chat: {msg}")

        self.run_async(job, done)

    def send_chat(self):
        text = self.chat_input.get().strip()
        if not text:
            return

        self.chat_input.delete(0, "end")
        self.append_chat(self.parent_app.ui_display_name(), text)
        play_ui_sound("send")
        play_typing_loop()

        def job():
            if self.chat_admin_mode:
                ok, msg, handled = handle_local_bot_chat(
                    text, self.parent_app.user_session
                )
                if handled:
                    return ok, msg

            return call_chat_webhook(text, self.parent_app.user_session)

        def done(ok, msg):
            stop_ui_sound()
            play_ui_sound("receive" if ok else "error")

            label = (
                "NAGI ADMIN" if self.chat_admin_mode else self.parent_app.ui_nagi_name()
            )
            self.append_chat(label, msg if ok else f"Erro: {msg}")
            self.parent_app.log(f"Chat IA separado: {msg}")

        self.parent_app.run_async(job, done)

    # -----------------------------
    # RPN BOT
    # -----------------------------
    def _require_azaph(self) -> bool:
        if self.is_azaph():
            return True
        self.log("Acesso negado. Somente Azaph pode controlar o RPN BOT.")
        if hasattr(self, "rpn_output"):
            self.set_output(
                self.rpn_output,
                False,
                "Acesso negado. Somente Azaph pode controlar o RPN BOT.",
            )
        return False

    def action_rpn_start(self):
        if not self._require_azaph():
            return
        self.run_async(
            lambda: self.service.start_rpn_bot(self.user_session["username"]),
            lambda ok, msg: self.set_output(self.rpn_output, ok, msg),
        )

    def action_rpn_stop(self):
        if not self._require_azaph():
            return
        self.run_async(
            lambda: self.service.stop_rpn_bot(self.user_session["username"]),
            lambda ok, msg: self.set_output(self.rpn_output, ok, msg),
        )

    def action_rpn_restart(self):
        if not self._require_azaph():
            return
        self.run_async(
            lambda: self.service.restart_rpn_bot(self.user_session["username"]),
            lambda ok, msg: self.set_output(self.rpn_output, ok, msg),
        )

    def action_rpn_status(self):
        if not self._require_azaph():
            return

        def job():
            data = self.service.rpn_bot_status()
            msg = (
                f"Rodando: {'sim' if data['running'] else 'não'}\n"
                f"PID: {data['pid']}\n"
                f"Pasta: {data['folder']}\n"
                f"Modo: {data['mode']}\n"
                f"Comando: {data['command']}\n"
                f"Log: {data['log_file']}"
            )
            return True, msg

        self.run_async(job, lambda ok, msg: self.set_output(self.rpn_output, ok, msg))

    def action_rpn_tail(self):
        if not self._require_azaph():
            return
        self.run_async(
            lambda: self.service.get_rpn_bot_log_tail(
                self.user_session["username"], 100
            ),
            lambda ok, msg: self.set_output(self.rpn_output, ok, msg),
        )

    def open_rpn_bot_folder(self):
        if not self._require_azaph():
            return
        try:
            if os.name == "nt":
                os.startfile(str(RPN_BOT_DIR))
            else:
                subprocess.Popen(["xdg-open", str(RPN_BOT_DIR)])
            self.log(f"Pasta RPN BOT aberta: {RPN_BOT_DIR}")
        except Exception as e:
            self.log(f"Erro ao abrir pasta do RPN BOT: {e}")
            if hasattr(self, "rpn_output"):
                self.set_output(
                    self.rpn_output, False, f"Erro ao abrir pasta do RPN BOT: {e}"
                )


class ChatIAWindow(ctk.CTkToplevel):

    def _cancel_chat_loading_animation(self):
        if self.chat_loading_after_id is not None:
            try:
                self.after_cancel(self.chat_loading_after_id)
            except Exception:
                pass
            self.chat_loading_after_id = None

    def destroy(self):
        self._cancel_chat_loading_animation()
        super().destroy()

    def __init__(self, parent_app: "NagiApp"):
        super().__init__(parent_app)

        self.parent_app = parent_app
        self.chat_session = None
        self.chat_side_img = None

        self.chat_loading_after_id = None
        self.chat_loading_bar = None
        self.chat_loading_canvas = None
        self.chat_loading_label = None

        self.chat_loading_frame = None
        self.chat_admin_mode = False
        self.chat_history = None
        self.chat_input = None

        self.title("NAGI // Chat IA")
        self.configure(fg_color=parent_app.T("BG"))

        width = 1220
        height = 760
        screen_w = self.winfo_screenwidth()
        screen_h = self.winfo_screenheight()
        x = max(20, (screen_w - width) // 2)
        y = max(20, (screen_h - height) // 2)

        self.geometry(f"{width}x{height}+{x}+{y}")
        self.minsize(1080, 680)
        self.transient(parent_app)
        self.focus()
        self.grab_set()

        self.grid_columnconfigure(0, weight=0)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self.left = ctk.CTkFrame(
            self,
            fg_color=parent_app.T("CARD"),
            corner_radius=0,
            width=470,
        )
        self.left.grid(row=0, column=0, sticky="nsew")
        self.left.grid_propagate(False)

        self.right = ctk.CTkFrame(
            self,
            fg_color=parent_app.T("BG_SOFT"),
            corner_radius=0,
        )
        self.right.grid(row=0, column=1, sticky="nsew")

        self.build_login_screen()

    def build_login_screen(self):
        for child in self.left.winfo_children():
            child.destroy()
        for child in self.right.winfo_children():
            child.destroy()

        bg_label = ctk.CTkLabel(self.left, text="", fg_color=self.parent_app.T("CARD"))
        bg_label.place(relx=0, rely=0, relwidth=1, relheight=1)
        self._load_chat_login_image(bg_label, 470, 760)

        wrap = ctk.CTkFrame(self.right, fg_color="transparent")
        wrap.place(relx=0.5, rely=0.5, anchor="center", relwidth=0.74, relheight=0.70)

        card = ctk.CTkFrame(
            wrap,
            fg_color=self.parent_app.T("CARD"),
            corner_radius=24,
            border_width=1,
            border_color=self.parent_app.T("BORDER"),
        )
        card.pack(fill="both", expand=True)

        ctk.CTkLabel(
            card,
            text="Entrar no Chat IA",
            font=ctk.CTkFont(size=30, weight="bold"),
            text_color=self.parent_app.T("TEXT"),
        ).pack(anchor="w", padx=34, pady=(34, 10))

        ctk.CTkLabel(
            card,
            text="Use um perfil do Chat IA para abrir o sistema separado.",
            font=ctk.CTkFont(size=14),
            text_color=self.parent_app.T("TEXT_SOFT"),
        ).pack(anchor="w", padx=34, pady=(0, 18))

        self.login_user = ctk.CTkEntry(
            card,
            placeholder_text="Usuário do Chat IA",
            height=44,
            corner_radius=14,
            fg_color=self.parent_app.T("CARD_2"),
            border_width=1,
            border_color=self.parent_app.T("BORDER"),
            text_color=self.parent_app.T("TEXT"),
            placeholder_text_color=self.parent_app.T("MUTED"),
        )
        self.login_user.pack(fill="x", padx=34, pady=8)

        self.login_pass = ctk.CTkEntry(
            card,
            placeholder_text="Senha do Chat IA",
            show="*",
            height=44,
            corner_radius=14,
            fg_color=self.parent_app.T("CARD_2"),
            border_width=1,
            border_color=self.parent_app.T("BORDER"),
            text_color=self.parent_app.T("TEXT"),
            placeholder_text_color=self.parent_app.T("MUTED"),
        )
        self.login_pass.pack(fill="x", padx=34, pady=8)
        self.login_pass.bind("<Return>", lambda e: self.try_login())

        self.login_status = ctk.CTkLabel(
            card,
            text="",
            font=ctk.CTkFont(size=12),
            text_color=self.parent_app.T("ERROR"),
        )
        self.login_status.pack(anchor="w", padx=34, pady=(8, 0))

        buttons = ctk.CTkFrame(card, fg_color="transparent")
        buttons.pack(fill="x", padx=34, pady=(22, 16))

        ctk.CTkButton(
            buttons,
            text="Entrar",
            command=self.try_login,
            height=46,
            corner_radius=14,
            fg_color=self.parent_app.T("ACCENT"),
            hover_color=self.parent_app.T("ACCENT_HOVER"),
            text_color=self.parent_app.T("TAG_TEXT"),
            font=ctk.CTkFont(size=14, weight="bold"),
        ).pack(side="left", padx=(0, 10))

        ctk.CTkButton(
            buttons,
            text="Fechar",
            command=self.destroy,
            height=46,
            corner_radius=14,
            fg_color=self.parent_app.T("CARD_2"),
            hover_color=self.parent_app.T("ACCENT_SOFT"),
            text_color=self.parent_app.T("TEXT"),
            border_width=1,
            border_color=self.parent_app.T("BORDER"),
            font=ctk.CTkFont(size=14, weight="bold"),
        ).pack(side="left")

        demo = (
            "Perfis do Chat IA:\n"
            "Admin: bangboonagi / 101010Nagi!\n"
            "Usuário: usuario / 101215"
        )
        ctk.CTkLabel(
            card,
            text=demo,
            justify="left",
            font=ctk.CTkFont(size=12),
            text_color=self.parent_app.T("MUTED"),
        ).pack(anchor="w", padx=34, pady=(0, 24))

    def _load_chat_login_image(self, label_widget, target_w, target_h):
        img_path = ROOT / "assets" / "chat_ia_side.png"

        if not img_path.exists():
            label_widget.configure(
                text="Imagem do Chat IA não encontrada.",
                text_color=self.parent_app.T("TEXT"),
            )
            return False

        try:
            img = Image.open(img_path).convert("RGBA")
            img = ImageOps.fit(img, (target_w, target_h), Image.LANCZOS)

            overlay = Image.new("RGBA", img.size, (0, 0, 0, 105))
            img = Image.alpha_composite(img, overlay)

            self.chat_side_img = ctk.CTkImage(
                light_image=img,
                dark_image=img,
                size=(target_w, target_h),
            )
            label_widget.configure(image=self.chat_side_img, text="")
            return True
        except Exception as e:
            print("[CHAT LOGIN IMG] erro ao carregar:", e)
            label_widget.configure(
                text="Erro ao carregar imagem do Chat IA.",
                text_color=self.parent_app.T("TEXT"),
            )
            return False

    def try_login(self):
        username = self.login_user.get().strip().lower()
        password = self.login_pass.get().strip()

        account = CHAT_IA_ACCOUNTS.get(username)
        if not account or account["password"] != password:
            play_ui_sound("error")
            self.login_status.configure(text="Usuário ou senha do Chat IA inválidos.")
            return

        self.chat_session = {
            "username": username,
            "role": account["role"],
            "display_name": account["display_name"],
            "login_at": int(time.time()),
        }

        self.chat_admin_mode = account["role"] == "admin"

        play_ui_sound("login")
        self.show_chat_loading()

    def show_chat_loading(self):
        self._cancel_chat_loading_animation()

        for child in self.left.winfo_children():
            child.destroy()
        for child in self.right.winfo_children():
            child.destroy()

        bg_label = ctk.CTkLabel(self.left, text="", fg_color=self.parent_app.T("CARD"))
        bg_label.place(relx=0, rely=0, relwidth=1, relheight=1)
        self._load_chat_login_image(bg_label, 470, 760)

        wrap = ctk.CTkFrame(self.right, fg_color="transparent")
        wrap.place(relx=0.5, rely=0.5, anchor="center", relwidth=0.72, relheight=0.52)

        card = ctk.CTkFrame(
            wrap,
            fg_color=self.parent_app.T("CARD"),
            corner_radius=24,
            border_width=1,
            border_color=self.parent_app.T("BORDER"),
        )
        card.pack(fill="both", expand=True)

        self.chat_loading_canvas = ctk.CTkCanvas(
            card,
            width=220,
            height=180,
            bg=self.parent_app.T("CARD"),
            highlightthickness=0,
            bd=0,
        )
        self.chat_loading_canvas.pack(pady=(40, 12))

        self.chat_ld_outer = self.chat_loading_canvas.create_oval(
            35, 15, 185, 165, fill=self.parent_app.T("CARD_2"), outline=""
        )
        self.chat_ld_inner = self.chat_loading_canvas.create_oval(
            62, 42, 158, 138, fill=self.parent_app.T("ACCENT"), outline=""
        )
        self.chat_ld_core = self.chat_loading_canvas.create_oval(
            88, 68, 132, 112, fill=self.parent_app.T("CARD_3"), outline=""
        )
        self.chat_ld_ring = self.chat_loading_canvas.create_oval(
            52, 32, 168, 148, outline=self.parent_app.T("LIME"), width=3
        )

        ctk.CTkLabel(
            card,
            text="Carregando Chat IA",
            font=ctk.CTkFont(size=28, weight="bold"),
            text_color=self.parent_app.T("TEXT"),
        ).pack()

        mode_text = "Modo ADMIN" if self.chat_admin_mode else "Modo Usuário"

        self.chat_loading_label = ctk.CTkLabel(
            card,
            text=f"Inicializando HUD... • {mode_text}",
            font=ctk.CTkFont(size=14),
            text_color=self.parent_app.T("TEXT_SOFT"),
        )
        self.chat_loading_label.pack(pady=(6, 18))

        self.chat_loading_bar = ctk.CTkProgressBar(
            card,
            width=320,
            height=14,
            progress_color=self.parent_app.T("ACCENT"),
        )
        self.chat_loading_bar.pack()
        self.chat_loading_bar.set(0)

        self.chat_loading_progress = 0.0
        self._animate_chat_loading()
        self.after(1200, self.build_chat_hud_screen)

    def _animate_chat_loading(self):
        if not self.winfo_exists():
            return

        if (
            self.chat_loading_bar is None
            or self.chat_loading_label is None
            or self.chat_loading_canvas is None
        ):
            return

        try:
            if not self.chat_loading_bar.winfo_exists():
                return
            if not self.chat_loading_label.winfo_exists():
                return
            if not self.chat_loading_canvas.winfo_exists():
                return
        except Exception:
            return

        self.parent_app.anim_phase += 0.18
        pulse = 1 + math.sin(self.parent_app.anim_phase) * 0.08
        ring = 1 + math.sin(self.parent_app.anim_phase * 1.35) * 0.12

        cx, cy = 110, 90
        r_inner = 48 * pulse
        r_ring = 58 * ring

        try:
            self.chat_loading_canvas.coords(
                self.chat_ld_inner,
                cx - r_inner,
                cy - r_inner,
                cx + r_inner,
                cy + r_inner,
            )
            self.chat_loading_canvas.coords(
                self.chat_ld_ring, cx - r_ring, cy - r_ring, cx + r_ring, cy + r_ring
            )
        except Exception:
            return

        self.chat_loading_progress = min(1.0, self.chat_loading_progress + 0.05)

        try:
            self.chat_loading_bar.set(self.chat_loading_progress)
        except Exception:
            return

        if self.chat_loading_progress < 0.35:
            txt = "Preparando sessão..."
        elif self.chat_loading_progress < 0.70:
            txt = "Carregando interface..."
        else:
            txt = "Abrindo HUD do chat..."

        try:
            self.chat_loading_label.configure(text=txt)
        except Exception:
            return

        self.chat_loading_after_id = self.after(45, self._animate_chat_loading)

    def build_chat_hud_screen(self):
        self._cancel_chat_loading_animation()

        for child in self.left.winfo_children():
            child.destroy()
        for child in self.right.winfo_children():
            child.destroy()

        bg_label = ctk.CTkLabel(self.left, text="", fg_color=self.parent_app.T("CARD"))
        bg_label.place(relx=0, rely=0, relwidth=1, relheight=1)
        self._load_chat_login_image(bg_label, 470, 760)

        top = ctk.CTkFrame(self.right, fg_color="transparent")
        top.pack(fill="x", padx=24, pady=(24, 12))

        role_label = "ADMIN" if self.chat_admin_mode else "USUÁRIO"
        desc = (
            "Modo administrador: comandos locais, criação de bot e automações."
            if self.chat_admin_mode
            else "Modo usuário: somente conversa com a IA do N8N."
        )

        ctk.CTkLabel(
            top,
            text=f"Chat IA // {role_label}",
            font=ctk.CTkFont(size=30, weight="bold"),
            text_color=self.parent_app.T("TEXT"),
        ).pack(anchor="w")

        ctk.CTkLabel(
            top,
            text=desc,
            font=ctk.CTkFont(size=14),
            text_color=self.parent_app.T("TEXT_SOFT"),
        ).pack(anchor="w", pady=(4, 10))

        row = ctk.CTkFrame(top, fg_color="transparent")
        row.pack(fill="x")

        ctk.CTkButton(
            row,
            text="Sair",
            command=self.destroy,
            height=44,
            corner_radius=12,
            fg_color=self.parent_app.T("CARD_2"),
            hover_color=self.parent_app.T("ACCENT_SOFT"),
            text_color=self.parent_app.T("TEXT"),
            border_width=1,
            border_color=self.parent_app.T("BORDER"),
            font=ctk.CTkFont(size=14, weight="bold"),
        ).pack(side="left", padx=(0, 8))

        ctk.CTkButton(
            row,
            text="Trocar Conta",
            command=self.build_login_screen,
            height=44,
            corner_radius=12,
            fg_color=self.parent_app.T("CARD_2"),
            hover_color=self.parent_app.T("ACCENT_SOFT"),
            text_color=self.parent_app.T("TEXT"),
            border_width=1,
            border_color=self.parent_app.T("BORDER"),
            font=ctk.CTkFont(size=14, weight="bold"),
        ).pack(side="left", padx=(0, 8))

        if self.chat_admin_mode:
            ctk.CTkButton(
                row,
                text="Testar Chat",
                command=self.test_chat,
                height=44,
                corner_radius=12,
                fg_color=self.parent_app.T("CARD_2"),
                hover_color=self.parent_app.T("ACCENT_SOFT"),
                text_color=self.parent_app.T("TEXT"),
                border_width=1,
                border_color=self.parent_app.T("BORDER"),
                font=ctk.CTkFont(size=14, weight="bold"),
            ).pack(side="left")

        chatbox = ctk.CTkFrame(
            self.right,
            fg_color=self.parent_app.T("CARD"),
            corner_radius=24,
            border_width=1,
            border_color=self.parent_app.T("BORDER"),
        )
        chatbox.pack(fill="both", expand=True, padx=24, pady=(0, 24))

        self.chat_history = ctk.CTkTextbox(
            chatbox,
            height=420,
            fg_color=self.parent_app.T("CARD_3"),
            border_width=1,
            border_color=self.parent_app.T("BORDER"),
            text_color=self.parent_app.T("TEXT"),
            wrap="word",
            font=("Consolas", 14),
            corner_radius=14,
        )
        self.chat_history.pack(fill="both", expand=True, padx=16, pady=(16, 12))

        bottom = ctk.CTkFrame(chatbox, fg_color="transparent")
        bottom.pack(fill="x", padx=16, pady=(0, 16))

        placeholder = (
            "Digite comandos administrativos do Nagi..."
            if self.chat_admin_mode
            else "Digite sua mensagem para a IA..."
        )

        self.chat_input = ctk.CTkEntry(
            bottom,
            placeholder_text=placeholder,
            height=44,
            corner_radius=14,
            fg_color=self.parent_app.T("CARD_2"),
            border_width=1,
            border_color=self.parent_app.T("BORDER"),
            text_color=self.parent_app.T("TEXT"),
            placeholder_text_color=self.parent_app.T("MUTED"),
        )
        self.chat_input.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self.chat_input.bind("<Return>", lambda e: self.send_chat())

        ctk.CTkButton(
            bottom,
            text="Enviar",
            command=self.send_chat,
            height=44,
            width=130,
            corner_radius=14,
            fg_color=self.parent_app.T("ACCENT"),
            hover_color=self.parent_app.T("ACCENT_HOVER"),
            text_color=self.parent_app.T("TAG_TEXT"),
            font=ctk.CTkFont(size=14, weight="bold"),
        ).pack(side="left")

    def append_chat(self, sender: str, text: str):
        stamp = time.strftime("%H:%M")
        self.chat_history.insert("end", f"[{stamp}] {sender}\n{text}\n\n")
        self.chat_history.see("end")

    def test_chat(self):
        self.append_chat("Sistema", "Teste do chat local/webhook...")

        def job():
            ok, msg, handled = handle_local_bot_chat(
                "status bot discord", self.parent_app.user_session
            )
            if handled:
                return ok, msg
            return call_chat_webhook(
                "teste de conexão do chat separado do Nagi",
                self.parent_app.user_session,
            )

        def done(ok, msg):
            self.append_chat(
                "Sistema", f"Teste do chat: {msg}" if ok else f"Falha no teste: {msg}"
            )
            self.parent_app.log(f"Teste chat separado: {msg}")

        self.parent_app.run_async(job, done)

    def send_chat(self):
        text = self.chat_input.get().strip()
        if not text:
            return

        self.chat_input.delete(0, "end")

        # mostra mensagem do usuário
        self.append_chat(self.parent_app.ui_display_name(), text)

        # som de envio
        play_ui_sound("send")

        def job():
            if self.chat_admin_mode:
                ok, msg, handled = handle_local_bot_chat(
                    text, self.parent_app.user_session
                )

                if handled:
                    return ok, msg

            return call_chat_webhook(text, self.parent_app.user_session)

        def done(ok, msg):
            label = (
                "NAGI ADMIN" if self.chat_admin_mode else self.parent_app.ui_nagi_name()
            )

            if ok:
                play_ui_sound("receive")
                self.append_chat(label, msg)
            else:
                play_ui_sound("error")
                self.append_chat(label, f"Erro: {msg}")

            self.parent_app.log(f"Chat IA separado: {msg}")

        self.parent_app.run_async(job, done)

    def show_placeholder_after_login(self):
        for child in self.left.winfo_children():
            child.destroy()
        for child in self.right.winfo_children():
            child.destroy()

        ctk.CTkLabel(
            self.left,
            text="Chat IA carregado",
            font=ctk.CTkFont(size=28, weight="bold"),
            text_color=self.parent_app.T("TEXT"),
        ).place(relx=0.5, rely=0.5, anchor="center")

        role = self.chat_session["role"]
        title = "HUD ADMIN" if role == "admin" else "HUD USUÁRIO"
        desc = (
            "Login do Chat IA concluído com sucesso.\n\n"
            f"Modo atual: {title}\n\n"
            "Na Parte 2 vamos substituir esta tela pelo HUD completo do chat."
        )

        box = ctk.CTkFrame(
            self.right,
            fg_color=self.parent_app.T("CARD"),
            corner_radius=24,
            border_width=1,
            border_color=self.parent_app.T("BORDER"),
        )
        box.place(relx=0.5, rely=0.5, anchor="center", relwidth=0.72, relheight=0.52)

        ctk.CTkLabel(
            box,
            text=title,
            font=ctk.CTkFont(size=28, weight="bold"),
            text_color=self.parent_app.T("TEXT"),
        ).pack(anchor="w", padx=28, pady=(28, 10))

        ctk.CTkLabel(
            box,
            text=desc,
            justify="left",
            wraplength=520,
            font=ctk.CTkFont(size=15),
            text_color=self.parent_app.T("TEXT_SOFT"),
        ).pack(anchor="w", padx=28, pady=(0, 20))

        ctk.CTkButton(
            box,
            text="Voltar ao Login do Chat IA",
            command=self.build_login_screen,
            height=46,
            corner_radius=14,
            fg_color=self.parent_app.T("ACCENT"),
            hover_color=self.parent_app.T("ACCENT_HOVER"),
            text_color=self.parent_app.T("TAG_TEXT"),
            font=ctk.CTkFont(size=14, weight="bold"),
        ).pack(anchor="w", padx=28, pady=(0, 20))


class BlueprintEditorWindow(ctk.CTkToplevel):
    STEP_TYPES = ["text", "attachment", "user_mention"]

    def __init__(
        self,
        parent_app: "NagiApp",
        command_name: str,
        blueprint_path: Path,
        blueprint_data: dict,
    ):
        super().__init__(parent_app)

        self.parent_app = parent_app
        self.command_name = command_name
        self.blueprint_path = blueprint_path
        self.data = blueprint_data

        self.title(f"NAGI // Editor Blueprint // {command_name}")
        self.configure(fg_color=parent_app.T("BG"))

        width = 1180
        height = 820
        screen_w = self.winfo_screenwidth()
        screen_h = self.winfo_screenheight()
        x = max(20, (screen_w - width) // 2)
        y = max(20, (screen_h - height) // 2)
        self.geometry(f"{width}x{height}+{x}+{y}")
        self.minsize(1080, 760)

        self.transient(parent_app)
        self.focus()
        self.grab_set()

        self.step_widgets = []

        self.build_ui()

    def build_ui(self):
        outer = ctk.CTkFrame(self, fg_color="transparent")
        outer.pack(fill="both", expand=True, padx=18, pady=18)

        top = ctk.CTkFrame(
            outer,
            fg_color=self.parent_app.T("CARD"),
            corner_radius=18,
            border_width=1,
            border_color=self.parent_app.T("BORDER"),
        )
        top.pack(fill="x", pady=(0, 12))

        ctk.CTkLabel(
            top,
            text=f"Editor de Blueprint // !{self.command_name}",
            font=ctk.CTkFont(size=28, weight="bold"),
            text_color=self.parent_app.T("TEXT"),
        ).pack(anchor="w", padx=18, pady=(18, 6))

        ctk.CTkLabel(
            top,
            text=f"Arquivo: {self.blueprint_path}",
            font=ctk.CTkFont(size=12),
            text_color=self.parent_app.T("TEXT_SOFT"),
            wraplength=1050,
            justify="left",
        ).pack(anchor="w", padx=18, pady=(0, 14))

        content = ctk.CTkScrollableFrame(
            outer,
            fg_color=self.parent_app.T("CARD"),
            corner_radius=18,
            border_width=1,
            border_color=self.parent_app.T("BORDER"),
        )
        content.pack(fill="both", expand=True)

        # ===== BLOCO GERAL =====
        general = self._section(content, "Configurações gerais")
        self.bp_command_name = self._entry(general, "Nome do comando")
        self.bp_command_name.insert(0, str(self.data.get("command_name", "")))
        self.bp_command_name.pack(fill="x", padx=14, pady=6)

        self.bp_type = self._entry(general, "Tipo")
        self.bp_type.insert(0, str(self.data.get("type", "generic_flow")))
        self.bp_type.pack(fill="x", padx=14, pady=6)

        self.bp_enabled = ctk.CTkCheckBox(
            general,
            text="Comando habilitado",
            text_color=self.parent_app.T("TEXT"),
        )
        if bool(self.data.get("enabled", True)):
            self.bp_enabled.select()
        self.bp_enabled.pack(anchor="w", padx=14, pady=8)

        self.bp_guild_id = self._entry(general, "Guild ID")
        self.bp_guild_id.insert(0, str(self.data.get("guild_id", "")))
        self.bp_guild_id.pack(fill="x", padx=14, pady=6)

        allowed_role_ids = self.data.get("allowed_role_ids", []) or []
        self.bp_allowed_role_ids = self._entry(
            general, "Allowed role IDs (separados por vírgula)"
        )
        self.bp_allowed_role_ids.insert(0, ",".join(map(str, allowed_role_ids)))
        self.bp_allowed_role_ids.pack(fill="x", padx=14, pady=6)

        self.bp_target_channel_id = self._entry(general, "Target channel ID")
        self.bp_target_channel_id.insert(0, str(self.data.get("target_channel_id", "")))
        self.bp_target_channel_id.pack(fill="x", padx=14, pady=6)

        self.bp_mention_role_id = self._entry(general, "Mention role ID")
        self.bp_mention_role_id.insert(0, str(self.data.get("mention_role_id", "")))
        self.bp_mention_role_id.pack(fill="x", padx=14, pady=6)

        # ===== EMBED =====
        embed = self.data.get("embed", {}) or {}
        embed_sec = self._section(content, "Embed")

        self.bp_embed_title = self._entry(embed_sec, "Título")
        self.bp_embed_title.insert(0, str(embed.get("title", "")))
        self.bp_embed_title.pack(fill="x", padx=14, pady=6)

        self.bp_embed_desc = self._textbox(embed_sec, height=90)
        self.bp_embed_desc.insert("1.0", str(embed.get("description", "")))
        self.bp_embed_desc.pack(fill="x", padx=14, pady=6)

        self.bp_embed_color = self._entry(embed_sec, "Cor (inteiro)")
        self.bp_embed_color.insert(0, str(embed.get("color", 15830058)))
        self.bp_embed_color.pack(fill="x", padx=14, pady=6)

        self.bp_embed_footer = self._entry(embed_sec, "Footer")
        self.bp_embed_footer.insert(0, str(embed.get("footer", "")))
        self.bp_embed_footer.pack(fill="x", padx=14, pady=6)

        # ===== ACTIONS =====
        actions = self.data.get("actions", {}) or {}
        act_sec = self._section(content, "Actions")

        self.bp_grant_role_to_mentioned = ctk.CTkCheckBox(
            act_sec,
            text="Conceder cargo ao usuário mencionado",
            text_color=self.parent_app.T("TEXT"),
        )
        if bool(actions.get("grant_role_to_mentioned_user", False)):
            self.bp_grant_role_to_mentioned.select()
        self.bp_grant_role_to_mentioned.pack(anchor="w", padx=14, pady=8)

        self.bp_grant_role_id = self._entry(act_sec, "Grant role ID")
        self.bp_grant_role_id.insert(0, str(actions.get("grant_role_id", "")))
        self.bp_grant_role_id.pack(fill="x", padx=14, pady=6)

        # ===== FLOW =====
        flow = self.data.get("flow", {}) or {}
        flow_sec = self._section(content, "Flow")

        self.bp_collect_in_channel = ctk.CTkCheckBox(
            flow_sec,
            text="Collect in channel",
            text_color=self.parent_app.T("TEXT"),
        )
        if bool(flow.get("collect_in_channel", True)):
            self.bp_collect_in_channel.select()
        self.bp_collect_in_channel.pack(anchor="w", padx=14, pady=8)

        self.bp_allow_cancel = ctk.CTkCheckBox(
            flow_sec,
            text="Allow cancel",
            text_color=self.parent_app.T("TEXT"),
        )
        if bool(flow.get("allow_cancel", True)):
            self.bp_allow_cancel.select()
        self.bp_allow_cancel.pack(anchor="w", padx=14, pady=8)

        steps_sec = self._section(content, "Steps")

        self.steps_wrap = ctk.CTkFrame(steps_sec, fg_color="transparent")
        self.steps_wrap.pack(fill="x", padx=8, pady=(0, 8))

        steps = flow.get("steps", []) or []
        for step in steps:
            self._add_step_editor(step)

        btns = ctk.CTkFrame(steps_sec, fg_color="transparent")
        btns.pack(fill="x", padx=14, pady=(0, 14))

        ctk.CTkButton(
            btns,
            text="+ Adicionar passo",
            command=self.add_empty_step,
            height=42,
            corner_radius=12,
            fg_color=self.parent_app.T("ACCENT"),
            hover_color=self.parent_app.T("ACCENT_HOVER"),
            text_color=self.parent_app.T("TAG_TEXT"),
            font=ctk.CTkFont(size=13, weight="bold"),
        ).pack(side="left")

        # ===== BOTOES FINAIS =====
        footer = ctk.CTkFrame(outer, fg_color="transparent")
        footer.pack(fill="x", pady=(12, 0))

        ctk.CTkButton(
            footer,
            text="Salvar Blueprint",
            command=self.save_blueprint,
            height=46,
            corner_radius=14,
            fg_color=self.parent_app.T("ACCENT"),
            hover_color=self.parent_app.T("ACCENT_HOVER"),
            text_color=self.parent_app.T("TAG_TEXT"),
            font=ctk.CTkFont(size=14, weight="bold"),
        ).pack(side="left", padx=(0, 8))

        ctk.CTkButton(
            footer,
            text="Fechar",
            command=self.destroy,
            height=46,
            corner_radius=14,
            fg_color=self.parent_app.T("CARD_2"),
            hover_color=self.parent_app.T("ACCENT_SOFT"),
            text_color=self.parent_app.T("TEXT"),
            border_width=1,
            border_color=self.parent_app.T("BORDER"),
            font=ctk.CTkFont(size=14, weight="bold"),
        ).pack(side="left")

    def _section(self, parent, title: str):
        box = ctk.CTkFrame(
            parent,
            fg_color=self.parent_app.T("CARD_2"),
            corner_radius=16,
            border_width=1,
            border_color=self.parent_app.T("BORDER"),
        )
        box.pack(fill="x", padx=12, pady=10)

        ctk.CTkLabel(
            box,
            text=title,
            font=ctk.CTkFont(size=18, weight="bold"),
            text_color=self.parent_app.T("TEXT"),
        ).pack(anchor="w", padx=14, pady=(12, 8))

        return box

    def _entry(self, parent, placeholder: str):
        return ctk.CTkEntry(
            parent,
            placeholder_text=placeholder,
            height=40,
            corner_radius=12,
            fg_color=self.parent_app.T("CARD_3"),
            border_width=1,
            border_color=self.parent_app.T("BORDER"),
            text_color=self.parent_app.T("TEXT"),
            placeholder_text_color=self.parent_app.T("MUTED"),
        )

    def _textbox(self, parent, height=90):
        return ctk.CTkTextbox(
            parent,
            height=height,
            fg_color=self.parent_app.T("CARD_3"),
            border_width=1,
            border_color=self.parent_app.T("BORDER"),
            text_color=self.parent_app.T("TEXT"),
            corner_radius=12,
            wrap="word",
        )

    def add_empty_step(self):
        self._add_step_editor(
            {
                "id": "",
                "type": "text",
                "label": "",
                "ask": "",
            }
        )

    def _add_step_editor(self, step_data: dict):
        card = ctk.CTkFrame(
            self.steps_wrap,
            fg_color=self.parent_app.T("CARD_3"),
            corner_radius=14,
            border_width=1,
            border_color=self.parent_app.T("BORDER"),
        )
        card.pack(fill="x", padx=8, pady=8)

        top = ctk.CTkFrame(card, fg_color="transparent")
        top.pack(fill="x", padx=12, pady=(10, 4))

        ctk.CTkLabel(
            top,
            text="Step",
            font=ctk.CTkFont(size=15, weight="bold"),
            text_color=self.parent_app.T("TEXT"),
        ).pack(side="left")

        ctk.CTkButton(
            top,
            text="Remover",
            width=110,
            height=34,
            corner_radius=10,
            fg_color=self.parent_app.T("CARD_2"),
            hover_color=self.parent_app.T("ACCENT_SOFT"),
            text_color=self.parent_app.T("TEXT"),
            border_width=1,
            border_color=self.parent_app.T("BORDER"),
            command=lambda c=card: self.remove_step_editor(c),
        ).pack(side="right")

        step_id = self._entry(card, "ID")
        step_id.insert(0, str(step_data.get("id", "")))
        step_id.pack(fill="x", padx=12, pady=4)

        step_label = self._entry(card, "Label")
        step_label.insert(0, str(step_data.get("label", "")))
        step_label.pack(fill="x", padx=12, pady=4)

        step_ask = self._entry(card, "Pergunta (ask)")
        step_ask.insert(0, str(step_data.get("ask", "")))
        step_ask.pack(fill="x", padx=12, pady=4)

        step_type = ctk.CTkOptionMenu(
            card,
            values=self.STEP_TYPES,
            fg_color=self.parent_app.T("CARD_2"),
            button_color=self.parent_app.T("ACCENT"),
            button_hover_color=self.parent_app.T("ACCENT_HOVER"),
            text_color=self.parent_app.T("TEXT"),
            dropdown_fg_color=self.parent_app.T("CARD_2"),
            dropdown_text_color=self.parent_app.T("TEXT"),
            dropdown_hover_color=self.parent_app.T("ACCENT_SOFT"),
        )
        step_type.set(str(step_data.get("type", "text")))
        step_type.pack(fill="x", padx=12, pady=(4, 12))

        self.step_widgets.append(
            {
                "card": card,
                "id": step_id,
                "label": step_label,
                "ask": step_ask,
                "type": step_type,
            }
        )

    def remove_step_editor(self, card):
        for item in list(self.step_widgets):
            if item["card"] == card:
                self.step_widgets.remove(item)
                break
        card.destroy()

    def save_blueprint(self):
        try:
            color_value = int(self.bp_embed_color.get().strip() or "15830058")
        except Exception:
            color_value = 15830058

        allowed_roles_raw = self.bp_allowed_role_ids.get().strip()
        allowed_roles = [x.strip() for x in allowed_roles_raw.split(",") if x.strip()]

        steps = []
        for item in self.step_widgets:
            step = {
                "id": item["id"].get().strip(),
                "type": item["type"].get().strip(),
                "label": item["label"].get().strip(),
                "ask": item["ask"].get().strip(),
            }
            if step["id"] or step["label"] or step["ask"]:
                steps.append(step)

        command_name = self.bp_command_name.get().strip()

        data = {
            "type": self.bp_type.get().strip() or "generic_flow",
            "command_name": command_name,
            "aliases": self.data.get("aliases", []),
            "enabled": bool(self.bp_enabled.get()),
            "guild_id": self.bp_guild_id.get().strip(),
            "allowed_role_ids": allowed_roles,
            "target_channel_id": self.bp_target_channel_id.get().strip(),
            "mention_role_id": self.bp_mention_role_id.get().strip(),
            "embed": {
                "title": self.bp_embed_title.get().strip(),
                "description": self.bp_embed_desc.get("1.0", "end").strip(),
                "color": color_value,
                "footer": self.bp_embed_footer.get().strip(),
            },
            "flow": {
                "collect_in_channel": bool(self.bp_collect_in_channel.get()),
                "allow_cancel": bool(self.bp_allow_cancel.get()),
                "steps": steps,
            },
            "actions": {
                "grant_role_to_mentioned_user": bool(
                    self.bp_grant_role_to_mentioned.get()
                ),
                "grant_role_id": self.bp_grant_role_id.get().strip(),
            },
        }

        try:
            self.blueprint_path.write_text(
                json.dumps(data, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )

            self.parent_app.log(f"Blueprint salvo com sucesso: {self.blueprint_path}")

            ok, msg = generate_command_from_blueprint(command_name)
            if ok:
                self.parent_app.log(f"JS regenerado com sucesso para !{command_name}")
                self.parent_app.log(msg)
            else:
                self.parent_app.log(f"Erro ao regenerar JS de !{command_name}: {msg}")

            self.parent_app.refresh_commands_list()
            self.destroy()

        except Exception as e:
            self.parent_app.log(f"Erro ao salvar blueprint: {e}")


if __name__ == "__main__":

    try:
        update, version = check_update()

        if update:
            print(f"[NAGI] Nova versão disponível: {version}")
        else:
            print("[NAGI] Nagi está atualizado")

    except Exception as e:
        print(f"[NAGI] Falha ao verificar atualização: {e}")

    app = NagiApp()
    app.mainloop()
