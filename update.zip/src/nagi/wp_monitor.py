from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple

import aiohttp

from .storage import load_json, save_json

WP_FILE = "wp_sites.json"


@dataclass
class CheckResult:
    ok: bool
    status: Optional[int]
    latency_ms: Optional[int]
    error: Optional[str]


def load_wp_data() -> Dict[str, Any]:
    # Estrutura:
    # {
    #   "sites": {
    #       "nome": {
    #           "url": "...",
    #           "enabled": true,
    #           "last": {"ok": true/false, "status": 200, "latency_ms": 123, "ts": 1234567890}
    #       }
    #   },
    #   "slow_threshold_ms": 3500
    # }
    return load_json(
        WP_FILE,
        {
            "sites": {},
            "slow_threshold_ms": 3500,
        },
    )


def save_wp_data(data: Dict[str, Any]) -> None:
    save_json(WP_FILE, data)


def ensure_default_site() -> None:
    data = load_wp_data()
    sites = data.setdefault("sites", {})

    # Registra o site padrão se ainda não existir
    if "euvivodisso_zero_ao_digital" not in sites:
        sites["euvivodisso_zero_ao_digital"] = {
            "url": "https://euvivodisso.com/zero-ao-digital/",
            "enabled": True,
            "last": None,
        }
        save_wp_data(data)


async def check_url(url: str, timeout_s: int = 10) -> CheckResult:
    t0 = time.perf_counter()
    timeout = aiohttp.ClientTimeout(total=timeout_s)

    # Tentamos GET (mais compatível que HEAD em alguns hosts)
    try:
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(url, allow_redirects=True) as resp:
                # Só ler um pedacinho evita travar em respostas enormes
                await resp.content.read(256)

                dt = time.perf_counter() - t0
                latency_ms = int(dt * 1000)

                status = resp.status
                ok = 200 <= status < 400

                return CheckResult(ok=ok, status=status, latency_ms=latency_ms, error=None)
    except Exception as e:
        dt = time.perf_counter() - t0
        latency_ms = int(dt * 1000)
        return CheckResult(ok=False, status=None, latency_ms=latency_ms, error=str(e))


def upsert_site(name: str, url: str) -> None:
    data = load_wp_data()
    sites = data.setdefault("sites", {})

    key = name.strip() or "site"
    sites[key] = {
        "url": url.strip(),
        "enabled": True,
        "last": sites.get(key, {}).get("last"),
    }
    save_wp_data(data)


def list_sites() -> Dict[str, Any]:
    data = load_wp_data()
    return data.get("sites", {}) or {}


def set_enabled(name: str, enabled: bool) -> None:
    data = load_wp_data()
    sites = data.setdefault("sites", {})
    if name in sites:
        sites[name]["enabled"] = bool(enabled)
        save_wp_data(data)


def update_last(name: str, result: CheckResult) -> Tuple[Optional[Dict[str, Any]], Dict[str, Any]]:
    """
    Atualiza last e retorna (last_anterior, last_novo)
    """
    data = load_wp_data()
    sites = data.setdefault("sites", {})
    if name not in sites:
        sites[name] = {"url": "", "enabled": True, "last": None}

    prev = sites[name].get("last")
    now = {
        "ok": result.ok,
        "status": result.status,
        "latency_ms": result.latency_ms,
        "error": result.error,
        "ts": int(time.time()),
    }
    sites[name]["last"] = now
    save_wp_data(data)
    return prev, now


def get_slow_threshold_ms() -> int:
    data = load_wp_data()
    try:
        return int(data.get("slow_threshold_ms", 3500))
    except Exception:
        return 3500