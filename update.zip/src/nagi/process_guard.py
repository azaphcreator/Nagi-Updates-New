from __future__ import annotations

import os
import psutil

PID_FILE = "nagi_pid.txt"


def write_pid() -> None:
    pid = os.getpid()
    with open(PID_FILE, "w", encoding="utf-8") as f:
        f.write(str(pid))


def read_pid() -> int | None:
    try:
        with open(PID_FILE, "r", encoding="utf-8") as f:
            return int(f.read().strip())
    except Exception:
        return None


def pid_is_running(pid: int) -> bool:
    try:
        p = psutil.Process(pid)
        return p.is_running() and p.status() != psutil.STATUS_ZOMBIE
    except Exception:
        return False


def kill_pid(pid: int) -> bool:
    try:
        p = psutil.Process(pid)
        p.terminate()
        try:
            p.wait(timeout=3)
        except Exception:
            p.kill()
        return True
    except Exception:
        return False