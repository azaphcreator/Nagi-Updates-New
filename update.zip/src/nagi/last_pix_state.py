from __future__ import annotations

from typing import Any, Dict, Optional

from .storage import load_json, save_json


FILE_NAME = "last_pix_context.json"


def save_last_pix(data: Dict[str, Any]) -> None:
    save_json(FILE_NAME, {"last_pix": data})


def load_last_pix() -> Optional[Dict[str, Any]]:
    data = load_json(FILE_NAME, {"last_pix": None})
    value = data.get("last_pix")
    return value if isinstance(value, dict) else None


def clear_last_pix() -> None:
    save_json(FILE_NAME, {"last_pix": None})