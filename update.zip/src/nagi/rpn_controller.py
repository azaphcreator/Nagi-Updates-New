from __future__ import annotations

import os
import subprocess
import signal
import psutil

RPN_DIR = r"C:\Users\RPN\Desktop\RPN BOT"
RPN_ENTRY = "index.js"

_process = None


def is_running() -> bool:
    global _process
    if _process and _process.poll() is None:
        return True
    return False


def start_rpn() -> str:
    global _process

    if is_running():
        return "RPN BOT já está rodando."

    try:
        _process = subprocess.Popen(
            ["node", RPN_ENTRY],
            cwd=RPN_DIR,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return "RPN BOT iniciado com sucesso."
    except Exception as e:
        return f"Erro ao iniciar RPN BOT: {e}"


def stop_rpn() -> str:
    global _process

    if not is_running():
        return "RPN BOT não está rodando."

    try:
        pid = _process.pid
        p = psutil.Process(pid)
        p.terminate()
        p.wait(timeout=5)
        return "RPN BOT encerrado com sucesso."
    except Exception as e:
        return f"Erro ao encerrar RPN BOT: {e}"


def status_rpn() -> str:
    if is_running():
        return "RPN BOT está ONLINE."
    return "RPN BOT está OFFLINE."