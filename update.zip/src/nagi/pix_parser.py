from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Tuple


def _parse_tlv(payload: str, start: int = 0, end: Optional[int] = None) -> Tuple[Dict[str, str], int]:
    if end is None:
        end = len(payload)

    i = start
    out: Dict[str, str] = {}

    while i + 4 <= end:
        tag = payload[i:i + 2]
        ln_str = payload[i + 2:i + 4]

        if not ln_str.isdigit():
            break

        ln = int(ln_str)
        i += 4

        if i + ln > end:
            break

        val = payload[i:i + ln]
        i += ln
        out[tag] = val

    return out, i


@dataclass
class PixInfo:
    is_emv: bool
    amount: Optional[str] = None


def parse_pix_emv(pix_code: str) -> PixInfo:
    code = (pix_code or "").strip()

    if len(code) < 10 or not code.startswith("000201"):
        return PixInfo(is_emv=False, amount=None)

    root, _ = _parse_tlv(code)
    amount = root.get("54")

    return PixInfo(is_emv=True, amount=amount)