from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path
from typing import Optional, Tuple

import requests


class DiscordAIAgent:
    def __init__(self):
        self.provider = (os.getenv("DISCORD_AI_PROVIDER", "ollama") or "ollama").strip().lower()
        self.model = (os.getenv("DISCORD_AI_MODEL", "llama3.1:8b") or "llama3.1:8b").strip()

        self.ollama_url = (os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434") or "").rstrip("/")
        self.openai_base_url = (os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1") or "").rstrip("/")
        self.openai_api_key = (os.getenv("OPENAI_API_KEY", "") or "").strip()

        raw_bot_dir = (os.getenv("DISCORD_AI_BOT_DIR") or os.getenv("RPN_BOT_DIR") or "").strip()
        self.bot_dir = Path(raw_bot_dir) if raw_bot_dir else None

        raw_commands_dir = (os.getenv("DISCORD_AI_COMMANDS_DIR") or "").strip()
        if raw_commands_dir:
            self.commands_dir = Path(raw_commands_dir)
        elif self.bot_dir:
            self.commands_dir = self.bot_dir / "commands" / "ai"
        else:
            self.commands_dir = None

    def _owner_allowed(self, controller_username: str) -> bool:
        return (controller_username or "").strip().lower() == "azaph"

    def _validate_base(self) -> Tuple[bool, str]:
        if not self.bot_dir:
            return False, "DISCORD_AI_BOT_DIR não configurado no .env"

        if not self.bot_dir.exists():
            return False, f"Pasta do bot não encontrada: {self.bot_dir}"

        if not self.commands_dir:
            return False, "DISCORD_AI_COMMANDS_DIR não definido."

        self.commands_dir.mkdir(parents=True, exist_ok=True)
        return True, "OK"

    def _extract_json(self, text: str) -> Optional[dict]:
        text = (text or "").strip()
        if not text:
            return None

        match = re.search(r"\{.*\}", text, re.DOTALL)
        if not match:
            return None

        try:
            return json.loads(match.group(0))
        except Exception:
            return None

    def _fallback_plan(self, prompt: str) -> dict:
        prompt = (prompt or "").strip()

        command_match = re.search(r"!(\w+)", prompt)
        command_name = command_match.group(1).lower() if command_match else "novo"

        response_text = "Comando criado pelo Nagi."
        m = re.search(
            r"(?:responda|responder|fale|diga|envie)\s+['\"]?(.+?)['\"]?$",
            prompt,
            re.IGNORECASE,
        )
        if m:
            response_text = m.group(1).strip()

        owner_only = any(
            k in prompt.lower()
            for k in [
                "só o azaph",
                "somente azaph",
                "apenas azaph",
                "somente eu",
                "só eu",
                "owner only",
                "apenas owner",
            ]
        )

        delete_trigger = "apague a mensagem" in prompt.lower() or "delete a mensagem" in prompt.lower()
        dm_author = "mande no privado" in prompt.lower() or "envie no privado" in prompt.lower()

        return {
            "action": "create_or_update_command",
            "command_name": command_name,
            "description": f"Comando gerado por IA a partir de: {prompt[:80]}",
            "aliases": [],
            "owner_only": owner_only,
            "delete_trigger": delete_trigger,
            "dm_author": dm_author,
            "reply_text": response_text,
            "react_emoji": None,
        }

    def _call_llm(self, prompt: str) -> dict:
        system_prompt = """
Você é um planejador de automações para bot de Discord em Node.js.
Sua tarefa é converter um pedido em linguagem natural em JSON puro.
Responda SOMENTE JSON válido.

Formato obrigatório:
{
  "action": "create_or_update_command",
  "command_name": "nome_sem_!",
  "description": "descrição curta",
  "aliases": ["alias1", "alias2"],
  "owner_only": false,
  "delete_trigger": false,
  "dm_author": false,
  "reply_text": "texto que o comando enviará",
  "react_emoji": null
}

Regras:
- command_name nunca deve ter "!".
- aliases pode ser vazio.
- reply_text deve ser simples.
- owner_only true quando o pedido disser que só Azaph/owner pode usar.
- delete_trigger true quando o pedido mandar apagar a mensagem original.
- dm_author true quando o pedido mandar responder no privado.
- react_emoji pode ser null ou emoji simples.
""".strip()

        user_prompt = f"Pedido do usuário:\n{prompt}"

        if self.provider == "openai":
            if not self.openai_api_key:
                raise RuntimeError("OPENAI_API_KEY não configurada.")
            url = f"{self.openai_base_url}/chat/completions"
            headers = {
                "Authorization": f"Bearer {self.openai_api_key}",
                "Content-Type": "application/json",
            }
            payload = {
                "model": self.model,
                "temperature": 0.1,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
            }
            resp = requests.post(url, json=payload, headers=headers, timeout=60)
            resp.raise_for_status()
            data = resp.json()
            content = data["choices"][0]["message"]["content"]
            parsed = self._extract_json(content)
            if not parsed:
                raise RuntimeError("A IA não retornou JSON válido.")
            return parsed

        url = f"{self.ollama_url}/api/chat"
        payload = {
            "model": self.model,
            "stream": False,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        }
        resp = requests.post(url, json=payload, timeout=120)
        resp.raise_for_status()
        data = resp.json()
        content = ((data.get("message") or {}).get("content") or "").strip()
        parsed = self._extract_json(content)
        if not parsed:
            raise RuntimeError("A IA não retornou JSON válido.")
        return parsed

    def _plan(self, prompt: str) -> dict:
        try:
            data = self._call_llm(prompt)
            if not isinstance(data, dict):
                raise RuntimeError("Planejamento inválido.")
            return data
        except Exception:
            return self._fallback_plan(prompt)

    def _safe_js_string(self, text: Optional[str]) -> str:
        return json.dumps(text or "", ensure_ascii=False)

    def _build_js_command(self, spec: dict) -> str:
        command_name = re.sub(r"[^a-zA-Z0-9_-]", "", (spec.get("command_name") or "novo").strip().lower()) or "novo"

        aliases = spec.get("aliases") or []
        if not isinstance(aliases, list):
            aliases = []

        aliases_clean = []
        for a in aliases:
            a = re.sub(r"[^a-zA-Z0-9_-]", "", str(a).strip().lower())
            if a and a != command_name and a not in aliases_clean:
                aliases_clean.append(a)

        description = str(spec.get("description") or f"Comando {command_name} criado por IA.").strip()
        reply_text = str(spec.get("reply_text") or "Comando executado.").strip()
        react_emoji = spec.get("react_emoji")
        owner_only = bool(spec.get("owner_only"))
        delete_trigger = bool(spec.get("delete_trigger"))
        dm_author = bool(spec.get("dm_author"))

        return f"""const OWNER_ID = process.env.OWNER_ID || "";

module.exports = {{
  name: {self._safe_js_string(command_name)},
  aliases: {json.dumps(aliases_clean, ensure_ascii=False)},
  description: {self._safe_js_string(description)},
  async execute(message, args, client) {{
    try {{
      if ({str(owner_only).lower()}) {{
        if (!message.author || String(message.author.id) !== String(OWNER_ID)) {{
          return;
        }}
      }}

      if ({str(delete_trigger).lower()}) {{
        await message.delete().catch(() => null);
      }}

      const responseText = {self._safe_js_string(reply_text)};

      if ({str(dm_author).lower()}) {{
        await message.author.send(responseText).catch(() => null);
      }} else {{
        await message.channel.send(responseText);
      }}

      const reaction = {json.dumps(react_emoji, ensure_ascii=False)};
      if (reaction) {{
        await message.react(reaction).catch(() => null);
      }}
    }} catch (err) {{
      console.error("[NAGI-AI-COMMAND] erro em {command_name}:", err);
      try {{
        await message.channel.send("Erro ao executar o comando.");
      }} catch (_) {{}}
    }}
  }},
}};
"""

    def preview_prompt(self, controller_username: str, prompt: str) -> Tuple[bool, str]:
        if not self._owner_allowed(controller_username):
            return False, "Acesso negado. Somente Azaph pode usar a IA administrativa do bot."

        ok, msg = self._validate_base()
        if not ok:
            return False, msg

        prompt = (prompt or "").strip()
        if not prompt:
            return False, "Descreva o comando que deseja criar."

        spec = self._plan(prompt)
        code = self._build_js_command(spec)

        command_name = re.sub(r"[^a-zA-Z0-9_-]", "", (spec.get("command_name") or "novo").strip().lower()) or "novo"
        file_path = self.commands_dir / f"{command_name}.js"

        preview = (
            f"PRÉVIA DA IA\n\n"
            f"Bot: {self.bot_dir}\n"
            f"Comando: !{command_name}\n"
            f"Arquivo: {file_path}\n\n"
            f"Especificação:\n{json.dumps(spec, ensure_ascii=False, indent=2)}\n\n"
            f"Código gerado:\n{'-' * 60}\n{code}"
        )
        return True, preview

    def apply_prompt(self, controller_username: str, prompt: str) -> Tuple[bool, str]:
        if not self._owner_allowed(controller_username):
            return False, "Acesso negado. Somente Azaph pode usar a IA administrativa do bot."

        ok, msg = self._validate_base()
        if not ok:
            return False, msg

        prompt = (prompt or "").strip()
        if not prompt:
            return False, "Descreva o comando que deseja criar."

        spec = self._plan(prompt)
        code = self._build_js_command(spec)

        command_name = re.sub(r"[^a-zA-Z0-9_-]", "", (spec.get("command_name") or "novo").strip().lower()) or "novo"
        file_path = self.commands_dir / f"{command_name}.js"

        if file_path.exists():
            backup_name = f"{command_name}.backup_{int(time.time())}.js"
            backup_path = self.commands_dir / backup_name
            backup_path.write_text(file_path.read_text(encoding="utf-8"), encoding="utf-8")

        file_path.write_text(code, encoding="utf-8")

        return True, (
            f"Comando aplicado com sucesso.\n\n"
            f"Nome: !{command_name}\n"
            f"Arquivo: {file_path}\n"
            f"Pasta do bot: {self.bot_dir}\n\n"
            f"Descrição: {spec.get('description') or '-'}\n"
            f"Owner only: {'sim' if spec.get('owner_only') else 'não'}\n"
            f"DM autor: {'sim' if spec.get('dm_author') else 'não'}\n"
            f"Apaga mensagem: {'sim' if spec.get('delete_trigger') else 'não'}"
        )