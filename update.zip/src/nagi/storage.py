from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict


ROOT_DIR = Path(__file__).resolve().parents[2]  # .../Nagi
DATA_DIR = ROOT_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)


def load_json(filename: str, default: Dict[str, Any]) -> Dict[str, Any]:
    path = DATA_DIR / filename
    if not path.exists():
        save_json(filename, default)
        return default

    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def save_json(filename: str, data: Dict[str, Any]) -> None:
    path = DATA_DIR / filename
    path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )