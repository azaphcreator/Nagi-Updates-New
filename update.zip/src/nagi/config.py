from __future__ import annotations

import os
from dataclasses import dataclass

from dotenv import load_dotenv


@dataclass(frozen=True)
class Settings:
    discord_token: str
    owner_id: int
    log_level: str
    default_profile: str
    nagi_webhook_url: str
    nagi_webhook_token: str
    nagi_webhook_timeout: int


def get_settings() -> Settings:
    load_dotenv()

    token = os.getenv("DISCORD_TOKEN", "").strip()
    owner = os.getenv("OWNER_ID", "").strip()
    log_level = (os.getenv("LOG_LEVEL", "INFO") or "INFO").strip()
    default_profile = (os.getenv("DEFAULT_PROFILE", "Casa") or "Casa").strip()

    nagi_webhook_url = os.getenv("NAGI_WEBHOOK_URL", "").strip()
    nagi_webhook_token = os.getenv("NAGI_WEBHOOK_TOKEN", "").strip()

    timeout_raw = (os.getenv("NAGI_WEBHOOK_TIMEOUT", "20") or "20").strip()
    try:
        nagi_webhook_timeout = int(timeout_raw)
    except ValueError:
        nagi_webhook_timeout = 20

    if not token:
        raise RuntimeError("DISCORD_TOKEN não definido no .env")

    if not owner.isdigit():
        raise RuntimeError("OWNER_ID inválido no .env (precisa ser número)")

    return Settings(
        discord_token=token,
        owner_id=int(owner),
        log_level=log_level,
        default_profile=default_profile,
        nagi_webhook_url=nagi_webhook_url,
        nagi_webhook_token=nagi_webhook_token,
        nagi_webhook_timeout=nagi_webhook_timeout,
    )