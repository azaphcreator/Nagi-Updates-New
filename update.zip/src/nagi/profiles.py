from __future__ import annotations

from dataclasses import dataclass
from typing import Dict

from .storage import load_json, save_json

PROFILES_FILE = "profiles.json"


@dataclass
class ProfileState:
    current: str
    profiles: Dict[str, Dict]


def load_profiles(default_profile: str) -> ProfileState:
    data = load_json(
        PROFILES_FILE,
        {
            "current": default_profile,
            "profiles": {
                "Casa": {"note": "Perfil padrão"},
                "Trabalho": {"note": ""},
                "Rua": {"note": ""},
            },
        },
    )

    return ProfileState(
        current=data.get("current", default_profile),
        profiles=data.get("profiles", {}),
    )


def set_current_profile(name: str, state: ProfileState) -> ProfileState:
    name = name.strip()
    if not name:
        return state

    if name not in state.profiles:
        state.profiles[name] = {"note": ""}

    state.current = name
    save_json(PROFILES_FILE, {"current": state.current, "profiles": state.profiles})
    return state