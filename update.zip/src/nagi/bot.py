from __future__ import annotations

import asyncio
import os
import re
from typing import Optional, Tuple

import aiohttp
import discord
import psutil
from discord.ext import commands

from .config import get_settings
from .last_pix_state import load_last_pix, save_last_pix
from .pix_parser import parse_pix_emv
from .link_pages import generate_pix_page_locked, generate_unlock_code

PID_FILE = "nagi_pid.txt"


def _write_pid() -> None:
    with open(PID_FILE, "w", encoding="utf-8") as f:
        f.write(str(os.getpid()))


def _read_pid() -> Optional[int]:
    try:
        with open(PID_FILE, "r", encoding="utf-8") as f:
            return int(f.read().strip())
    except Exception:
        return None


def _pid_is_running(pid: int) -> bool:
    try:
        p = psutil.Process(pid)
        return p.is_running()
    except Exception:
        return False


def _kill_pid(pid: int) -> None:
    try:
        p = psutil.Process(pid)
        p.terminate()
        try:
            p.wait(timeout=3)
        except Exception:
            p.kill()
    except Exception:
        pass


def _fmt_rate(bytes_per_sec: float) -> str:
    kb_s = bytes_per_sec / 1024.0
    mb_s = bytes_per_sec / (1024.0 * 1024.0)
    mbit_s = (bytes_per_sec * 8.0) / 1_000_000.0
    if mb_s >= 1:
        return f"{mb_s:.2f} MB/s ({mbit_s:.2f} Mbps)"
    return f"{kb_s:.2f} KB/s ({mbit_s:.2f} Mbps)"


def _parse_pipe_args(text: str) -> list[str]:
    parts = [p.strip() for p in (text or "").split("|")]
    while parts and parts[-1] == "":
        parts.pop()
    return parts


def _format_brl_value(raw: str) -> Optional[str]:
    if raw is None:
        return None

    s = (raw or "").strip()
    if not s:
        return None

    s = s.replace("R$", "").strip()
    s = s.replace(" ", "")
    s = re.sub(r"[^0-9\.,]", "", s)

    if not s:
        return None

    if "," in s:
        s_num = s.replace(".", "").replace(",", ".")
    else:
        s_num = s

    try:
        val = float(s_num)
    except Exception:
        return None

    inteiro, frac = f"{val:.2f}".split(".")
    return f"R$ {inteiro},{frac}"


def _normalize_target_site_key(raw: str) -> Optional[Tuple[str, str]]:
    text = (raw or "").strip().lower()
    text = re.sub(r"\s+", " ", text)

    aliases = {
        "1": ("checkout_1", "Checkout 1"),
        "checkout 1": ("checkout_1", "Checkout 1"),
        "checkout_1": ("checkout_1", "Checkout 1"),
        "links-checkout": ("checkout_1", "Checkout 1"),
        "links checkout": ("checkout_1", "Checkout 1"),
        "2": ("checkout_2", "Checkout 2"),
        "checkout 2": ("checkout_2", "Checkout 2"),
        "checkout_2": ("checkout_2", "Checkout 2"),
        "links-checkout-2": ("checkout_2", "Checkout 2"),
        "links checkout 2": ("checkout_2", "Checkout 2"),
    }

    return aliases.get(text)


def _normalize_origin(raw: str) -> Optional[str]:
    text = (raw or "").strip().lower()

    if text == "rpn":
        return "RPN"

    if text == "hotmart":
        return "Hotmart"

    return None


async def _call_n8n_webhook(
    webhook_url: str,
    webhook_token: str,
    timeout_seconds: int,
    payload: dict,
) -> tuple[bool, str]:
    if not webhook_url:
        return False, "❌ NAGI_WEBHOOK_URL não configurado no .env"

    headers = {"Content-Type": "application/json"}
    if webhook_token:
        headers["X-Nagi-Token"] = webhook_token

    timeout = aiohttp.ClientTimeout(total=timeout_seconds)

    try:
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(webhook_url, json=payload, headers=headers) as resp:
                content_type = (resp.headers.get("Content-Type") or "").lower()

                if "application/json" in content_type:
                    data = await resp.json()
                else:
                    text = await resp.text()
                    data = {"reply": text}

                if resp.status >= 400:
                    msg = (
                        data.get("error")
                        or data.get("message")
                        or data.get("reply")
                        or f"status {resp.status}"
                    )
                    return False, f"❌ Webhook retornou erro {resp.status}: {msg}"

                reply = data.get("reply") or data.get("message") or "✅ Automação executada com sucesso."
                return True, str(reply)

    except asyncio.TimeoutError:
        return False, "❌ O webhook demorou demais para responder."
    except Exception as e:
        return False, f"❌ Erro ao chamar webhook: {e}"


def run() -> None:
    settings = get_settings()

    old_pid = _read_pid()
    if old_pid and old_pid != os.getpid() and _pid_is_running(old_pid):
        print(f"[NAGI] Já existe um Nagi rodando (PID {old_pid}). Use !encerrar pela DM.")
        return

    _write_pid()

    intents = discord.Intents.default()
    intents.message_content = True
    bot = commands.Bot(command_prefix="??", intents=intents)

    def is_dm_from_owner(ctx: commands.Context) -> bool:
        return (
            isinstance(ctx.channel, discord.DMChannel)
            and ctx.author is not None
            and ctx.author.id == settings.owner_id
        )

    def is_dm_message_from_owner(message: discord.Message) -> bool:
        return (
            isinstance(message.channel, discord.DMChannel)
            and message.author is not None
            and not message.author.bot
            and message.author.id == settings.owner_id
        )

    async def dm_owner(text: str) -> None:
        u = bot.get_user(settings.owner_id)
        if not u:
            try:
                u = await bot.fetch_user(settings.owner_id)
            except Exception:
                return
        try:
            await u.send(text)
        except Exception:
            pass

    @bot.check
    async def global_dm_only(ctx):
        return ctx.guild is None

    @bot.event
    async def on_ready():
        await bot.change_presence(status=discord.Status.idle, activity=discord.Game(name="DM only"))
        await dm_owner(
            "🤖 **Nagi ON** ✅\n\n"
            "**PIX/LP:**\n"
            "`??criarpix <nome> | <codigo> | <origem> | <pix>`\n"
            "`??criarpix <nome> | <codigo> | <origem> | <valor> | <pix>`\n"
            "`??criarpix <nome> | | <origem> | <pix>`\n"
            "`??criarpix <nome> | | <origem> | <valor> | <pix>`\n"
            "`??Nagi publicar checkout 1`\n"
            "`??Nagi publicar checkout 2`\n\n"
            "**Planilha:**\n"
            "`??planilha`\n"
            "`??pendentes`\n"
            "`??resumo`\n"
            "`??pago <id>`\n\n"
            "**Cache:**\n"
            "`??limparcache`\n\n"
            "**Sistema:** `??ultimopix`, `??velocidade`, `??encerrar`"
        )

    @bot.event
    async def on_message(message: discord.Message):
        if message is None or message.author is None:
            return

        if message.author.bot:
            return

        # Nagi ignora tudo em servidor
        if message.guild is not None:
            return

        content = (message.content or "").strip()

        if is_dm_message_from_owner(message) and content.lower().startswith("??nagi"):
            user_text = content[5:].strip()

            if not user_text:
                await message.channel.send(
                    "Use:\n"
                    "`??Nagi publicar checkout 1`\n"
                    "`??Nagi publicar checkout 2`"
                )
                return

            lowered = user_text.lower()

            if lowered.startswith("publicar "):
                target_raw = user_text[len("publicar "):].strip()
                target_info = _normalize_target_site_key(target_raw)

                if not target_info:
                    await message.channel.send(
                        "❌ Destino inválido.\n"
                        "Use:\n"
                        "`??Nagi publicar checkout 1`\n"
                        "`??Nagi publicar checkout 2`"
                    )
                    return

                last_pix = load_last_pix()
                if not last_pix:
                    await message.channel.send(
                        "❌ Não encontrei um PIX recente salvo.\n"
                        "Primeiro use `!criarpix ...`."
                    )
                    return

                target_site_key, target_site_label = target_info

                payload = {
                    "source": "discord_dm",
                    "type": "publish_last_pix_to_wordpress",
                    "author_id": str(message.author.id),
                    "author_name": message.author.name,
                    "message": user_text,
                    "raw": content,
                    "target_site_key": target_site_key,
                    "target_site_label": target_site_label,
                    "origin": last_pix.get("origin", "RPN"),
                    "customer": last_pix.get("customer"),
                    "amount": last_pix.get("amount"),
                    "unlock_code": last_pix.get("unlock_code"),
                    "pix_code": last_pix.get("pix_code"),
                    "file_name": last_pix.get("file_name"),
                    "file_path": last_pix.get("file_path"),
                    "company_fixed": last_pix.get("company_fixed", "RPN"),
                    "title": last_pix.get("title", "Copiar Pix"),
                }

                await message.channel.send(f"🚀 Publicando no **{target_site_label}**...")

                ok, reply = await _call_n8n_webhook(
                    webhook_url=settings.nagi_webhook_url,
                    webhook_token=settings.nagi_webhook_token,
                    timeout_seconds=settings.nagi_webhook_timeout,
                    payload=payload,
                )

                await message.channel.send(reply)
                return

        await bot.process_commands(message)

    @bot.command(name="ultimopix")
    async def ultimopix(ctx: commands.Context):
        if not is_dm_from_owner(ctx):
            return

        data = load_last_pix()
        if not data:
            await ctx.send("Nenhum PIX salvo ainda.")
            return

        summary = (
            f"**Último PIX salvo**\n"
            f"Cliente: {data.get('customer') or '-'}\n"
            f"Código: {data.get('unlock_code') or '-'}\n"
            f"Origem: {data.get('origin') or '-'}\n"
            f"Valor: {data.get('amount') or '-'}\n"
            f"Arquivo: {data.get('file_name') or '-'}"
        )
        await ctx.send(summary)

    @bot.command(name="velocidade")
    async def velocidade(ctx: commands.Context):
        if not is_dm_from_owner(ctx):
            return

        net1 = psutil.net_io_counters()
        await asyncio.sleep(1.0)
        net2 = psutil.net_io_counters()

        down = net2.bytes_recv - net1.bytes_recv
        up = net2.bytes_sent - net1.bytes_sent

        await ctx.send(
            f"📡 **Velocidade da rede**\n"
            f"Download: {_fmt_rate(down)}\n"
            f"Upload: {_fmt_rate(up)}"
        )

    @bot.command(name="limparcache")
    async def limparcache(ctx: commands.Context):
        if not is_dm_from_owner(ctx):
            return

        try:
            save_last_pix({})
            await ctx.send("🧹 Cache do último PIX limpo com sucesso.")
        except Exception as e:
            await ctx.send(f"❌ Erro ao limpar cache: {e}")

    @bot.command(name="encerrar")
    async def encerrar(ctx: commands.Context):
        if not is_dm_from_owner(ctx):
            return

        await ctx.send("🛑 Encerrando Nagi...")
        try:
            await bot.close()
        finally:
            pid = _read_pid()
            if pid:
                _kill_pid(pid)

    @bot.command(name="criarpix")
    async def criarpix(ctx: commands.Context, *, raw: str = ""):
        if not is_dm_from_owner(ctx):
            return

        parts = _parse_pipe_args(raw)

        if len(parts) not in (4, 5):
            await ctx.send(
                "Uso:\n"
                "`??criarpix <nome> | <codigo> | <origem> | <pix>`\n"
                "`??criarpix <nome> | <codigo> | <origem> | <valor> | <pix>`\n"
                "`??criarpix <nome> | | <origem> | <pix>`\n"
                "`??criarpix <nome> | | <origem> | <valor> | <pix>`"
            )
            return

        if len(parts) == 4:
            nome, codigo, origem_raw, pix_code = parts
            amount_raw = ""
        else:
            nome, codigo, origem_raw, amount_raw, pix_code = parts

        nome = nome.strip()
        codigo = codigo.strip()
        origem = _normalize_origin(origem_raw)
        amount = _format_brl_value(amount_raw) if amount_raw.strip() else None
        pix_code = (pix_code or "").strip()

        if not nome:
            await ctx.send("❌ Nome do cliente é obrigatório.")
            return

        if not origem:
            await ctx.send("❌ Origem inválida. Use `RPN` ou `Hotmart`.")
            return

        if not pix_code:
            await ctx.send("❌ Código PIX é obrigatório.")
            return

        try:
            pix_info = parse_pix_emv(pix_code)
        except Exception:
            pix_info = None

        unlock_code = codigo if codigo else generate_unlock_code()

        title = f"Copiar Pix - {nome}"
        output_path = generate_pix_page_locked(
            customer_name=nome,
            pix_code=pix_code,
            unlock_code=unlock_code,
            title=title,
        )

        data = {
            "customer": nome,
            "unlock_code": unlock_code,
            "origin": origem,
            "amount": amount or (pix_info.amount if pix_info else None),
            "pix_code": pix_code,
            "file_name": output_path.name,
            "file_path": str(output_path),
            "company_fixed": "RPN",
            "title": title,
        }
        save_last_pix(data)

        await ctx.send(
            "✅ PIX gerado e salvo no cache.\n\n"
            f"Cliente: {nome}\n"
            f"Código: {unlock_code}\n"
            f"Origem: {origem}\n"
            f"Valor: {data.get('amount') or '-'}\n"
            f"Arquivo: {output_path.name}"
        )

    try:
        bot.run(settings.discord_token)
    finally:
        try:
            if os.path.exists(PID_FILE):
                os.remove(PID_FILE)
        except Exception:
            pass