from __future__ import annotations

from typing import Dict, Optional, Tuple

from .storage import load_json, save_json
from .network import get_network_fingerprint

MAP_FILE = "network_map.json"


def load_map() -> Dict:
    return load_json(
        MAP_FILE,
        {
            "auto": False,
            "profiles": {}
        },
    )


def save_map(data: Dict) -> None:
    save_json(MAP_FILE, data)


def set_auto(enabled: bool) -> None:
    data = load_map()
    data["auto"] = bool(enabled)
    save_map(data)


def map_current_network(profile_name: str) -> Dict:
    data = load_map()
    fp = get_network_fingerprint()

    # Normaliza nome do perfil (mantém o que você digitou, mas sem espaços extras)
    name = (profile_name or "").strip()
    if not name:
        name = "Casa"

    data["profiles"][name] = fp
    save_map(data)
    return fp


def _score_match(saved: Dict, current: Dict) -> int:
    """
    Pontuação de match (quanto maior, melhor)
    - MAC é o mais forte
    - Adapter também ajuda
    - Gateway/SSID confirmam contexto
    - IPv4 é fraco (muda fácil)
    """
    score = 0

    if saved.get("transport") and saved.get("transport") == current.get("transport"):
        score += 10

    # Forte
    if saved.get("mac") and current.get("mac") and saved.get("mac") == current.get("mac"):
        score += 50

    # Médio
    if saved.get("adapter") and current.get("adapter") and saved.get("adapter") == current.get("adapter"):
        score += 20

    # Confirmadores
    if saved.get("gateway") and current.get("gateway") and saved.get("gateway") == current.get("gateway"):
        score += 15

    if saved.get("ssid") and current.get("ssid") and saved.get("ssid") == current.get("ssid"):
        score += 15

    # Fraco
    if saved.get("ipv4") and current.get("ipv4") and saved.get("ipv4") == current.get("ipv4"):
        score += 5

    return score


def detect_profile(min_score: int = 40) -> Tuple[Optional[str], int]:
    """
    Retorna (perfil_detectado, score)
    min_score evita falso positivo (ex.: só 'ethernet' igual).
    """
    data = load_map()
    if not data.get("auto"):
        return None, 0

    current = get_network_fingerprint()
    profiles = data.get("profiles", {}) or {}

    best_name = None
    best_score = 0

    for name, saved in profiles.items():
        if not isinstance(saved, dict):
            continue
        score = _score_match(saved, current)
        if score > best_score:
            best_score = score
            best_name = name

    if best_score >= min_score:
        return best_name, best_score

    return None, best_score