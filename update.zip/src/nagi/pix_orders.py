from __future__ import annotations

import json
import os
import time
import uuid
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Optional


def _base_dir() -> Path:
    userprofile = os.environ.get("USERPROFILE") or str(Path.home())
    base = Path(userprofile) / "Desktop" / "Sites" / "NagiLinks"
    base.mkdir(parents=True, exist_ok=True)
    return base


ORDERS_FILE = _base_dir() / "orders.json"


@dataclass
class PixOrder:
    order_id: str
    created_at: int
    customer: str
    password: Optional[str]
    pix_code: str
    amount: Optional[str]
    merchant_name: Optional[str]
    merchant_city: Optional[str]
    file_name: str
    file_path: str


def _load() -> dict:
    if not ORDERS_FILE.exists():
        return {"orders": []}
    try:
        return json.loads(ORDERS_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {"orders": []}


def _save(data: dict) -> None:
    ORDERS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def new_order_id() -> str:
    return uuid.uuid4().hex[:6].upper()


def add_order(order: PixOrder) -> None:
    data = _load()
    data.setdefault("orders", [])
    data["orders"].append(asdict(order))
    _save(data)


def list_orders(limit: int = 10) -> list[dict]:
    data = _load()
    orders = data.get("orders", [])
    return list(reversed(orders))[: max(1, limit)]


def find_order(order_id: str) -> Optional[dict]:
    data = _load()
    for o in reversed(data.get("orders", [])):
        if (o.get("order_id") or "").upper() == order_id.upper():
            return o
    return None