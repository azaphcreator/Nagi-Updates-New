from __future__ import annotations

import base64
import os
import re
import secrets
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass
class GeneratedPage:
    file_path: str
    file_name: str
    link_value: str
    unlock_code: Optional[str] = None


def _desktop_links_dir() -> Path:
    userprofile = os.environ.get("USERPROFILE") or str(Path.home())
    base = Path(userprofile) / "Desktop" / "Sites" / "NagiLinks"
    base.mkdir(parents=True, exist_ok=True)
    return base


def _safe_slug(text: str, max_len: int = 40) -> str:
    t = (text or "").strip().lower()
    t = re.sub(r"\s+", "-", t)
    t = re.sub(r"[^a-z0-9\-_.]", "", t)
    t = t.strip("-_.")
    if not t:
        t = uuid.uuid4().hex[:10]
    return t[:max_len]


def generate_unlock_code(length: int = 8) -> str:
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return "".join(secrets.choice(alphabet) for _ in range(length)).lower()


def _b64_chunks(s: str, chunk_size: int = 32) -> list[str]:
    b64 = base64.b64encode(s.encode("utf-8")).decode("ascii")
    return [b64[i:i + chunk_size] for i in range(0, len(b64), chunk_size)]


def _build_html(title: str, payload_js: str, meta_html_hidden: str) -> str:
    tpl = r"""<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
  <title>%%TITLE%%</title>
  <style>
    :root {
      --bg-1: #08101d;
      --bg-2: #111a2d;
      --card: rgba(255,255,255,0.08);
      --card-strong: rgba(255,255,255,0.10);
      --border: rgba(255,255,255,0.14);
      --text: #eef4ff;
      --muted: rgba(238,244,255,0.72);
      --primary: #5b7fff;
      --primary-2: #7f9cff;
      --success: #7CFFB2;
      --danger: #ff7b7b;
      --shadow: rgba(0,0,0,0.38);
    }

    * {
      box-sizing: border-box;
    }

    html, body {
      margin: 0;
      min-height: 100%;
    }

    body {
      min-height: 100vh;
      font-family: Inter, system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
      color: var(--text);
      background:
        radial-gradient(circle at top left, rgba(91,127,255,0.18), transparent 30%),
        radial-gradient(circle at bottom right, rgba(127,156,255,0.16), transparent 32%),
        linear-gradient(160deg, var(--bg-1), var(--bg-2));
      display: grid;
      place-items: center;
      padding: 18px;
    }

    .shell {
      width: min(760px, 100%);
    }

    .brand {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      margin-bottom: 14px;
      color: rgba(238,244,255,0.9);
      font-size: 13px;
      font-weight: 700;
      letter-spacing: 0.4px;
      text-transform: uppercase;
    }

    .brand-dot {
      width: 10px;
      height: 10px;
      border-radius: 999px;
      background: linear-gradient(135deg, var(--primary), var(--primary-2));
      box-shadow: 0 0 22px rgba(91,127,255,0.55);
    }

    .card {
      width: 100%;
      background: linear-gradient(180deg, rgba(255,255,255,0.08), rgba(255,255,255,0.06));
      border: 1px solid var(--border);
      border-radius: 24px;
      padding: 22px;
      box-shadow: 0 18px 55px var(--shadow);
      backdrop-filter: blur(10px);
    }

    .header {
      text-align: center;
      margin-bottom: 18px;
    }

    .title {
      margin: 0;
      font-size: 28px;
      line-height: 1.1;
      letter-spacing: -0.02em;
      color: #ffffff;
    }

    .subtitle {
      margin: 8px 0 0 0;
      font-size: 14px;
      line-height: 1.45;
      color: var(--muted);
    }

    .lockbox {
      padding: 16px;
      border-radius: 18px;
      background: rgba(255,255,255,0.05);
      border: 1px solid rgba(255,255,255,0.08);
      margin-bottom: 16px;
    }

    .field-wrap {
      display: grid;
      gap: 10px;
    }

    .field {
      width: 100%;
      padding: 15px 16px;
      border-radius: 16px;
      border: 1px solid rgba(255,255,255,0.12);
      background: rgba(0,0,0,0.20);
      color: var(--text);
      font-size: 16px;
      outline: none;
      text-transform: lowercase;
      transition: border-color .2s ease, background .2s ease, transform .2s ease;
    }

    .field:focus {
      border-color: rgba(127,156,255,0.75);
      background: rgba(0,0,0,0.28);
    }

    .field::placeholder {
      color: rgba(238,244,255,0.45);
    }

    .btn {
      width: 100%;
      border: 0;
      border-radius: 16px;
      padding: 15px 16px;
      font-size: 16px;
      font-weight: 800;
      color: #fff;
      cursor: pointer;
      transition: transform .15s ease, opacity .15s ease, box-shadow .2s ease;
    }

    .btn:active {
      transform: translateY(1px);
    }

    .btn-primary {
      background: linear-gradient(135deg, var(--primary), var(--primary-2));
      box-shadow: 0 10px 24px rgba(91,127,255,0.28);
    }

    .btn-primary:hover {
      opacity: 0.96;
    }

    .meta-grid {
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 12px;
      margin-bottom: 14px;
    }

    .meta-card {
      background: rgba(255,255,255,0.05);
      border: 1px solid rgba(255,255,255,0.09);
      border-radius: 18px;
      padding: 14px;
    }

    .meta-label {
      display: block;
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: var(--muted);
      margin-bottom: 6px;
      font-weight: 700;
    }

    .meta-value {
      font-size: 15px;
      line-height: 1.35;
      color: #ffffff;
      font-weight: 700;
      word-break: break-word;
    }

    .steps {
      margin: 0 0 14px 0;
      padding: 16px;
      border-radius: 18px;
      border: 1px solid rgba(255,255,255,0.08);
      background: rgba(255,255,255,0.05);
      font-size: 14px;
      line-height: 1.6;
      color: rgba(238,244,255,0.90);
    }

    .steps-title {
      margin: 0 0 8px 0;
      font-weight: 800;
      color: #fff;
    }

    .pix-box {
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;
      font-size: 14px;
      line-height: 1.5;
      background: rgba(0,0,0,0.28);
      border: 1px solid rgba(255,255,255,0.12);
      border-radius: 18px;
      padding: 16px;
      margin-bottom: 14px;
      overflow-wrap: anywhere;
      word-break: break-word;
      white-space: pre-wrap;
      overflow-x: auto;
      -webkit-overflow-scrolling: touch;
    }

    .footer-note {
      margin-top: 10px;
      font-size: 12.5px;
      color: var(--muted);
      text-align: center;
      line-height: 1.45;
    }

    .toast {
      margin-top: 10px;
      font-size: 13px;
      color: var(--success);
      display: none;
      text-align: center;
      font-weight: 800;
    }

    .error {
      margin-top: 10px;
      font-size: 13px;
      color: var(--danger);
      display: none;
      text-align: center;
      font-weight: 800;
    }

    .hidden {
      display: none !important;
    }

    @media (max-width: 760px) {
      .meta-grid {
        grid-template-columns: 1fr;
      }
    }

    @media (max-width: 480px) {
      body {
        padding: 12px;
      }

      .card {
        padding: 16px;
        border-radius: 20px;
      }

      .title {
        font-size: 24px;
      }

      .subtitle {
        font-size: 13px;
      }

      .field,
      .btn {
        font-size: 16px;
      }

      .meta-card,
      .steps,
      .pix-box,
      .lockbox {
        border-radius: 16px;
      }

      .pix-box {
        font-size: 13px;
        padding: 14px;
      }
    }
  </style>
</head>
<body>
  <main class="shell">
    <div class="brand">
      <span class="brand-dot"></span>
      <span>RPN • Pagamento Seguro</span>
    </div>

    <section class="card">
      <header class="header">
        <h1 class="title">Copiar Pix</h1>
        <p class="subtitle">Digite seu nome para liberar os dados do pagamento.</p>
      </header>

      <section id="unlockBox" class="lockbox">
        <div class="field-wrap">
          <input id="nameInput" class="field" type="text" placeholder="Digite seu nome" autocomplete="off" inputmode="text" />
          <button id="unlockBtn" class="btn btn-primary">Liberar</button>
        </div>
        <div class="error" id="errMsg">❌ Nome inválido</div>
      </section>

      <section id="lockedContent" class="hidden">
        %%META%%

        <div class="steps">
          <div class="steps-title">Como pagar</div>
          <div>1. Toque em <b>Copiar Pix</b></div>
          <div>2. Abra o aplicativo do seu banco</div>
          <div>3. Vá em <b>Pix &gt; Copia e Cola</b></div>
          <div>4. Cole o código e finalize</div>
        </div>

        <div id="linkBox" class="pix-box"></div>

        <button id="copyBtn" class="btn btn-primary">Copiar Pix</button>
        <div class="toast" id="okMsg">✅ Copiado!</div>
        <div class="footer-note">Depois de copiar, cole no app do seu banco.</div>
      </section>
    </section>
  </main>

  <script>
    %%PAYLOAD_JS%%

    const unlockBox = document.getElementById("unlockBox");
    const nameInput = document.getElementById("nameInput");
    const unlockBtn = document.getElementById("unlockBtn");
    const errMsg = document.getElementById("errMsg");

    const lockedContent = document.getElementById("lockedContent");
    const linkBox = document.getElementById("linkBox");
    const copyBtn = document.getElementById("copyBtn");
    const okMsg = document.getElementById("okMsg");

    function showErr() {
      errMsg.style.display = "block";
      setTimeout(() => errMsg.style.display = "none", 1600);
    }

    function showOk() {
      okMsg.style.display = "block";
      setTimeout(() => okMsg.style.display = "none", 1400);
    }

    async function copyText(text) {
      try {
        await navigator.clipboard.writeText(text);
        showOk();
      } catch (e) {
        const ta = document.createElement("textarea");
        ta.value = text;
        ta.style.position = "fixed";
        ta.style.top = "-9999px";
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        try {
          document.execCommand("copy");
          showOk();
        } finally {
          document.body.removeChild(ta);
        }
      }
    }

    function decodeB64Chunks(chunks) {
      const b64 = chunks.join("");
      const bin = atob(b64);
      const bytes = Uint8Array.from(bin, c => c.charCodeAt(0));
      return new TextDecoder().decode(bytes);
    }

    function normalizeInput(text) {
      return (text || "").trim().toLowerCase();
    }

    function unlock() {
      const typed = normalizeInput(nameInput.value || "");
      if (!typed) {
        showErr();
        return;
      }

      if (typed !== EXPECTED_UNLOCK) {
        showErr();
        return;
      }

      const pix = decodeB64Chunks(LINK_CHUNKS);

      unlockBox.classList.add("hidden");
      lockedContent.classList.remove("hidden");

      linkBox.textContent = pix;
      copyBtn.addEventListener("click", () => copyText(pix));
    }

    unlockBtn.addEventListener("click", unlock);
    nameInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") unlockBtn.click();
    });
  </script>
</body>
</html>
"""
    return (
        tpl.replace("%%TITLE%%", title)
           .replace("%%PAYLOAD_JS%%", payload_js)
           .replace("%%META%%", meta_html_hidden or "")
    )


def generate_pix_page_locked(
    pix_code: str,
    customer: str,
    unlock_code: str,
    amount_display: Optional[str],
    company_fixed: str = "RPN",
    title: str = "Copiar Pix",
) -> GeneratedPage:
    pix_code = (pix_code or "").strip()
    if not pix_code:
        raise ValueError("pix_code vazio")

    customer = (customer or "").strip()
    if not customer:
        raise ValueError("customer vazio")

    unlock_code = (unlock_code or "").strip().lower()
    if not unlock_code:
        raise ValueError("unlock_code vazio")

    chunks = _b64_chunks(pix_code, 32)
    chunks_js = "[" + ", ".join([f"`{c}`" for c in chunks]) + "]"

    amount_text = amount_display if amount_display else "(não definido)"

    meta_html = (
        "<div class='meta-grid'>"
        f"<div class='meta-card'><span class='meta-label'>Nome</span><div class='meta-value'>{customer}</div></div>"
        f"<div class='meta-card'><span class='meta-label'>Empresa</span><div class='meta-value'>{company_fixed}</div></div>"
        f"<div class='meta-card'><span class='meta-label'>Valor</span><div class='meta-value'>{amount_text}</div></div>"
        "</div>"
    )

    payload_js = (
        f"const LINK_CHUNKS = {chunks_js};\n"
        f'const EXPECTED_UNLOCK = "{unlock_code}";'
    )

    slug = _safe_slug(customer)
    file_name = f"PIX_{slug}.html"
    file_path = _desktop_links_dir() / file_name

    html = _build_html(title=title, payload_js=payload_js, meta_html_hidden=meta_html)
    file_path.write_text(html, encoding="utf-8")

    return GeneratedPage(str(file_path), file_name, pix_code, unlock_code)