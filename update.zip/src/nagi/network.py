from __future__ import annotations

import csv
import io
import re
import subprocess
from typing import Optional, Tuple


def _run(cmd: str) -> str:
    p = subprocess.run(
        cmd,
        shell=True,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="ignore",
    )
    out = (p.stdout or "").strip()
    err = (p.stderr or "").strip()
    return out + ("\n" + err if err else "")


def _get_wifi_ssid() -> Optional[str]:
    out = _run("netsh wlan show interfaces")
    m = re.search(r"^\s*SSID\s*:\s*(.+)\s*$", out, re.MULTILINE)
    if not m:
        return None
    ssid = m.group(1).strip()
    if not ssid or ssid.lower() in ("n/a", "não aplicável", "nao aplicavel"):
        return None
    return ssid


def _get_active_ipv4_and_gateway() -> Tuple[Optional[str], Optional[str]]:
    """
    Usa a rota padrão IPv4:
    0.0.0.0  0.0.0.0  <GATEWAY>  <INTERFACE_IP>  <METRIC>
    """
    out = _run("route print -4")

    best_metric = None
    best_ip = None
    best_gw = None

    for line in out.splitlines():
        line = line.strip()
        parts = re.split(r"\s+", line)
        if len(parts) >= 5 and parts[0] == "0.0.0.0" and parts[1] == "0.0.0.0":
            gw = parts[2]
            ip = parts[3]
            try:
                metric = int(parts[4])
            except Exception:
                metric = 999999

            if best_metric is None or metric < best_metric:
                best_metric = metric
                best_ip = ip
                best_gw = gw

    return best_ip, best_gw


def _get_mac_and_adapter_via_getmac_csv() -> Tuple[Optional[str], Optional[str]]:
    """
    getmac em CSV é muito mais estável que LIST.
    Formato típico (4 colunas):
      Connection Name, Network Adapter, Physical Address, Transport Name

    Com /nh não vem header.
    """
    out = _run("getmac /v /fo csv /nh")
    if not out:
        return None, None

    # Alguns sistemas retornam mensagens junto; filtramos só linhas que parecem CSV
    lines = [ln for ln in out.splitlines() if ln.strip().startswith('"') and ln.count('","') >= 2]
    if not lines:
        return None, None

    reader = csv.reader(io.StringIO("\n".join(lines)))
    for row in reader:
        # Esperado: [conn, adapter, mac, transport]
        if len(row) < 3:
            continue

        conn_name = (row[0] or "").strip()
        adapter_name = (row[1] or "").strip()
        mac = (row[2] or "").strip()

        # Normalizações
        mac_up = mac.upper()
        if not mac or mac_up in ("N/A", "NA", "NONE", "00-00-00-00-00-00"):
            continue

        # Se for Wi-Fi, normalmente conn_name contém "Wi-Fi"; se cabo, "Ethernet".
        # Mas não dependemos disso; só pegamos o primeiro MAC válido.
        return mac, adapter_name or conn_name

    return None, None


def _get_mac_and_adapter_fallback_wmic() -> Tuple[Optional[str], Optional[str]]:
    """
    Fallback: wmic nic where NetEnabled=true get Name,MACAddress
    (wmic pode existir no seu Windows; se não existir, retorna vazio)
    """
    out = _run('wmic nic where (NetEnabled=true) get Name,MACAddress /format:csv')
    if not out:
        return None, None

    # procura algo tipo: Node,MACAddress,Name
    lines = [ln.strip() for ln in out.splitlines() if ln.strip() and "," in ln]
    # pula header
    for ln in lines[1:]:
        parts = [p.strip() for p in ln.split(",")]
        if len(parts) < 3:
            continue
        mac = parts[1]
        name = parts[2]
        if mac and mac != "00:00:00:00:00:00":
            return mac.replace(":", "-"), name
    return None, None


def get_network_fingerprint() -> dict:
    ipv4, gateway = _get_active_ipv4_and_gateway()

    mac, adapter = _get_mac_and_adapter_via_getmac_csv()
    if not mac:
        mac, adapter = _get_mac_and_adapter_fallback_wmic()

    ssid = _get_wifi_ssid()
    transport = "wifi" if ssid else "ethernet"

    return {
        "transport": transport,
        "adapter": adapter,
        "mac": mac,
        "ipv4": ipv4,
        "gateway": gateway,
        "ssid": ssid,
    }