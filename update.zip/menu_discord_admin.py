from __future__ import annotations

import json
import os
import re
import subprocess
import time
from pathlib import Path
from typing import Tuple

import requests
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent

BOT_DIR = ROOT / "discord_bot"
COMMANDS_DIR = BOT_DIR / "commands"
AI_COMMANDS_DIR = COMMANDS_DIR / "ai"
BASIC_COMMANDS_DIR = COMMANDS_DIR / "basic"
BLUEPRINTS_DIR = COMMANDS_DIR / "blueprints"

STATE_FILE = BOT_DIR / "bot_state.json"
BOT_ENV_FILE = BOT_DIR / "bot.env"
BOT_ENV_EXAMPLE_FILE = BOT_DIR / "bot.env.example"

GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"


# =========================================================
# ENV / SETTINGS
# =========================================================


def refresh_env() -> None:
    load_dotenv(dotenv_path=ROOT / ".env", override=True)


def get_groq_api_key() -> str:
    refresh_env()
    return os.getenv("GROQ_API_KEY", "").strip()


def get_groq_model() -> str:
    refresh_env()
    return os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile").strip()


def bot_status_text() -> str:
    try:
        state = read_json(STATE_FILE)
        pid = state.get("pid")
        entry = state.get("entry", "")

        if pid and is_process_running(pid):
            return (
                "[BOT LOCAL]\n\n"
                "Bot Discord está rodando.\n"
                f"PID: {pid}\n"
                f"Entry: {entry}"
            )

        return "[BOT LOCAL]\n\nBot Discord está parado."

    except Exception as e:
        return f"[BOT LOCAL]\n\nErro ao consultar status do bot: {e}"


# =========================================================
# BASIC HELPERS
# =========================================================


def is_azaph_session(user_session: dict) -> bool:
    username = str(user_session.get("username", "")).strip().lower()
    profile_key = str(user_session.get("profile_key", "")).strip().lower()
    return username in {"azaph", "azaphsilva"} or profile_key == "azaph"


def is_local_bot_request(message: str) -> bool:
    text = (message or "").strip().lower()

    keywords = [
        "bot discord",
        "discord bot",
        "criar bot",
        "inicializar bot",
        "status do bot",
        "status bot",
        "estrutura do bot",
        "instalar bot",
        "npm install",
        "iniciar bot",
        "ligar bot",
        "parar bot",
        "desligar bot",
        "reiniciar bot",
        "restart bot",
        "configurar token",
        "token bot discord",
        "mostrar log do bot",
        "log bot discord",
        "comando !",
        "crie comando !",
        "criar comando !",
        "gere comando !",
        "edite o comando !",
        "mostrar blueprint do comando !",
        "mostre o blueprint do comando !",
        "apague o comando !",
        "apagar comando !",
        "excluir comando !",
        "crie um comando complexo !",
        "criar comando complexo !",
    ]
    return any(k in text for k in keywords)


def ensure_bot_structure() -> None:
    BOT_DIR.mkdir(parents=True, exist_ok=True)
    COMMANDS_DIR.mkdir(parents=True, exist_ok=True)
    AI_COMMANDS_DIR.mkdir(parents=True, exist_ok=True)
    BASIC_COMMANDS_DIR.mkdir(parents=True, exist_ok=True)
    BLUEPRINTS_DIR.mkdir(parents=True, exist_ok=True)


def write_file(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def read_json(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def bot_exists() -> bool:
    return (BOT_DIR / "package.json").exists() and (BOT_DIR / "index.js").exists()


def is_process_running(pid: int) -> bool:
    if not pid:
        return False

    try:
        result = subprocess.run(
            ["tasklist", "/FI", f"PID eq {pid}"],
            capture_output=True,
            text=True,
            shell=True,
        )
        output = (result.stdout or "") + (result.stderr or "")
        return str(pid) in output
    except Exception:
        return False


def extract_json_block(text: str) -> dict | None:
    text = (text or "").strip()
    if not text:
        return None

    match = re.search(r"\{.*\}", text, re.DOTALL)
    if not match:
        return None

    try:
        return json.loads(match.group(0))
    except Exception:
        return None


def extract_command_name_from_text(message: str) -> str:
    match = re.search(r"!(\w+)", message or "")
    return match.group(1).lower() if match else ""


# =========================================================
# BOT BASE FILES
# =========================================================


def build_package_json() -> str:
    data = {
        "name": "nagi-discord-bot",
        "version": "1.0.0",
        "main": "index.js",
        "type": "commonjs",
        "scripts": {"start": "node index.js"},
        "dependencies": {"discord.js": "^14.16.3", "dotenv": "^16.4.5"},
    }
    return json.dumps(data, indent=2, ensure_ascii=False)


def build_env_example() -> str:
    return (
        "DISCORD_BOT_TOKEN=coloque_seu_token_aqui\n"
        "OWNER_ID=1156980445339209821\n"
        "PREFIX=!\n"
    )


def build_index_js() -> str:
    return r"""const path = require("path");
require("dotenv").config({
  path: path.join(__dirname, "bot.env"),
  override: true,
});

const fs = require("fs");
const { Client, GatewayIntentBits, Partials, Events } = require("discord.js");

const TOKEN = process.env.DISCORD_BOT_TOKEN || "";
const PREFIX = process.env.PREFIX || "!";
const OWNER_ID = process.env.OWNER_ID || "";

if (!TOKEN) {
  console.log("[BOT] DISCORD_BOT_TOKEN não configurado no bot.env");
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.MessageContent,
  ],
  partials: [Partials.Channel],
});

const commands = new Map();

function loadCommandsFrom(folder) {
  if (!fs.existsSync(folder)) return;

  const files = fs.readdirSync(folder).filter((file) => file.endsWith(".js"));

  for (const file of files) {
    const fullPath = path.join(folder, file);

    try {
      delete require.cache[require.resolve(fullPath)];
      const command = require(fullPath);

      if (!command || !command.name || typeof command.execute !== "function") {
        console.log("[BOT] comando ignorado:", fullPath);
        continue;
      }

      commands.set(command.name, command);

      if (Array.isArray(command.aliases)) {
        for (const alias of command.aliases) {
          commands.set(alias, command);
        }
      }

      console.log("[BOT] comando carregado:", command.name);
    } catch (err) {
      console.error("[BOT] erro ao carregar", fullPath, err);
    }
  }
}

function loadAllCommands() {
  commands.clear();
  loadCommandsFrom(path.join(__dirname, "commands", "basic"));
  loadCommandsFrom(path.join(__dirname, "commands", "ai"));
}

client.once(Events.ClientReady, () => {
  console.log(`[BOT] online como ${client.user.tag}`);
});

client.on(Events.MessageCreate, async (message) => {
  if (!message) return;
  if (message.author?.bot) return;

  // Permite fluxos complexos capturarem anexos e mensagens sem prefixo
  const uniqueCommands = new Set(commands.values());
  for (const command of uniqueCommands) {
    if (typeof command.onMessage === "function") {
      try {
        await command.onMessage(message, client, { OWNER_ID, PREFIX });
      } catch (err) {
        console.error("[BOT] erro em onMessage do comando:", command.name, err);
      }
    }
  }

  const content = message.content || "";
  if (!content.startsWith(PREFIX)) return;

  const raw = content.slice(PREFIX.length).trim();
  if (!raw) return;

  const parts = raw.split(/\s+/);
  const name = (parts.shift() || "").toLowerCase();
  const args = parts;

  const command = commands.get(name);
  if (!command) return;

  try {
    await command.execute(message, args, client, { OWNER_ID, PREFIX });
  } catch (err) {
    console.error("[BOT] erro executando comando:", name, err);
    await message.channel.send("Erro ao executar comando.").catch(() => null);
  }
});

loadAllCommands();

client.login(TOKEN).catch((err) => {
  console.error("[BOT] falha ao logar:", err);
});
"""


def build_ping_command() -> str:
    return r"""module.exports = {
  name: "ping",
  aliases: [],
  description: "Responde pong",
  async execute(message) {
    await message.channel.send("Pong");
  },
};
"""


def build_help_command() -> str:
    return r"""module.exports = {
  name: "ajuda",
  aliases: ["help"],
  description: "Mostra ajuda básica",
  async execute(message) {
    await message.channel.send(
      "Comandos base:\n!ping\n!ajuda"
    );
  },
};
"""


def create_base_bot() -> Tuple[bool, str]:
    ensure_bot_structure()

    write_file(BOT_DIR / "package.json", build_package_json())
    write_file(BOT_ENV_EXAMPLE_FILE, build_env_example())
    write_file(BOT_DIR / "index.js", build_index_js())
    write_file(BASIC_COMMANDS_DIR / "ping.js", build_ping_command())
    write_file(BASIC_COMMANDS_DIR / "ajuda.js", build_help_command())

    return True, (
        "[BOT LOCAL]\n\n"
        "Bot Discord base criado com sucesso.\n\n"
        f"Pasta: {BOT_DIR}\n"
        f"Arquivo principal: {BOT_DIR / 'index.js'}\n"
        f"Comandos base: {BASIC_COMMANDS_DIR}\n\n"
        "Arquivos criados:\n"
        "- package.json\n"
        "- bot.env.example\n"
        "- index.js\n"
        "- commands/basic/ping.js\n"
        "- commands/basic/ajuda.js\n"
        "- commands/ai/\n"
        "- commands/blueprints/\n"
    )


def create_real_env(token: str) -> Tuple[bool, str]:
    ensure_bot_structure()

    token = (token or "").strip()
    if not token:
        return False, "Token vazio. Use: configurar token bot discord SEU_TOKEN"

    env_content = (
        f"DISCORD_BOT_TOKEN={token}\n" "OWNER_ID=1156980445339209821\n" "PREFIX=!\n"
    )
    write_file(BOT_ENV_FILE, env_content)

    return True, f"[BOT LOCAL]\n\nbot.env criado com sucesso em:\n{BOT_ENV_FILE}"


def extract_token_from_message(message: str) -> str:
    text = (message or "").strip()
    prefix = "configurar token bot discord"
    lower = text.lower()

    idx = lower.find(prefix)
    if idx == -1:
        return ""

    return text[idx + len(prefix) :].strip()


def npm_install() -> Tuple[bool, str]:
    ensure_bot_structure()

    if not bot_exists():
        return False, "O bot ainda não foi criado. Use primeiro: criar bot discord"

    try:
        result = subprocess.run(
            ["npm", "install"],
            cwd=str(BOT_DIR),
            capture_output=True,
            text=True,
            shell=True,
        )
    except Exception as e:
        return False, f"Erro ao executar npm install: {e}"

    output = ((result.stdout or "") + "\n" + (result.stderr or "")).strip()

    if result.returncode != 0:
        return False, f"npm install falhou.\n\n{output[:3500]}"

    return True, "[BOT LOCAL]\n\nnpm install concluído com sucesso."


def get_bot_status() -> Tuple[bool, str]:
    ensure_bot_structure()
    exists = bot_exists()
    state = read_json(STATE_FILE)

    files = [
        BOT_DIR / "package.json",
        BOT_DIR / "index.js",
        BOT_ENV_FILE,
        BASIC_COMMANDS_DIR / "ping.js",
        BASIC_COMMANDS_DIR / "ajuda.js",
    ]

    status_lines = [
        "[BOT LOCAL]",
        "",
        f"Bot criado: {'sim' if exists else 'não'}",
        f"Pasta do bot: {BOT_DIR}",
        f"Pasta commands/basic: {BASIC_COMMANDS_DIR}",
        f"Pasta commands/ai: {AI_COMMANDS_DIR}",
        f"Pasta commands/blueprints: {BLUEPRINTS_DIR}",
        f"Processo salvo: {'sim' if state.get('pid') else 'não'}",
        f"PID salvo: {state.get('pid') or '-'}",
        f"Modo: {state.get('mode') or '-'}",
        f"Entry: {state.get('entry') or '-'}",
        "",
        "Arquivos:",
    ]
    for f in files:
        status_lines.append(f"- {f.name}: {'OK' if f.exists() else 'faltando'}")

    return True, "\n".join(status_lines)


def get_tree() -> Tuple[bool, str]:
    ensure_bot_structure()

    lines = [
        "discord_bot/",
        "  index.js" if (BOT_DIR / "index.js").exists() else "  index.js (faltando)",
        (
            "  package.json"
            if (BOT_DIR / "package.json").exists()
            else "  package.json (faltando)"
        ),
        "  bot.env" if BOT_ENV_FILE.exists() else "  bot.env (faltando)",
        (
            "  bot.env.example"
            if BOT_ENV_EXAMPLE_FILE.exists()
            else "  bot.env.example (faltando)"
        ),
        "  commands/",
        "    basic/",
    ]

    for path in sorted(BASIC_COMMANDS_DIR.glob("*.js")):
        lines.append(f"      {path.name}")

    lines.append("    ai/")
    for path in sorted(AI_COMMANDS_DIR.glob("*.js")):
        lines.append(f"      {path.name}")

    lines.append("    blueprints/")
    for path in sorted(BLUEPRINTS_DIR.glob("*.json")):
        lines.append(f"      {path.name}")

    return True, "\n".join(lines)


def start_bot_process() -> Tuple[bool, str]:
    ensure_bot_structure()

    if not bot_exists():
        return False, "O bot ainda não foi criado. Use primeiro: criar bot discord"

    if not BOT_ENV_FILE.exists():
        return (
            False,
            "O bot.env do bot não existe. Use: configurar token bot discord SEU_TOKEN",
        )

    state = read_json(STATE_FILE)
    existing_pid = state.get("pid")
    if existing_pid and is_process_running(existing_pid):
        return True, (
            "[BOT LOCAL]\n\n"
            "O bot Discord já parece estar rodando.\n"
            f"PID: {existing_pid}\n"
            f"Entry: {BOT_DIR / 'index.js'}"
        )

    index_path = BOT_DIR / "index.js"
    if not index_path.exists():
        return False, f"Arquivo principal não encontrado: {index_path}"

    try:
        process = subprocess.Popen(
            ["cmd.exe", "/k", "node index.js"],
            cwd=str(BOT_DIR),
            shell=False,
            creationflags=subprocess.CREATE_NEW_CONSOLE if os.name == "nt" else 0,
        )
    except Exception as e:
        return False, f"Erro ao iniciar o bot Discord via CMD: {e}"

    time.sleep(2)

    exit_code = process.poll()
    if exit_code is not None:
        return False, (
            "[BOT LOCAL]\n\n"
            "O CMD do bot abriu, mas fechou logo em seguida.\n"
            f"Exit code: {exit_code}\n"
            f"Entry: {index_path}"
        )

    write_json(
        STATE_FILE,
        {
            "pid": process.pid,
            "entry": str(index_path),
            "mode": "cmd_k_node_index",
        },
    )

    return True, (
        "[BOT LOCAL]\n\n"
        "Bot Discord iniciado via CMD com sucesso.\n\n"
        f"PID: {process.pid}\n"
        f"Entry: {index_path}\n"
        "Modo: cmd.exe /k node index.js"
    )


def stop_bot_process() -> Tuple[bool, str]:
    state = read_json(STATE_FILE)
    pid = state.get("pid")

    if not pid:
        return True, "[BOT LOCAL]\n\nNenhum PID salvo. Bot já estava parado."

    if not is_process_running(pid):
        write_json(STATE_FILE, {})
        return (
            True,
            f"[BOT LOCAL]\n\nO processo {pid} já não estava rodando. Estado limpo.",
        )

    try:
        result = subprocess.run(
            ["taskkill", "/PID", str(pid), "/T", "/F"],
            capture_output=True,
            text=True,
            shell=True,
        )
    except Exception as e:
        return False, f"[BOT LOCAL]\n\nErro ao tentar parar o bot Discord: {e}"

    # Mesmo se o Windows demorar um pouco, limpamos o estado
    write_json(STATE_FILE, {})

    stdout = (result.stdout or "").strip()
    stderr = (result.stderr or "").strip()

    if result.returncode == 0:
        return (
            True,
            f"[BOT LOCAL]\n\nBot Discord parado com sucesso.\nPID finalizado: {pid}",
        )

    # Se o processo já sumiu, também consideramos sucesso
    time.sleep(1)
    if not is_process_running(pid):
        return (
            True,
            f"[BOT LOCAL]\n\nBot Discord parado com sucesso.\nPID finalizado: {pid}",
        )

    return False, (
        "[BOT LOCAL]\n\n"
        f"Falha ao encerrar o PID {pid}.\n\n"
        f"Saída:\n{stdout or '-'}\n"
        f"Erro:\n{stderr or '-'}"
    )


def restart_bot_process() -> Tuple[bool, str]:
    state = read_json(STATE_FILE)
    pid = state.get("pid")

    stop_msg = "Nenhum processo anterior encontrado."

    if pid:
        ok, msg = stop_bot_process()
        stop_msg = msg

        if not ok:
            return (
                False,
                f"[BOT LOCAL]\n\nFalha ao parar o bot antes de reiniciar:\n{msg}",
            )

        # pequeno intervalo para o Windows limpar a árvore
        time.sleep(1.5)

    # garante estado limpo antes de iniciar de novo
    write_json(STATE_FILE, {})

    start_ok, start_msg = start_bot_process()
    if not start_ok:
        return False, f"[BOT LOCAL]\n\n{stop_msg}\n\n{start_msg}"

    return True, f"[BOT LOCAL]\n\n{stop_msg}\n\n{start_msg}"


def read_bot_log() -> Tuple[bool, str]:
    state = read_json(STATE_FILE)
    pid = state.get("pid")
    entry = state.get("entry") or str(BOT_DIR / "index.js")

    return True, (
        "[BOT LOCAL]\n\n"
        "No modo atual, o bot foi iniciado em uma janela CMD dedicada.\n"
        "O log principal está nessa janela.\n\n"
        f"PID salvo: {pid or '-'}\n"
        f"Entry: {entry}\n"
        "Modo: cmd.exe /k node index.js"
    )


# =========================================================
# SIMPLE COMMANDS VIA GROQ
# =========================================================


def parse_create_command_request(message: str) -> tuple[str, str]:
    text = (message or "").strip()

    match_name = re.search(r"!(\w+)", text)
    command_name = match_name.group(1).lower() if match_name else "novo"

    reply = "Comando criado pelo Nagi."
    match_reply = re.search(
        r"(?:responda|responder|fale|diga|envie)\s+['\"]?(.+?)['\"]?$",
        text,
        re.IGNORECASE,
    )
    if match_reply:
        reply = match_reply.group(1).strip()

    return command_name, reply


def call_groq_command_planner(user_message: str) -> Tuple[bool, dict | str]:
    groq_api_key = get_groq_api_key()
    groq_model = get_groq_model()

    if not groq_api_key:
        return False, "GROQ_API_KEY não configurada no .env principal do Nagi."

    system_prompt = """
Você é um planejador de comandos para um bot Discord em Node.js.
Sua tarefa é converter o pedido do usuário em JSON puro, sem explicações.

Responda SOMENTE um JSON válido no formato:

{
  "action": "create_or_update_command",
  "command_name": "nome_sem_!",
  "description": "descrição curta",
  "aliases": [],
  "owner_only": false,
  "dm_author": false,
  "delete_trigger": false,
  "reply_text": "texto que o comando deve enviar"
}

Regras:
- command_name nunca deve ter "!".
- aliases deve ser uma lista.
- owner_only = true quando o usuário disser que só Azaph/owner pode usar.
- dm_author = true quando o usuário pedir para mandar no privado.
- delete_trigger = true quando o usuário pedir para apagar a mensagem de comando.
- reply_text deve ser a resposta principal do comando.
- Se o pedido falar em editar comando, use a mesma action "create_or_update_command".
""".strip()

    payload = {
        "model": groq_model,
        "temperature": 0.1,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message},
        ],
    }

    headers = {
        "Authorization": f"Bearer {groq_api_key}",
        "Content-Type": "application/json",
    }

    try:
        resp = requests.post(GROQ_URL, headers=headers, json=payload, timeout=90)
    except Exception as e:
        return False, f"Erro ao conectar na Groq: {e}"

    if resp.status_code != 200:
        return False, f"Groq retornou {resp.status_code}: {resp.text[:1500]}"

    try:
        data = resp.json()
        content = data["choices"][0]["message"]["content"]
    except Exception as e:
        return False, f"Resposta inválida da Groq: {e}"

    parsed = extract_json_block(content)
    if not parsed:
        return (
            False,
            f"A Groq não retornou JSON válido.\n\nResposta recebida:\n{content[:2000]}",
        )

    return True, parsed


def normalize_command_spec(spec: dict) -> dict:
    command_name = (
        re.sub(
            r"[^a-zA-Z0-9_-]", "", str(spec.get("command_name", "novo")).strip().lower()
        )
        or "novo"
    )

    aliases = spec.get("aliases") or []
    if not isinstance(aliases, list):
        aliases = []

    aliases_clean = []
    for a in aliases:
        a = re.sub(r"[^a-zA-Z0-9_-]", "", str(a).strip().lower())
        if a and a != command_name and a not in aliases_clean:
            aliases_clean.append(a)

    return {
        "action": "create_or_update_command",
        "command_name": command_name,
        "description": str(
            spec.get("description") or f"Comando {command_name} criado pelo Nagi"
        ).strip(),
        "aliases": aliases_clean,
        "owner_only": bool(spec.get("owner_only")),
        "dm_author": bool(spec.get("dm_author")),
        "delete_trigger": bool(spec.get("delete_trigger")),
        "reply_text": str(spec.get("reply_text") or "Comando executado.").strip(),
    }


def build_ai_command_js_advanced(spec: dict) -> str:
    spec = normalize_command_spec(spec)

    command_name = spec["command_name"]
    description = json.dumps(spec["description"], ensure_ascii=False)
    aliases = json.dumps(spec["aliases"], ensure_ascii=False)
    reply_text = json.dumps(spec["reply_text"], ensure_ascii=False)
    owner_only = str(spec["owner_only"]).lower()
    dm_author = str(spec["dm_author"]).lower()
    delete_trigger = str(spec["delete_trigger"]).lower()

    return f"""module.exports = {{
  name: {json.dumps(command_name)},
  aliases: {aliases},
  description: {description},
  async execute(message, args, client, ctx = {{}}) {{
    try {{
      const OWNER_ID = ctx.OWNER_ID || "";

      if ({owner_only}) {{
        if (!message.author || String(message.author.id) !== String(OWNER_ID)) {{
          return;
        }}
      }}

      if ({delete_trigger}) {{
        await message.delete().catch(() => null);
      }}

      const responseText = {reply_text};

      if ({dm_author}) {{
        await message.author.send(responseText).catch(() => null);
      }} else {{
        await message.channel.send(responseText);
      }}
    }} catch (err) {{
      console.error("[BOT] erro no comando {command_name}:", err);
      await message.channel.send("Erro ao executar comando.").catch(() => null);
    }}
  }},
}};
"""


def groq_create_or_update_command(message: str) -> Tuple[bool, str]:
    ensure_bot_structure()

    ok, result = call_groq_command_planner(message)
    if not ok:
        return False, str(result)

    spec = normalize_command_spec(result)
    js = build_ai_command_js_advanced(spec)

    file_path = AI_COMMANDS_DIR / f"{spec['command_name']}.js"
    write_file(file_path, js)

    return True, (
        "[BOT LOCAL + GROQ]\n\n"
        "Comando criado/atualizado com sucesso.\n\n"
        f"Nome: !{spec['command_name']}\n"
        f"Arquivo: {file_path}\n"
        f"Descrição: {spec['description']}\n"
        f"Aliases: {', '.join(spec['aliases']) if spec['aliases'] else '-'}\n"
        f"Owner only: {'sim' if spec['owner_only'] else 'não'}\n"
        f"DM autor: {'sim' if spec['dm_author'] else 'não'}\n"
        f"Apaga mensagem: {'sim' if spec['delete_trigger'] else 'não'}\n"
        f"Resposta: {spec['reply_text']}"
    )


# =========================================================
# BLUEPRINT COMMANDS (COMPLEX)
# =========================================================


def blueprint_file_for(command_name: str) -> Path:
    safe = re.sub(r"[^a-zA-Z0-9_-]", "", command_name.lower()) or "novo"
    return BLUEPRINTS_DIR / f"{safe}.json"


def command_file_for(command_name: str) -> Path:
    safe = re.sub(r"[^a-zA-Z0-9_-]", "", command_name.lower()) or "novo"
    return AI_COMMANDS_DIR / f"{safe}.js"


def read_blueprint(command_name: str) -> dict | None:
    path = blueprint_file_for(command_name)
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def save_blueprint(command_name: str, data: dict) -> None:
    path = blueprint_file_for(command_name)
    write_file(path, json.dumps(data, indent=2, ensure_ascii=False))


def delete_command_files(command_name: str) -> Tuple[bool, str]:
    bp = blueprint_file_for(command_name)
    js = command_file_for(command_name)

    removed = []

    if bp.exists():
        bp.unlink()
        removed.append(str(bp))

    if js.exists():
        js.unlink()
        removed.append(str(js))

    if not removed:
        return False, f"Nenhum arquivo encontrado para !{command_name}"

    return True, "[BOT LOCAL]\n\nArquivos removidos:\n" + "\n".join(removed)


def create_sales_blueprint_venda_default(command_name: str) -> dict:
    return {
        "type": "sales_submission",
        "command_name": command_name,
        "aliases": [],
        "enabled": True,
        "guild_id": "1447626538722787441",
        "allowed_role_ids": [],
        "target_channel_id": "1475574286243594461",
        "mention_role_id": "1468684459531309268",
        "embed": {
            "title": "📦 Nova venda enviada",
            "description": "Uma nova venda foi enviada para análise.",
            "color": 15830058,
            "footer": "RPN BOT • Sistema de envio de venda",
        },
        "flow": {
            "collect_in_channel": True,
            "allow_cancel": True,
            "steps": [
                {
                    "id": "customer_name",
                    "type": "text",
                    "ask": "📦 **Início do envio de venda**\n\nPrimeiro, envie **seu nome**.\n\nVocê pode digitar `cancelar` a qualquer momento.",
                },
                {
                    "id": "purchase_receipt",
                    "type": "attachment",
                    "ask": "✅ Nome salvo.\n\nAgora envie o **comprovante de compra** como anexo.",
                },
                {
                    "id": "label_receipt",
                    "type": "attachment",
                    "ask": "✅ Comprovante de compra salvo.\n\nAgora envie o **comprovante da etiqueta** como anexo.",
                },
            ],
        },
    }


def build_sales_submission_js_from_blueprint(bp: dict) -> str:
    command_name = bp["command_name"]
    aliases = bp.get("aliases", [])
    guild_id = bp.get("guild_id", "")
    allowed_role_ids = bp.get("allowed_role_ids", [])
    target_channel_id = bp.get("target_channel_id", "")
    mention_role_id = bp.get("mention_role_id", "")
    embed = bp.get("embed", {})
    flow = bp.get("flow", {})
    steps = flow.get("steps", [])

    title = json.dumps(embed.get("title", "📦 Nova venda enviada"), ensure_ascii=False)
    description = json.dumps(
        embed.get("description", "Uma nova venda foi enviada para análise."),
        ensure_ascii=False,
    )
    color = int(embed.get("color", 0xF28C2A))
    footer = json.dumps(
        embed.get("footer", "RPN BOT • Sistema de envio de venda"), ensure_ascii=False
    )

    aliases_js = json.dumps(aliases, ensure_ascii=False)
    allowed_roles_js = json.dumps(allowed_role_ids, ensure_ascii=False)

    ask_name = (
        json.dumps(steps[0]["ask"], ensure_ascii=False)
        if len(steps) > 0
        else json.dumps("Envie seu nome.", ensure_ascii=False)
    )
    ask_purchase = (
        json.dumps(steps[1]["ask"], ensure_ascii=False)
        if len(steps) > 1
        else json.dumps("Envie o comprovante de compra.", ensure_ascii=False)
    )
    ask_label = (
        json.dumps(steps[2]["ask"], ensure_ascii=False)
        if len(steps) > 2
        else json.dumps("Envie o comprovante da etiqueta.", ensure_ascii=False)
    )

    return f"""const {{ EmbedBuilder }} = require("discord.js");

const TARGET_GUILD_ID = {json.dumps(guild_id)};
const TARGET_CHANNEL_ID = {json.dumps(target_channel_id)};
const MENTION_ROLE_ID = {json.dumps(mention_role_id)};
const ALLOWED_ROLE_IDS = {allowed_roles_js};

const sessions = new Map();

function getAttachmentInfo(message) {{
  if (!message.attachments || message.attachments.size === 0) return null;
  const first = message.attachments.first();
  if (!first) return null;

  return {{
    name: first.name || "arquivo",
    url: first.url,
    contentType: first.contentType || "desconhecido",
    size: first.size || 0,
  }};
}}

function hasAllowedRole(member) {{
  if (!ALLOWED_ROLE_IDS || ALLOWED_ROLE_IDS.length === 0) return true;
  if (!member || !member.roles || !member.roles.cache) return false;
  return ALLOWED_ROLE_IDS.some(roleId => member.roles.cache.has(roleId));
}}

module.exports = {{
  name: {json.dumps(command_name)},
  aliases: {aliases_js},
  description: "Comando complexo gerado por blueprint",

  async execute(message, args, client) {{
    try {{
      if (!message.guild || String(message.guild.id) !== String(TARGET_GUILD_ID)) {{
        await message.reply("Este comando só pode ser usado no servidor configurado.");
        return;
      }}

      if (!hasAllowedRole(message.member)) {{
        await message.reply("❌ Você não tem permissão para usar este comando.");
        return;
      }}

      const userId = String(message.author.id);

      if (sessions.has(userId)) {{
        await message.reply(
          "Você já tem uma coleta em andamento.\\n" +
          "Envie o próximo dado solicitado ou digite `cancelar` para abortar."
        );
        return;
      }}

      sessions.set(userId, {{
        step: "awaiting_name",
        guildId: String(message.guild.id),
        channelId: String(message.channel.id),
        startedAt: Date.now(),
        data: {{
          customerName: "",
          purchaseReceipt: null,
          labelReceipt: null
        }}
      }});

      await message.reply({ask_name});
    }} catch (err) {{
      console.error("[BOT] erro ao iniciar fluxo:", err);
      await message.reply("Erro ao iniciar o fluxo.").catch(() => null);
    }}
  }},

  async onMessage(message, client) {{
    try {{
      if (!message.guild || String(message.guild.id) !== String(TARGET_GUILD_ID)) return;
      if (message.author?.bot) return;

      const userId = String(message.author.id);
      const session = sessions.get(userId);
      if (!session) return;

      if (String(message.channel.id) !== String(session.channelId)) return;

      const content = (message.content || "").trim();

      if (content.toLowerCase() === "cancelar") {{
        sessions.delete(userId);
        await message.reply("❌ Coleta cancelada com sucesso.");
        return;
      }}

      if (session.step === "awaiting_name") {{
        if (!content || content.startsWith("!")) return;

        session.data.customerName = content;
        session.step = "awaiting_purchase_receipt";
        sessions.set(userId, session);

        await message.reply({ask_purchase});
        return;
      }}

      if (session.step === "awaiting_purchase_receipt") {{
        const attachment = getAttachmentInfo(message);
        if (!attachment) {{
          await message.reply("⚠️ Agora preciso do **comprovante de compra** como anexo.");
          return;
        }}

        session.data.purchaseReceipt = attachment;
        session.step = "awaiting_label_receipt";
        sessions.set(userId, session);

        await message.reply({ask_label});
        return;
      }}

      if (session.step === "awaiting_label_receipt") {{
        const attachment = getAttachmentInfo(message);
        if (!attachment) {{
          await message.reply("⚠️ Agora preciso do **comprovante da etiqueta** como anexo.");
          return;
        }}

        session.data.labelReceipt = attachment;

        const targetChannel =
          message.guild.channels.cache.get(TARGET_CHANNEL_ID) ||
          (await message.guild.channels.fetch(TARGET_CHANNEL_ID).catch(() => null));

        if (!targetChannel || !targetChannel.isTextBased()) {{
          await message.reply("❌ Não consegui encontrar o canal de destino configurado.");
          sessions.delete(userId);
          return;
        }}

        const embed = new EmbedBuilder()
          .setTitle({title})
          .setDescription({description})
          .setColor({color})
          .addFields(
            {{
              name: "👤 Nome",
              value: session.data.customerName || "Não informado",
              inline: false,
            }},
            {{
              name: "🙍 Usuário",
              value: `${{message.author}} \\nID: \\`${{message.author.id}}\\``,
              inline: false,
            }},
            {{
              name: "🛒 Comprovante de compra",
              value: `[Abrir arquivo](${{session.data.purchaseReceipt.url}})`,
              inline: false,
            }},
            {{
              name: "🏷️ Comprovante da etiqueta",
              value: `[Abrir arquivo](${{session.data.labelReceipt.url}})`,
              inline: false,
            }},
            {{
              name: "💬 Canal de origem",
              value: `<#${{message.channel.id}}>`,
              inline: true,
            }},
            {{
              name: "🕒 Enviado em",
              value: `<t:${{Math.floor(Date.now() / 1000)}}:F>`,
              inline: true,
            }}
          )
          .setFooter({{ text: {footer} }})
          .setTimestamp();

        await targetChannel.send({{
          content: MENTION_ROLE_ID ? `<@&${{MENTION_ROLE_ID}}>` : "",
          embeds: [embed],
        }});

        await message.reply("✅ Sua solicitação foi enviada com sucesso.");
        sessions.delete(userId);
      }}
    }} catch (err) {{
      console.error("[BOT] erro em onMessage do comando:", err);
      try {{
        await message.reply("❌ Ocorreu um erro durante a coleta.");
      }} catch (_) {{}}
    }}
  }},
}};
"""


def generate_command_from_blueprint(command_name: str) -> Tuple[bool, str]:
    bp = read_blueprint(command_name)
    if not bp:
        return False, f"Blueprint não encontrado para !{command_name}"

    cmd_type = bp.get("type")

    if cmd_type == "sales_submission":
        js = build_sales_submission_js_from_blueprint(bp)
    elif cmd_type == "generic_flow":
        js = build_generic_flow_js_from_blueprint(bp)
    else:
        return False, f"Tipo de blueprint não suportado: {cmd_type}"

    write_file(command_file_for(command_name), js)
    return True, (
        "[BOT LOCAL]\n\n"
        f"Comando !{command_name} regenerado com sucesso.\n"
        f"Blueprint: {blueprint_file_for(command_name)}\n"
        f"JS: {command_file_for(command_name)}"
    )


def call_groq_blueprint_editor(
    user_message: str, current_blueprint: dict | None
) -> Tuple[bool, dict | str]:
    groq_api_key = get_groq_api_key()
    groq_model = get_groq_model()

    if not groq_api_key:
        return False, "GROQ_API_KEY não configurada no .env principal do Nagi."

    current_json = json.dumps(current_blueprint or {}, indent=2, ensure_ascii=False)

    system_prompt = """
Você é um editor de blueprints de comandos Discord.

Sua tarefa é receber um pedido do usuário e devolver SOMENTE JSON válido.
O JSON devolvido deve representar o blueprint final atualizado.

Tipos suportados:
- sales_submission

Regras:
- Nunca explique, nunca use markdown.
- Responda apenas JSON puro.
- Preserve campos existentes quando não forem alterados.
- allowed_role_ids deve ser uma lista de strings.
- guild_id, target_channel_id, mention_role_id devem ser strings.
- command_name nunca deve ter "!".
""".strip()

    payload = {
        "model": groq_model,
        "temperature": 0.1,
        "messages": [
            {"role": "system", "content": system_prompt},
            {
                "role": "user",
                "content": (
                    f"Blueprint atual:\n{current_json}\n\n"
                    f"Pedido do usuário:\n{user_message}"
                ),
            },
        ],
    }

    headers = {
        "Authorization": f"Bearer {groq_api_key}",
        "Content-Type": "application/json",
    }

    try:
        resp = requests.post(GROQ_URL, headers=headers, json=payload, timeout=90)
    except Exception as e:
        return False, f"Erro ao conectar na Groq: {e}"

    if resp.status_code != 200:
        return False, f"Groq retornou {resp.status_code}: {resp.text[:1500]}"

    try:
        data = resp.json()
        content = data["choices"][0]["message"]["content"]
    except Exception as e:
        return False, f"Resposta inválida da Groq: {e}"

    parsed = extract_json_block(content)
    if not parsed:
        return (
            False,
            f"A Groq não retornou JSON válido.\n\nResposta recebida:\n{content[:2000]}",
        )

    return True, parsed


def create_complex_command_from_text(message: str) -> Tuple[bool, str]:
    command_name = extract_command_name_from_text(message)
    if not command_name:
        return False, "Não encontrei o nome do comando. Exemplo: !verificar"

    ok, result = call_groq_generic_flow_blueprint(message)
    if not ok:
        return False, str(result)

    bp = normalize_generic_flow_blueprint(result)
    bp["command_name"] = command_name

    save_blueprint(command_name, bp)
    ok2, msg2 = generate_command_from_blueprint(command_name)
    if not ok2:
        return False, msg2

    return True, (
        "[BOT LOCAL + GROQ]\n\n"
        f"Comando complexo !{command_name} criado com sucesso.\n\n"
        f"Blueprint: {blueprint_file_for(command_name)}\n"
        f"JS: {command_file_for(command_name)}"
    )


def show_blueprint_from_text(message: str) -> Tuple[bool, str]:
    command_name = extract_command_name_from_text(message)
    if not command_name:
        return False, "Não encontrei o nome do comando."

    bp = read_blueprint(command_name)
    if not bp:
        return False, f"Blueprint não encontrado para !{command_name}"

    return True, "[BOT LOCAL]\n\n" + json.dumps(bp, indent=2, ensure_ascii=False)


def edit_blueprint_from_text(message: str) -> Tuple[bool, str]:
    command_name = extract_command_name_from_text(message)
    if not command_name:
        return False, "Não encontrei o nome do comando."

    current = read_blueprint(command_name)
    if not current:
        return False, f"Blueprint não encontrado para !{command_name}"

    ok, result = call_groq_blueprint_editor(message, current)
    if not ok:
        return False, str(result)

    save_blueprint(command_name, result)
    ok2, msg2 = generate_command_from_blueprint(command_name)
    if not ok2:
        return False, msg2

    return True, (
        "[BOT LOCAL + GROQ]\n\n"
        f"Blueprint de !{command_name} atualizado com sucesso.\n\n"
        f"Blueprint: {blueprint_file_for(command_name)}\n"
        f"JS: {command_file_for(command_name)}"
    )


def delete_command_from_text(message: str) -> Tuple[bool, str]:
    command_name = extract_command_name_from_text(message)
    if not command_name:
        return False, "Não encontrei o nome do comando."

    return delete_command_files(command_name)


def call_groq_generic_flow_blueprint(user_message: str) -> Tuple[bool, dict | str]:
    groq_api_key = get_groq_api_key()
    groq_model = get_groq_model()

    if not groq_api_key:
        return False, "GROQ_API_KEY não configurada no .env principal do Nagi."

    system_prompt = """
Você é um gerador de blueprints de comandos complexos para bot Discord.

Responda SOMENTE JSON válido.

Formato esperado:
{
  "type": "generic_flow",
  "command_name": "verificar",
  "aliases": [],
  "enabled": true,
  "guild_id": "",
  "allowed_role_ids": [],
  "target_channel_id": "",
  "mention_role_id": "",
  "embed": {
    "title": "Título",
    "description": "Descrição",
    "color": 15830058,
    "footer": "Rodapé"
  },
  "flow": {
    "collect_in_channel": true,
    "allow_cancel": true,
    "steps": [
      {
        "id": "customer_name",
        "type": "text",
        "label": "Nome",
        "ask": "Envie seu nome"
      },
      {
        "id": "receipt",
        "type": "attachment",
        "label": "Comprovante",
        "ask": "Envie o comprovante"
      },
      {
        "id": "target_user",
        "type": "user_mention",
        "label": "Usuário mencionado",
        "ask": "Mencione o usuário"
      }
    ]
  },
  "actions": {
    "grant_role_to_mentioned_user": false,
    "grant_role_id": ""
  }
}

Regras:
- Responda somente JSON puro.
- command_name nunca deve ter "!".
- types de step suportados: text, attachment, user_mention.
- allowed_role_ids deve ser lista de strings.
- guild_id, target_channel_id, mention_role_id, grant_role_id devem ser strings de IDs.
- Se o usuário falar "apenas quem tiver o cargo X pode usar", coloque X em allowed_role_ids.
- Se o usuário falar "mencione o cargo X", coloque X em mention_role_id.
- Se o usuário falar "dê o cargo X ao usuário mencionado", coloque:
  "grant_role_to_mentioned_user": true
  e "grant_role_id": "X".
- Se o usuário pedir nome + comprovante + mencionar usuário, crie exatamente 3 steps nessa ordem:
  1) text
  2) attachment
  3) user_mention
- Se o usuário mencionar um canal de envio, coloque em target_channel_id.
- Se o usuário mencionar um servidor, coloque em guild_id.
- embed.color deve ser número inteiro.
- Preserve todos os IDs exatamente como o usuário forneceu.
""".strip()

    payload = {
        "model": groq_model,
        "temperature": 0.1,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message},
        ],
    }

    headers = {
        "Authorization": f"Bearer {groq_api_key}",
        "Content-Type": "application/json",
    }

    try:
        resp = requests.post(GROQ_URL, headers=headers, json=payload, timeout=90)
    except Exception as e:
        return False, f"Erro ao conectar na Groq: {e}"

    if resp.status_code != 200:
        return False, f"Groq retornou {resp.status_code}: {resp.text[:1500]}"

    try:
        data = resp.json()
        content = data["choices"][0]["message"]["content"]
    except Exception as e:
        return False, f"Resposta inválida da Groq: {e}"

    parsed = extract_json_block(content)
    if not parsed:
        return (
            False,
            f"A Groq não retornou JSON válido.\n\nResposta recebida:\n{content[:2000]}",
        )

    return True, parsed


def normalize_generic_flow_blueprint(bp: dict) -> dict:
    command_name = (
        re.sub(
            r"[^a-zA-Z0-9_-]", "", str(bp.get("command_name", "novo")).strip().lower()
        )
        or "novo"
    )

    aliases = bp.get("aliases") or []
    if not isinstance(aliases, list):
        aliases = []

    aliases_clean = []
    for a in aliases:
        a = re.sub(r"[^a-zA-Z0-9_-]", "", str(a).strip().lower())
        if a and a != command_name and a not in aliases_clean:
            aliases_clean.append(a)

    steps = bp.get("flow", {}).get("steps", [])
    if not isinstance(steps, list):
        steps = []

    normalized_steps = []
    for i, step in enumerate(steps, start=1):
        step_type = str(step.get("type", "text")).strip().lower()
        if step_type not in {"text", "attachment", "user_mention"}:
            step_type = "text"

        normalized_steps.append(
            {
                "id": re.sub(
                    r"[^a-zA-Z0-9_]",
                    "",
                    str(step.get("id", f"step_{i}")).strip().lower(),
                )
                or f"step_{i}",
                "type": step_type,
                "label": str(step.get("label") or f"Campo {i}").strip(),
                "ask": str(step.get("ask") or f"Envie o valor para {i}.").strip(),
            }
        )

    if not normalized_steps:
        normalized_steps = [
            {
                "id": "input_text",
                "type": "text",
                "label": "Texto",
                "ask": "Envie o texto solicitado.",
            }
        ]

    embed = bp.get("embed", {}) or {}
    actions = bp.get("actions", {}) or {}
    flow = bp.get("flow", {}) or {}

    allowed_role_ids_raw = bp.get("allowed_role_ids") or []
    if not isinstance(allowed_role_ids_raw, list):
        allowed_role_ids_raw = []

    allowed_role_ids = []
    for x in allowed_role_ids_raw:
        sx = str(x).strip()
        if sx:
            allowed_role_ids.append(sx)

    return {
        "type": "generic_flow",
        "command_name": command_name,
        "aliases": aliases_clean,
        "enabled": bool(bp.get("enabled", True)),
        "guild_id": str(bp.get("guild_id") or "").strip(),
        "allowed_role_ids": allowed_role_ids,
        "target_channel_id": str(bp.get("target_channel_id") or "").strip(),
        "mention_role_id": str(bp.get("mention_role_id") or "").strip(),
        "embed": {
            "title": str(
                embed.get("title") or f"📦 Nova solicitação: {command_name}"
            ).strip(),
            "description": str(
                embed.get("description") or "Uma nova solicitação foi enviada."
            ).strip(),
            "color": int(embed.get("color", 15830058)),
            "footer": str(
                embed.get("footer") or "RPN BOT • Fluxo gerado por IA"
            ).strip(),
        },
        "flow": {
            "collect_in_channel": bool(flow.get("collect_in_channel", True)),
            "allow_cancel": bool(flow.get("allow_cancel", True)),
            "steps": normalized_steps,
        },
        "actions": {
            "grant_role_to_mentioned_user": bool(
                actions.get("grant_role_to_mentioned_user", False)
            ),
            "grant_role_id": str(actions.get("grant_role_id") or "").strip(),
        },
    }


def build_generic_flow_js_from_blueprint(bp: dict) -> str:
    bp = normalize_generic_flow_blueprint(bp)

    command_name = bp["command_name"]
    aliases_js = json.dumps(bp["aliases"], ensure_ascii=False)
    guild_id = json.dumps(bp["guild_id"], ensure_ascii=False)
    allowed_roles_js = json.dumps(bp["allowed_role_ids"], ensure_ascii=False)
    target_channel_id = json.dumps(bp["target_channel_id"], ensure_ascii=False)
    mention_role_id = json.dumps(bp["mention_role_id"], ensure_ascii=False)

    embed_title = json.dumps(bp["embed"]["title"], ensure_ascii=False)
    embed_description = json.dumps(bp["embed"]["description"], ensure_ascii=False)
    embed_color = int(bp["embed"]["color"])
    embed_footer = json.dumps(bp["embed"]["footer"], ensure_ascii=False)

    steps_js = json.dumps(bp["flow"]["steps"], ensure_ascii=False)
    allow_cancel = str(bp["flow"]["allow_cancel"]).lower()

    grant_role = str(bp["actions"]["grant_role_to_mentioned_user"]).lower()
    grant_role_id = json.dumps(bp["actions"]["grant_role_id"], ensure_ascii=False)

    return f"""const {{ EmbedBuilder }} = require("discord.js");

const TARGET_GUILD_ID = {guild_id};
const TARGET_CHANNEL_ID = {target_channel_id};
const MENTION_ROLE_ID = {mention_role_id};
const ALLOWED_ROLE_IDS = {allowed_roles_js};
const FLOW_STEPS = {steps_js};
const GRANT_ROLE_TO_MENTIONED_USER = {grant_role};
const GRANT_ROLE_ID = {grant_role_id};

const sessions = new Map();

function hasAllowedRole(member) {{
  if (!ALLOWED_ROLE_IDS || ALLOWED_ROLE_IDS.length === 0) return true;
  if (!member || !member.roles || !member.roles.cache) return false;
  return ALLOWED_ROLE_IDS.some(roleId => member.roles.cache.has(roleId));
}}

function getAttachmentInfo(message) {{
  if (!message.attachments || message.attachments.size === 0) return null;
  const first = message.attachments.first();
  if (!first) return null;

  return {{
    name: first.name || "arquivo",
    url: first.url,
    contentType: first.contentType || "desconhecido",
    size: first.size || 0,
  }};
}}

function getMentionedUser(message) {{
  if (!message.mentions || !message.mentions.users || message.mentions.users.size === 0) return null;
  const first = message.mentions.users.first();
  if (!first) return null;

  return {{
    id: String(first.id),
    tag: first.tag || first.username || "usuário",
  }};
}}

function getCurrentStep(session) {{
  return FLOW_STEPS[session.stepIndex];
}}

module.exports = {{
  name: {json.dumps(command_name)},
  aliases: {aliases_js},
  description: "Comando genérico complexo gerado por IA",

  async execute(message, args, client) {{
    try {{
      if (TARGET_GUILD_ID && (!message.guild || String(message.guild.id) !== String(TARGET_GUILD_ID))) {{
        await message.reply("Este comando só pode ser usado no servidor configurado.");
        return;
      }}

      if (!hasAllowedRole(message.member)) {{
        await message.reply("❌ Você não tem permissão para usar este comando.");
        return;
      }}

      const userId = String(message.author.id);

      if (sessions.has(userId)) {{
        await message.reply(
          "Você já tem um fluxo em andamento.\\n" +
          "Envie o próximo dado solicitado ou digite `cancelar` para abortar."
        );
        return;
      }}

      sessions.set(userId, {{
        stepIndex: 0,
        guildId: message.guild ? String(message.guild.id) : "",
        channelId: String(message.channel.id),
        startedAt: Date.now(),
        data: {{}}
      }});

      const firstStep = FLOW_STEPS[0];
      await message.reply(firstStep.ask);
    }} catch (err) {{
      console.error("[BOT] erro ao iniciar fluxo genérico:", err);
      await message.reply("Erro ao iniciar o fluxo.").catch(() => null);
    }}
  }},

  async onMessage(message, client) {{
    try {{
      if (message.author?.bot) return;
      if (TARGET_GUILD_ID && (!message.guild || String(message.guild.id) !== String(TARGET_GUILD_ID))) return;

      const userId = String(message.author.id);
      const session = sessions.get(userId);
      if (!session) return;

      if (String(message.channel.id) !== String(session.channelId)) return;

      const content = (message.content || "").trim();

      if ({allow_cancel} && content.toLowerCase() === "cancelar") {{
        sessions.delete(userId);
        await message.reply("❌ Fluxo cancelado com sucesso.");
        return;
      }}

      const step = getCurrentStep(session);
      if (!step) {{
        sessions.delete(userId);
        return;
      }}

      if (step.type === "text") {{
        if (!content || content.startsWith("!")) return;

        session.data[step.id] = content;
      }}

      if (step.type === "attachment") {{
        const attachment = getAttachmentInfo(message);
        if (!attachment) {{
          await message.reply(`⚠️ Agora preciso de: ${{step.label}} como anexo.`);
          return;
        }}
        session.data[step.id] = attachment;
      }}

      if (step.type === "user_mention") {{
        const mentioned = getMentionedUser(message);
        if (!mentioned) {{
          await message.reply(`⚠️ Agora preciso que você mencione um usuário para: ${{step.label}}.`);
          return;
        }}
        session.data[step.id] = mentioned;
      }}

      session.stepIndex += 1;

      if (session.stepIndex < FLOW_STEPS.length) {{
        sessions.set(userId, session);
        const nextStep = getCurrentStep(session);
        await message.reply(nextStep.ask);
        return;
      }}

      const targetChannel =
        (TARGET_CHANNEL_ID
          ? message.guild.channels.cache.get(TARGET_CHANNEL_ID) || await message.guild.channels.fetch(TARGET_CHANNEL_ID).catch(() => null)
          : message.channel);

      if (!targetChannel || !targetChannel.isTextBased()) {{
        await message.reply("❌ Não consegui encontrar o canal de destino configurado.");
        sessions.delete(userId);
        return;
      }}

      const fields = [];

      for (const s of FLOW_STEPS) {{
        const value = session.data[s.id];

        if (s.type === "text") {{
          fields.push({{
            name: s.label,
            value: String(value || "Não informado"),
            inline: false,
          }});
        }}

        if (s.type === "attachment") {{
          fields.push({{
            name: s.label,
            value: value?.url ? `[Abrir arquivo](${{value.url}})` : "Arquivo não encontrado",
            inline: false,
          }});
        }}

        if (s.type === "user_mention") {{
          fields.push({{
            name: s.label,
            value: value?.id ? `<@${{value.id}}>\\nID: \\`${{value.id}}\\`` : "Usuário não informado",
            inline: false,
          }});
        }}
      }}

      fields.push(
        {{
          name: "📨 Solicitante",
          value: `${{message.author}}\\nID: \\`${{message.author.id}}\\``,
          inline: false,
        }},
        {{
          name: "💬 Canal de origem",
          value: `<#${{message.channel.id}}>`,
          inline: true,
        }},
        {{
          name: "🕒 Enviado em",
          value: `<t:${{Math.floor(Date.now() / 1000)}}:F>`,
          inline: true,
        }}
      );

      const embed = new EmbedBuilder()
        .setTitle({embed_title})
        .setDescription({embed_description})
        .setColor({embed_color})
        .addFields(fields)
        .setFooter({{ text: {embed_footer} }})
        .setTimestamp();

      const sendResult = await targetChannel.send({{
        content: MENTION_ROLE_ID ? `<@&${{MENTION_ROLE_ID}}>` : "",
        embeds: [embed],
      }});

      if (GRANT_ROLE_TO_MENTIONED_USER && GRANT_ROLE_ID) {{
        for (const s of FLOW_STEPS) {{
          if (s.type === "user_mention") {{
            const target = session.data[s.id];
            if (target?.id) {{
              const member = await message.guild.members.fetch(target.id).catch(() => null);
              if (member) {{
                await member.roles.add(GRANT_ROLE_ID).catch(() => null);
              }}
            }}
          }}
        }}
      }}

      await message.reply("✅ Fluxo finalizado com sucesso.");
      sessions.delete(userId);
    }} catch (err) {{
      console.error("[BOT] erro em onMessage do comando genérico:", err);
      try {{
        await message.reply("❌ Ocorreu um erro durante o fluxo.");
      }} catch (_) {{}}
    }}
  }},
}};
"""


# =========================================================
# ROUTER
# =========================================================


def handle_local_bot_chat(message: str, user_session: dict) -> Tuple[bool, str, bool]:
    """
    Retorna: (ok, msg, handled_locally)
    """
    text = (message or "").strip().lower()

    if not is_local_bot_request(message):
        return True, "", False

    if not is_azaph_session(user_session):
        return (
            False,
            "Acesso negado. Somente Azaph pode controlar o bot Discord pelo chat do menu.",
            True,
        )

    # 1) apagar
    if (
        "apague o comando !" in text
        or "apagar comando !" in text
        or "excluir comando !" in text
    ):
        ok, msg = delete_command_from_text(message)
        return ok, msg, True

    # 2) mostrar blueprint
    if (
        "mostrar blueprint do comando !" in text
        or "mostre blueprint do comando !" in text
        or "mostrar o blueprint do comando !" in text
        or "mostre o blueprint do comando !" in text
    ):
        ok, msg = show_blueprint_from_text(message)
        return ok, msg, True

    # 3) editar blueprint
    if "edite o comando !" in text or "editar comando !" in text:
        ok, msg = edit_blueprint_from_text(message)
        return ok, msg, True

    # 4) criar comando complexo
    if (
        "crie um comando complexo !" in text
        or "criar comando complexo !" in text
        or "crie um comando completo !" in text
        or "criar comando completo !" in text
        or "quero um comando complexo !" in text
        or "quero um comando completo !" in text
    ):
        ok, msg = create_complex_command_from_text(message)
        return ok, msg, True

    # 5) criar/editar comando simples
    if (
        "crie comando !" in text
        or "criar comando !" in text
        or "gere comando !" in text
    ):
        ok, msg = groq_create_or_update_command(message)
        return ok, msg, True

    if "configurar token bot discord" in text:
        token = extract_token_from_message(message)
        ok, msg = create_real_env(token)
        return ok, msg, True

    if (
        "instalar bot discord" in text
        or "npm install bot discord" in text
        or "instalar dependências do bot" in text
    ):
        ok, msg = npm_install()
        return ok, msg, True

    # IMPORTANTE: reiniciar precisa vir antes de iniciar,
    # porque "reiniciar bot discord" contém "iniciar bot discord"
    if "reiniciar bot discord" in text or "restart bot discord" in text:
        ok, msg = restart_bot_process()
        return ok, msg, True

    if "parar bot discord" in text or "desligar bot discord" in text:
        ok, msg = stop_bot_process()
        return ok, msg, True

    if "iniciar bot discord" in text or "ligar bot discord" in text:
        ok, msg = start_bot_process()
        return ok, msg, True

    if "log bot discord" in text or "mostrar log do bot" in text:
        ok, msg = read_bot_log()
        return ok, msg, True

    if (
        "status bot discord" in text
        or "status do bot discord" in text
        or "status do bot" in text
    ):
        ok, msg = get_bot_status()
        return ok, msg, True

    if "estrutura do bot" in text or "mostrar estrutura do bot" in text:
        ok, msg = get_tree()
        return ok, msg, True

    # 6) CRIAR/EDITAR comando simples
    if (
        "crie comando !" in text
        or "criar comando !" in text
        or "gere comando !" in text
        or "comando !" in text
    ):
        ok, msg = groq_create_or_update_command(message)
        return ok, msg, True

    return (
        True,
        (
            "[BOT LOCAL]\n\n"
            "Entendi que você quer controlar o bot Discord.\n\n"
            "Use frases como:\n"
            "- criar bot discord\n"
            "- configurar token bot discord SEU_TOKEN\n"
            "- instalar bot discord\n"
            "- iniciar bot discord\n"
            "- parar bot discord\n"
            "- reiniciar bot discord\n"
            "- status bot discord\n"
            "- mostrar estrutura do bot\n"
            "- mostrar log do bot\n"
            "- crie comando !ping responda Pong\n"
            "- crie um comando complexo !venda\n"
            "- mostre o blueprint do comando !venda\n"
            "- edite o comando !venda agora só quem tiver o cargo 1468684459531309268 pode usar\n"
            "- edite o comando !venda agora envie para o canal 1475574286243594461\n"
            "- apague o comando !venda"
        ),
        True,
    )
