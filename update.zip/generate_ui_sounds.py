import math
import wave
import struct
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOUNDS_DIR = ROOT / "assets" / "sounds"
SOUNDS_DIR.mkdir(parents=True, exist_ok=True)

SAMPLE_RATE = 44100


def clamp(x: float) -> int:
    return max(-32767, min(32767, int(x)))


def write_wav(path: Path, samples: list[int]) -> None:
    with wave.open(str(path), "w") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)  # 16-bit
        wf.setframerate(SAMPLE_RATE)
        frames = b"".join(struct.pack("<h", s) for s in samples)
        wf.writeframes(frames)


def envelope(t: float, duration: float, attack: float = 0.01, release: float = 0.07) -> float:
    if t < attack:
        return t / attack
    if t > duration - release:
        return max(0.0, (duration - t) / release)
    return 1.0


def tone(freq: float, duration: float, volume: float = 0.35, wave_type: str = "sine") -> list[int]:
    total = int(SAMPLE_RATE * duration)
    out = []

    for i in range(total):
        t = i / SAMPLE_RATE
        env = envelope(t, duration)

        if wave_type == "square":
            base = 1.0 if math.sin(2 * math.pi * freq * t) >= 0 else -1.0
        elif wave_type == "triangle":
            base = (2 / math.pi) * math.asin(math.sin(2 * math.pi * freq * t))
        else:
            base = math.sin(2 * math.pi * freq * t)

        out.append(clamp(base * volume * env * 32767))

    return out


def noise_tick(duration: float = 0.018, volume: float = 0.10) -> list[int]:
    total = int(SAMPLE_RATE * duration)
    out = []
    seed = 1234567

    for i in range(total):
        t = i / SAMPLE_RATE
        env = envelope(t, duration, attack=0.001, release=0.012)

        # pseudo-noise simples
        seed_local = (seed * (i + 1) * 1103515245 + 12345) & 0x7FFFFFFF
        rand = ((seed_local / 0x7FFFFFFF) * 2.0) - 1.0

        out.append(clamp(rand * volume * env * 32767))

    return out


def silence(duration: float) -> list[int]:
    return [0] * int(SAMPLE_RATE * duration)


def concat(*parts: list[int]) -> list[int]:
    out = []
    for p in parts:
        out.extend(p)
    return out


def mix(*tracks: list[int]) -> list[int]:
    max_len = max(len(t) for t in tracks)
    out = []

    for i in range(max_len):
        value = 0
        for tr in tracks:
            if i < len(tr):
                value += tr[i]
        out.append(clamp(value))

    return out


def click_sound() -> list[int]:
    return concat(
        mix(
            tone(1150, 0.028, 0.18, "triangle"),
            tone(1650, 0.020, 0.08, "sine"),
        ),
        silence(0.006),
        tone(880, 0.020, 0.12, "triangle"),
    )


def hover_sound() -> list[int]:
    return mix(
        tone(720, 0.035, 0.10, "sine"),
        tone(1080, 0.028, 0.05, "triangle"),
    )


def open_sound() -> list[int]:
    return concat(
        mix(
            tone(320, 0.08, 0.10, "sine"),
            tone(640, 0.08, 0.05, "triangle"),
        ),
        silence(0.012),
        mix(
            tone(540, 0.08, 0.12, "sine"),
            tone(1080, 0.08, 0.05, "triangle"),
        ),
        silence(0.012),
        mix(
            tone(860, 0.12, 0.12, "sine"),
            tone(1720, 0.12, 0.04, "triangle"),
        ),
    )


def login_sound() -> list[int]:
    return concat(
        mix(tone(440, 0.07, 0.10, "sine"), tone(880, 0.07, 0.04, "triangle")),
        silence(0.015),
        mix(tone(660, 0.08, 0.11, "sine"), tone(1320, 0.08, 0.04, "triangle")),
        silence(0.015),
        mix(tone(980, 0.12, 0.12, "sine"), tone(1960, 0.12, 0.03, "triangle")),
    )


def send_sound() -> list[int]:
    return concat(
        tone(900, 0.032, 0.12, "triangle"),
        silence(0.006),
        tone(1320, 0.040, 0.10, "triangle"),
    )


def receive_sound() -> list[int]:
    return concat(
        mix(tone(760, 0.055, 0.10, "sine"), tone(1140, 0.055, 0.04, "triangle")),
        silence(0.008),
        mix(tone(1020, 0.075, 0.10, "sine"), tone(1530, 0.075, 0.03, "triangle")),
    )


def error_sound() -> list[int]:
    return concat(
        tone(220, 0.10, 0.14, "square"),
        silence(0.020),
        tone(170, 0.14, 0.12, "square"),
    )


def startup_sound() -> list[int]:
    return concat(
        mix(tone(240, 0.09, 0.08, "sine"), tone(480, 0.09, 0.03, "triangle")),
        silence(0.012),
        mix(tone(420, 0.10, 0.09, "sine"), tone(840, 0.10, 0.03, "triangle")),
        silence(0.012),
        mix(tone(720, 0.12, 0.10, "sine"), tone(1440, 0.12, 0.03, "triangle")),
        silence(0.012),
        mix(tone(1080, 0.16, 0.11, "sine"), tone(2160, 0.16, 0.025, "triangle")),
    )


def notify_sound() -> list[int]:
    return concat(
        tone(980, 0.045, 0.10, "triangle"),
        silence(0.012),
        tone(1480, 0.055, 0.10, "triangle"),
    )


def typing_sound() -> list[int]:
    # um tic-tic curto e limpo, com 4 pulsos
    tick = mix(
        noise_tick(0.015, 0.08),
        tone(2400, 0.012, 0.025, "square"),
    )
    return concat(
        tick, silence(0.030),
        tick, silence(0.026),
        tick, silence(0.030),
        tick
    )


def generate():
    files = {
        "click.wav": click_sound(),
        "hover.wav": hover_sound(),
        "open.wav": open_sound(),
        "login.wav": login_sound(),
        "send.wav": send_sound(),
        "receive.wav": receive_sound(),
        "error.wav": error_sound(),
        "startup.wav": startup_sound(),
        "notify.wav": notify_sound(),
        "typing.wav": typing_sound(),
    }

    for name, samples in files.items():
        path = SOUNDS_DIR / name
        write_wav(path, samples)
        print(f"Gerado: {path}")

    print("\nTodos os sons foram gerados com sucesso.")


if __name__ == "__main__":
    generate()